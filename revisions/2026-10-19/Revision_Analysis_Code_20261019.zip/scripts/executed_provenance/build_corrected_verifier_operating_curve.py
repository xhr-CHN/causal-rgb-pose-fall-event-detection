"""Descriptive threshold sweep of locked revised verifier; no threshold selection."""
from pathlib import Path
import csv
import hashlib
import json
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / 'work/server_label_correction_import_20261012/corrected_verifier_gmd_retrospective_v1'
OUT = ROOT / 'outputs/label_corrected_revision_20261012/verifier_operating_analysis'
LABELS = ROOT / 'work/gmdcsa24_server_import_20261009/gmdcsa24_final_blind_evaluation_v1/annotation_audit.csv'


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def write(path, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    if OUT.exists():
        raise RuntimeError(f'Preserve existing operating analysis: {OUT}')
    predictions = read(SERVER / 'corrected_verifier_predictions.csv')
    metadata = {r['sequence_id']: r for r in read(LABELS)}
    protocol = json.loads((SERVER / 'protocol.json').read_text())
    locked = float(protocol['threshold'])
    score = np.array([float(r['corrected_verifier_probability']) for r in predictions])
    timestamp = np.array([float(r['decision_timestamp_ms']) for r in predictions])
    negative_seconds = sum(min(float(r['fall_onset_seconds']), float(r['actual_duration_seconds']))
                           if r['category'] == 'Fall' else float(r['actual_duration_seconds']) for r in metadata.values())
    assert len(predictions) == 110 and len(metadata) == 160
    thresholds = sorted(set(score.tolist() + [0.0, 1.0, locked]), reverse=True)
    def evaluate(threshold):
        kept = score >= threshold
        false, duplicate, delays = 0, 0, []
        for sid, info in metadata.items():
            times = timestamp[np.array([r['sequence_id'] == sid for r in predictions]) & kept]
            if info['category'] == 'ADL':
                false += len(times)
            else:
                onset = float(info['fall_onset_seconds']) * 1000
                false += int((times < onset).sum())
                after = times[times >= onset]
                if len(after):
                    delays.append((after.min() - onset) / 1000)
                    duplicate += max(0, len(after) - 1)
        detected = len(delays)
        return {'threshold': threshold, 'retained_candidates': int(kept.sum()),
                'events': 79, 'detected': detected, 'recall': detected / 79,
                'false_alarms': false, 'negative_exposure_h': negative_seconds / 3600,
                'fa_per_hour': false / (negative_seconds / 3600),
                'precision': detected / (detected + false) if detected + false else '',
                'duplicate_alarms': duplicate, 'median_delay_s': float(np.median(delays)) if delays else '',
                'is_development_locked_threshold': int(threshold == locked)}
    curve = [evaluate(t) for t in thresholds]
    for a, b in zip(curve, curve[1:]):
        assert a['threshold'] > b['threshold']
        assert a['retained_candidates'] <= b['retained_candidates']
        assert a['detected'] <= b['detected'] and a['false_alarms'] <= b['false_alarms']
    selected = next(r for r in curve if r['is_development_locked_threshold'])
    assert (selected['detected'], selected['false_alarms'], selected['retained_candidates']) == (60, 14, 74)
    original = json.loads((SERVER / 'summary.json').read_text())['corrected_verifier_retrospective']
    assert abs(selected['fa_per_hour'] - original['false_alarms_per_hour']) < 1e-12
    alternatives = [evaluate(t) for t in sorted(set([0.0, 0.1, 0.2, locked, 0.4, 0.5, 0.75, 0.9, 1.0]), reverse=True)]
    OUT.mkdir(parents=True)
    write(OUT / 'threshold_curve.csv', curve)
    write(OUT / 'illustrative_operating_points.csv', alternatives)
    result = {'role': 'post-hoc descriptive sensitivity on previously revealed test set',
              'threshold_count': len(curve), 'development_locked_threshold': locked,
              'threshold_selection_or_model_change': False, 'rescue_applied': False,
              'timestamp': 'stored decision_timestamp_ms, identical to retrospective server evaluation',
              'event_precision': 'first detected fall events / (detected events + false alarms); duplicate post-onset alarms excluded',
              'zero_alarm_precision': 'undefined, retained in CSV and omitted only from PR plotting',
              'alternative_points': 'illustrative predetermined values; not chosen by test performance',
              'input_sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in
                              (SERVER / 'corrected_verifier_predictions.csv', LABELS, SERVER / 'protocol.json')}}
    (OUT / 'protocol.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps({'protocol': result, 'locked': selected, 'illustrative': alternatives}, indent=2))


if __name__ == '__main__':
    main()
