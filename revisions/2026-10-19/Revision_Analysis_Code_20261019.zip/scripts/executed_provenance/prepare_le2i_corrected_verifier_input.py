"""Prepare corrected development labels with the existing 18 verifier features."""
from pathlib import Path
import collections
import csv
import hashlib
import io
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'outputs/revision_submission_final_v11'
LABELS = ROOT / 'work/le2i_label_basis_audit/omnifall_unified_v1'
OUT = LABELS / 'corrected_verifier_input_v1'
ARCHIVE = Path('E:/FFFfall/multidataset_alarm_recovery_features_v3_full.zip')
FEATURES = ['pre_person_conf_max', 'pre_bbox_aspect_ratio_std',
            'pre_branch_disagreement_mean', 'pre_bbox_cy_delta',
            'pre_bbox_aspect_ratio_slope', 'pre_rgb_fall_score_delta',
            'pre_torso_keypoint_conf_max', 'pre_bbox_height_delta',
            'confirm_fused_fall_score_mean', 'confirm_fused_fall_score_min',
            'confirm_fused_fall_score_delta', 'confirm_fall_support_fraction_70',
            'confirm_fall_longest_run_70', 'confirm_modal_agreement_fraction_50',
            'confirm_recovery_drop_from_candidate', 'confirm_fallen_rise',
            'confirm_branch_disagreement_mean', 'confirm_pose_found_ratio_mean']


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def main():
    if OUT.exists():
        raise RuntimeError(f'Preserve existing input: {OUT}')
    with zipfile.ZipFile(ARCHIVE) as archive:
        raw = archive.read('alarm_recovery_features.csv')
    source = list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))
    oof = {r['candidate_key']: r for r in read(BASE / 'evidence/final_verifier_oof_predictions.csv')}
    assert len(source) == len(oof) == 281
    assert {r['candidate_key'] for r in source} == set(oof)
    assert {r['dataset'].lower() for r in source} == {'urfd', 'le2i'}
    alarms = {(r['sequence_id'], r['sample_index']): r for r in read(
        LABELS / 'quality_gated_late_logit/classified_alarms.csv')}
    rows, changes = [], 0
    import math
    for r in source:
        old = int(r['label_true_alarm'])
        assert old == int(oof[r['candidate_key']]['label_true_alarm'])
        new = int(alarms[(r['sequence_id'], r['sample_index'])]['alarm_classification'] == 'event_alarm') if r['dataset'].lower() == 'le2i' else old
        changes += new != old
        assert all(math.isfinite(float(r[f])) for f in FEATURES)
        row = {k: r[k] for k in ('dataset', 'candidate_key', 'sequence_id', 'sample_index')}
        row.update({'original_label_true_alarm': old, 'label_true_alarm': new})
        row.update({f: r[f] for f in FEATURES})
        rows.append(row)
    assert changes == 30
    OUT.mkdir()
    with (OUT / 'alarm_confirmation_features_corrected.csv').open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    protocol = {'candidates': len(rows), 'sequence_groups': len({r['dataset'] + '::' + r['sequence_id'] for r in rows}),
                'features': FEATURES, 'changed_labels': changes,
                'class_counts': dict(collections.Counter(r['label_true_alarm'] for r in rows)),
                'datasets': sorted({r['dataset'] for r in rows}),
                'gmdcsa24_read': False, 'training_performed': False,
                'source_feature_member_sha256': hashlib.sha256(raw).hexdigest(),
                'source_archive_sha256': hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
                'label_protocol': 'URFD unchanged; Le2i unified OmniFall first-post-onset candidate true-alarm labels',
                'old_labels_checked_against_historical_oof': True,
                'intended_use': 'corrected development retraining/grouped validation; cannot attach historical GMD blind-test metrics to a new model'}
    (OUT / 'protocol.json').write_text(json.dumps(protocol, indent=2), encoding='utf-8')
    print(json.dumps(protocol, indent=2))


if __name__ == '__main__':
    main()
