"""Video-paired frame bootstrap and development-label audit after reannotation."""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import numpy as np
import server_frame_bootstrap as bootstrap

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'outputs/revision_submission_final_v11'
LABELS = ROOT / 'work/le2i_label_basis_audit/omnifall_unified_v1'
OUT = LABELS / 'frame_statistics_v1'
PRED = BASE / 'evidence/matched_operator_control/input/le2i_frame_predictions.csv'
REPS, SEED = 10000, 20261004


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def write(path, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    if OUT.exists():
        raise RuntimeError(f'Preserve existing results: {OUT}')
    rows = read(PRED)
    targets = read(LABELS / 'frozen_endpoint_targets.csv')
    assert len(rows) == len(targets) == 58328
    keys = ('sequence_id', 'sample_index', 'source_frame_number')
    assert all(all(a[k] == b[k] for k in keys) for a, b in zip(rows, targets))
    full_y = np.array([int(r['target_state_id']) for r in targets])
    mask = full_y >= 0
    y = (full_y[mask] != 0).astype(int)
    ids = sorted({r['sequence_id'] for r in rows})
    assert len(ids) == 190 and mask.sum() == 55007
    lookup = {sid: i for i, sid in enumerate(ids)}
    groups = np.array([lookup[r['sequence_id']] for r, valid in zip(rows, mask) if valid])
    spec = importlib.util.spec_from_file_location('fusion_evaluator', BASE / 'scripts/external_fusion_ablation_urfd_le2i_v1.py')
    evaluator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(evaluator)
    probabilities = evaluator.build_variants(rows)
    rng = np.random.default_rng(SEED)
    draws = rng.integers(len(ids), size=(REPS, len(ids)))
    weights = np.array([np.bincount(draw, minlength=len(ids)) for draw in draws])
    OUT.mkdir()
    output, all_boot, points = [], {}, {}
    for variant in bootstrap.VARIANTS:
        prob = np.asarray(probabilities[variant], float)[mask]
        point = bootstrap.metrics(y, prob, np.ones(len(y)))
        pred = (prob.argmax(axis=1) != 0).astype(int)
        cells = np.stack([np.bincount(groups, weights=cell, minlength=len(ids)) for cell in
                          ((y == 1) & (pred == 1), (y == 0) & (pred == 1),
                           (y == 0) & (pred == 0), (y == 1) & (pred == 0))], axis=1)
        tp, fp, tn, fn = (weights @ cells).T
        f1 = (np.divide(2 * tp, 2 * tp + fp + fn, out=np.zeros_like(tp), where=(2 * tp + fp + fn) > 0)
              + np.divide(2 * tn, 2 * tn + fp + fn, out=np.zeros_like(tn), where=(2 * tn + fp + fn) > 0)) / 2
        score = np.clip(prob[:, 1] + prob[:, 2], 0, 1)
        ap = (bootstrap.batched_ap(y, score, groups, weights)
              + bootstrap.batched_ap(1 - y, 1 - score, groups, weights)) / 2
        values = np.column_stack((f1, ap))
        all_boot[variant], points[variant] = values, point
        for k, metric in enumerate(('binary_macro_f1', 'binary_macro_auprc')):
            finite = values[np.isfinite(values[:, k]), k]
            assert len(finite) == REPS
            output.append({'variant': variant, 'metric': metric, 'estimate': point[k],
                           'ci_low': np.percentile(finite, 2.5), 'ci_high': np.percentile(finite, 97.5),
                           'videos': len(ids), 'labelled_endpoints': len(y),
                           'excluded_endpoints': len(rows) - len(y), 'finite_resamples': len(finite)})
        print(variant, 'completed', flush=True)
    write(OUT / 'frame_intervals.csv', output)
    gated, fixed = 'quality_gated_late_logit', 'fixed_0.5_late_logit'
    effects = []
    for k, metric in enumerate(('binary_macro_f1', 'binary_macro_auprc')):
        diff = all_boot[gated][:, k] - all_boot[fixed][:, k]
        effects.append({'comparison': 'gated minus fixed', 'metric': metric,
                        'difference': points[gated][k] - points[fixed][k],
                        'ci_low': np.percentile(diff, 2.5), 'ci_high': np.percentile(diff, 97.5)})
    write(OUT / 'paired_frame_effects.csv', effects)
    classified = read(LABELS / gated / 'classified_alarms.csv')
    alarm_lookup = {(r['sequence_id'], r['sample_index']): r for r in classified}
    changes = []
    le2i_count = 0
    for row in read(BASE / 'evidence/final_verifier_oof_predictions.csv'):
        if row['dataset'].lower() != 'le2i':
            continue
        le2i_count += 1
        alarm = alarm_lookup[(row['sequence_id'], row['sample_index'])]
        new = int(alarm['alarm_classification'] == 'event_alarm')
        old = int(row['label_true_alarm'])
        if old != new:
            changes.append({'candidate_key': row['candidate_key'], 'sequence_id': row['sequence_id'],
                            'sample_index': row['sample_index'], 'old_label': old,
                            'unified_label': new, 'new_classification': alarm['alarm_classification'],
                            'role': 'development label audit; old OOF scores do not validate corrected-label training'})
    if changes:
        write(OUT / 'verifier_development_label_changes.csv', changes)
    protocol = {'label_source': 'fixed OmniFall revision in parent protocol.json',
                'metrics': 'binary macro F1/AP: fall or fallen versus other annotated activity',
                'point_prediction': 'argmax of unchanged three-state probabilities, collapsed to binary',
                'ap': 'full tied-score groups, fall+fallen score and complement for negative class',
                'bootstrap_unit': 'complete video with fixed known-label evaluation mask',
                'resamples': REPS, 'seed': SEED, 'paired_resampling': True,
                'unknown_frame_handling': 'excluded; never filled as ADL',
                'labelled_endpoints': int(mask.sum()), 'excluded_endpoints': int((~mask).sum()),
                'endpoint_coverage_fraction': float(mask.mean()),
                'limitations': 'conditional on label source and annotated endpoints; video clustering does not remove subject/camera correlation',
                'historical_metric_comparability': 'historical positive truth used original provider fall onset/end interval; new truth uses OmniFall fall/fallen segments; old and new estimates are not same-label comparisons',
                'le2i_oof_candidates': le2i_count, 'changed_oof_development_labels': len(changes),
                'negative_to_positive': sum(r['old_label'] == 0 for r in changes),
                'positive_to_negative': sum(r['old_label'] == 1 for r in changes),
                'training': False, 'threshold_tuning': False,
                'input_hashes': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in
                                 (PRED, LABELS / 'frozen_endpoint_targets.csv')}}
    (OUT / 'protocol.json').write_text(json.dumps(protocol, indent=2), encoding='utf-8')
    print(json.dumps({'completed': True, 'frame_metrics': output,
                      'paired_effects': effects, 'label_audit': protocol}, indent=2), flush=True)


if __name__ == '__main__':
    main()
