"""Build versioned Le2i reannotation protocol and rescore frozen candidates."""
from pathlib import Path
import collections
import csv
import hashlib
import importlib.util
import json
import math

ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / 'work/le2i_label_basis_audit'
BASE = ROOT / 'outputs/revision_submission_final_v11'
OUT = AUDIT / 'omnifall_unified_v1'


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def write(path, rows):
    if not rows:
        return
    with path.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if OUT.exists():
        raise RuntimeError(f'Preserve previous output: {OUT}')
    inventory = {r['sequence_id']: r for r in read(
        ROOT / 'work/le2i_inventory/le2i_inventory_v2/sequence_inventory.csv')}
    labels = AUDIT / 'omnifall_le2i.csv'
    vocabulary = {int(r['id']): r['label'] for r in read(AUDIT / 'omnifall_label2id.csv')}
    assert vocabulary[1] == 'fall' and vocabulary[2] == 'fallen'
    grouped = collections.defaultdict(list)
    for row in read(labels):
        scene, stem = row['path'].rsplit('/', 1)
        sid = scene.lower().replace(' ', '_') + '_' + stem.lower()
        assert int(row['label']) in vocabulary
        assert float(row['start']) < float(row['end'])
        grouped[sid].append(row)
    assert set(grouped) == set(inventory) and len(inventory) == 190
    segments, video_rows, event_rows, boundary_issues = [], [], [], []
    events = {}
    exposure_seconds = 0.0
    for sid, meta in inventory.items():
        rows = sorted(grouped[sid], key=lambda r: float(r['start']))
        duration = float(meta['duration_seconds'])
        falls = [r for r in rows if int(r['label']) == 1]
        assert len(falls) <= 1, 'Multi-event matching needs explicit implementation'
        onset = float(falls[0]['start']) if falls else None
        if onset is not None:
            assert 0 <= onset < duration
            events[sid] = {'sequence_id': sid, 'onset_ms': onset * 1000,
                           'onset_frame': math.ceil(onset * float(meta['fps']) - 1e-9) + 1}
        negative_seconds = duration if onset is None else onset
        exposure_seconds += negative_seconds
        video_rows.append({'sequence_id': sid, 'scene': meta['scene'],
                           'has_fall': int(bool(falls)), 'fall_events': len(falls),
                           'onset_s': onset, 'duration_s': duration,
                           'negative_exposure_seconds': negative_seconds,
                           'original_event_file_present': meta['annotation_present']})
        if falls:
            event_rows.append({'sequence_id': sid, 'onset_s': onset,
                               'fall_end_s': float(falls[0]['end']),
                               'label_source': 'OmniFall author-published reannotation'})
        covered_end = 0.0
        for row in rows:
            start, end = float(row['start']), float(row['end'])
            if start > covered_end + 0.001:
                boundary_issues.append({'sequence_id': sid, 'issue': 'unlabelled_gap',
                                        'start_s': covered_end, 'end_s': start,
                                        'duration_s': start - covered_end})
            elif start < covered_end - 0.001:
                boundary_issues.append({'sequence_id': sid, 'issue': 'overlap',
                                        'start_s': start, 'end_s': min(end, covered_end),
                                        'duration_s': min(end, covered_end) - start})
            if end > duration + 0.001:
                boundary_issues.append({'sequence_id': sid, 'issue': 'beyond_native_duration',
                                        'start_s': duration, 'end_s': end,
                                        'duration_s': end - duration})
            covered_end = max(covered_end, end)
            label = int(row['label'])
            segments.append({'sequence_id': sid, 'start_s': start, 'end_s': end,
                             'omnifall_label_id': label, 'omnifall_label': vocabulary[label],
                             'target_state_id': label if label in (1, 2) else 0,
                             'target_state': {0: 'ADL', 1: 'Falling', 2: 'Fallen'}[
                                 label if label in (1, 2) else 0]})
        if covered_end < duration - 0.001:
            boundary_issues.append({'sequence_id': sid, 'issue': 'unlabelled_tail',
                                    'start_s': covered_end, 'end_s': duration,
                                    'duration_s': duration - covered_end})
    assert len(events) == 130
    evpath = BASE / 'scripts/external_fusion_ablation_urfd_le2i_v1.py'
    spec = importlib.util.spec_from_file_location('frozen_candidate_eval', evpath)
    evaluator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(evaluator)
    OUT.mkdir()
    write(OUT / 'mapped_segments.csv', segments)
    write(OUT / 'video_inventory.csv', video_rows)
    write(OUT / 'fall_events.csv', event_rows)
    write(OUT / 'segment_boundary_issues.csv', boundary_issues)
    source = BASE / 'evidence/input/server/external_fusion_ablation_urfd_le2i_server_v3/le2i'
    summaries, hashes = [], {}
    for variant in ['pose_branch_only', 'rgb_branch_only', 'fixed_0.5_late_logit',
                    'quality_gated_late_logit']:
        path = source / variant / 'candidate_alarms.csv'
        alarms = read(path)
        assert {r['sequence_id'] for r in alarms} <= set(inventory)
        metrics, classified, per_event = evaluator.evaluate_events(
            alarms, inventory, events, exposure_seconds / 3600)
        hashes[variant] = digest(path)
        summaries.append({'variant': variant, 'videos': 190, 'fall_events': 130,
                          'detected': metrics['detected_fall_events'],
                          'event_recall': metrics['event_recall'],
                          'false_alarms': metrics['false_alarm_count'],
                          'negative_exposure_hours': exposure_seconds / 3600,
                          'fa_per_hour': metrics['false_alarms_per_hour'],
                          'median_delay_s': metrics['median_detection_delay_s'],
                          'duplicates': metrics['duplicate_alarms_after_onset']})
        folder = OUT / variant
        folder.mkdir()
        write(folder / 'classified_alarms.csv', classified)
        write(folder / 'event_results.csv', per_event)
    write(OUT / 'candidate_metrics.csv', summaries)
    protocol = {
        'label_source': 'OmniFall author-published Le2i reannotation',
        'source_revision': '83572a37b9e3081df8c06a56874b1d1f2a19386c',
        'labels_sha256': digest(labels), 'vocabulary_sha256': digest(AUDIT / 'omnifall_label2id.csv'),
        'class_mapping': {'fall': 'Falling', 'fallen': 'Fallen', 'other_activities': 'ADL'},
        'model_and_predictions_changed': False, 'training': False, 'threshold_tuning': False,
        'event_matching': 'Preserved historical policy: first alarm at/after source-time onset through video end; subsequent alarms are duplicates',
        'exposure': 'Continuous annotated first-fall onset in seconds for fall videos; native video duration for no-fall videos. Differs from historical integer-frame rounding.',
        'framewise_unlabelled_or_overlapping_intervals': 'Recorded explicitly; no default ADL filling and no frame metric computed in this stage',
        'boundary_issue_counts': dict(collections.Counter(r['issue'] for r in boundary_issues)),
        'boundary_issue_files': len({r['sequence_id'] for r in boundary_issues}),
        'candidate_input_hashes': hashes, 'evaluator_sha256': digest(evpath),
        'role': 'Revision-period unified reannotation analysis; not a new blind test or complete submission package',
        'verifier_retrained': False,
    }
    (OUT / 'protocol.json').write_text(json.dumps(protocol, indent=2), encoding='utf-8')
    print(json.dumps({'protocol': protocol, 'metrics': summaries}, indent=2))


if __name__ == '__main__':
    main()
