"""Audit original-environment retraining and conditional video-bootstrap CIs."""
from pathlib import Path
import csv
import hashlib
import json
import numpy as np
from server_frame_bootstrap import batched_ap

ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / 'work/server_label_correction_import_20261012/verifier_v1'
LOCAL = ROOT / 'work/le2i_label_basis_audit/omnifall_unified_v1/verifier_retraining_v1'
OUT = SERVER / 'post_training_statistics_v1'
REPS, SEED = 10000, 20261004
NAMES = ('precision', 'recall_sensitivity', 'specificity', 'f1', 'balanced_accuracy', 'auroc', 'average_precision')


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def write(path, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def ratio(a, b):
    return np.divide(a, b, out=np.full_like(a, np.nan, dtype=float), where=b > 0)


def weighted_auc(y, score, groups, weights):
    assert len(np.unique(score)) == len(score), 'Handle tied scores explicitly before using this no-tie AUC calculation'
    order = np.argsort(score)
    target = y[order]
    group = groups[order]
    result = []
    for start in range(0, len(weights), 128):
        w = weights[start:start + 128, group]
        positive, negative = w * target, w * (1 - target)
        numerator = (positive * np.cumsum(negative, axis=1)).sum(axis=1)
        result.extend(ratio(numerator, positive.sum(axis=1) * negative.sum(axis=1)))
    return np.asarray(result)


def main():
    if OUT.exists():
        raise RuntimeError(f'Preserve existing statistics: {OUT}')
    protocol = json.loads((SERVER / 'protocol.json').read_text())
    reproduction = json.loads((SERVER / 'historical_reproduction_audit.json').read_text())
    assert protocol['environment']['numpy'] == '1.26.4'
    assert protocol['environment']['python'].startswith('3.9.25')
    assert '/.conda/envs/yolo/' in protocol['environment']['python_executable']
    assert all(x == 0 for x in reproduction['max_oof_probability_errors'].values())
    assert reproduction['threshold_error'] == 0 and reproduction['folds_match'] and reproduction['selected_configuration_matches']
    assert protocol['gmdcsa24_read'] is False and protocol['new_blind_test_performed'] is False
    source = Path('E:/FFFfall/train_multidataset_alarm_verifier_v2.py')
    assert hashlib.sha256(source.read_bytes()).hexdigest() == protocol['trainer_sha256']
    supplied = ROOT / 'work/le2i_label_basis_audit/omnifall_unified_v1/corrected_verifier_input_v1/alarm_confirmation_features_corrected.csv'
    assert hashlib.sha256(supplied.read_bytes()).hexdigest() == protocol['input_sha256']
    server_rows = read(SERVER / 'corrected_labels/oof_predictions.csv')
    local = {r['candidate_key']: r for r in read(LOCAL / 'corrected_labels/oof_predictions.csv')}
    assert len(server_rows) == len(local) == 281
    summary = json.loads((SERVER / 'corrected_labels/summary.json').read_text())
    local_summary = json.loads((LOCAL / 'corrected_labels/summary.json').read_text())
    configs = list(summary['feature_configuration_comparison'])
    errors = {}
    for config in configs:
        field = config + '_oof_probability'
        errors[config] = max(abs(float(r[field]) - float(local[r['candidate_key']][field])) for r in server_rows)
        assert errors[config] < 1e-12
    assert all(all(r[f] == local[r['candidate_key']][f] for f in ('dataset', 'sequence_id', 'sample_index', 'label_true_alarm', 'fold')) for r in server_rows)
    assert summary['selected_feature_configuration'] == local_summary['selected_feature_configuration']
    y = np.array([int(r['label_true_alarm']) for r in server_rows])
    dataset = np.array([r['dataset'] for r in server_rows])
    keys = [r['dataset'] + '::' + r['sequence_id'] for r in server_rows]
    ids = sorted(set(keys))
    assert len(ids) == 209 and set(dataset) == {'Le2i', 'URFD'}
    lookup = {k: i for i, k in enumerate(ids)}
    groups = np.array([lookup[k] for k in keys])
    for group in ids:
        assert len({r['fold'] for r, k in zip(server_rows, keys) if k == group}) == 1
    draws = np.random.default_rng(SEED).integers(len(ids), size=(REPS, len(ids)))
    weights = np.array([np.bincount(draw, minlength=len(ids)) for draw in draws])
    output = []
    for config in configs:
        item = summary['feature_configuration_comparison'][config]
        scores = np.array([float(r[config + '_oof_probability']) for r in server_rows])
        threshold = item['selected_threshold']
        for scope in ('overall', 'Le2i', 'URFD'):
            mask = np.ones(len(y), bool) if scope == 'overall' else dataset == scope
            truth, score, group = y[mask], scores[mask], groups[mask]
            pred = score >= threshold
            cells = np.stack([np.bincount(group, weights=cell, minlength=len(ids)) for cell in
                              ((truth == 1) & pred, (truth == 0) & pred,
                               (truth == 0) & ~pred, (truth == 1) & ~pred)], axis=1)
            tp, fp, tn, fn = (weights @ cells).T
            recall, specificity = ratio(tp, tp + fn), ratio(tn, tn + fp)
            values = [ratio(tp, tp + fp), recall, specificity,
                      ratio(2 * tp, 2 * tp + fp + fn), (recall + specificity) / 2,
                      weighted_auc(truth, score, group, weights), batched_ap(truth, score, group, weights)]
            point = item['grouped_oof']['overall'] if scope == 'overall' else item['grouped_oof']['by_dataset'][scope]
            counts = cells.sum(axis=0).astype(int)
            assert list(counts) == [point[k] for k in ('tp', 'fp', 'tn', 'fn')]
            # Independent all-unit-weight AUC/AP checks against trainer output.
            unit = np.ones((1, len(ids)))
            assert abs(weighted_auc(truth, score, group, unit)[0] - point['auroc']) < 1e-12
            assert abs(batched_ap(truth, score, group, unit)[0] - point['average_precision']) < 1e-12
            for metric, samples in zip(NAMES, values):
                finite = samples[np.isfinite(samples)]
                assert len(finite) == REPS
                output.append({'configuration': config, 'feature_count': item['feature_count'],
                               'scope': scope, 'metric': metric, 'estimate': point[metric],
                               'ci_low': np.percentile(finite, 2.5), 'ci_high': np.percentile(finite, 97.5),
                               'threshold': threshold, 'candidates': int(mask.sum()),
                               'sequence_groups': len(set(group)), 'resamples': REPS,
                               'finite_resamples': len(finite)})
    OUT.mkdir()
    write(OUT / 'verifier_oof_intervals.csv', output)
    audit = {'server_environment_verified': True, 'historical_control_exact': True,
             'source_trainer_and_input_hashes_match': True, 'all_corrected_oof_keys_labels_and_folds_match_local': True,
             'corrected_oof_probability_max_errors': errors,
             'selected_configuration': summary['selected_feature_configuration'],
             'bootstrap': {'unit': 'dataset::complete_video', 'resamples': REPS, 'seed': SEED,
                           'sampling': 'pooled 209 groups with replacement; same draws for all configurations/scopes',
                           'scope': 'fixed OOF scores and selected thresholds; models and selection not refit inside resamples',
                           'limitations': 'conditional descriptive intervals; selection optimism remains, and videos may share subjects/cameras; degenerate intervals do not establish zero population error'},
             'member_sha256': {str(p.relative_to(SERVER)): hashlib.sha256(p.read_bytes()).hexdigest() for p in SERVER.rglob('*') if p.is_file() and OUT not in p.parents},
             'downloaded_archive_sha256': hashlib.sha256((ROOT / 'verifier_v1_results.tar.gz').read_bytes()).hexdigest()}
    (OUT / 'server_validation_and_statistics_protocol.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
    print(json.dumps({'audit': audit, 'selected_overall_intervals': [r for r in output if r['configuration'] == summary['selected_feature_configuration'] and r['scope'] == 'overall']}, indent=2))


if __name__ == '__main__':
    main()
