"""Verify downloaded server GMD retrospective outputs, identities and intervals."""
from pathlib import Path
import csv
import hashlib
import json
import numpy as np
from recompute_le2i_sampling_image_studies import boot_median, ratio
from corrected_fusion_event_statistics import mcnemar_p, permutation, holm

ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / 'work/server_label_correction_import_20261012/corrected_verifier_gmd_retrospective_v1'
OUT = SERVER / 'audit_statistics_v1'
LABEL_PATH = ROOT / 'work/gmdcsa24_server_import_20261009/gmdcsa24_final_blind_evaluation_v1/annotation_audit.csv'
STAGES = ('historical_base', 'historical_primary', 'historical_final', 'corrected_verifier_retrospective')
REPS, SEED = 10000, 20261004


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def write(path, rows):
    if rows:
        with path.open('w', encoding='utf-8-sig', newline='') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)


def main():
    if OUT.exists():
        raise RuntimeError(f'Preserve previous audit: {OUT}')
    protocol = json.loads((SERVER / 'protocol.json').read_text())
    locked = protocol['model_threshold_and_input_hashes_locked_before_test_scoring']
    model_path = ROOT / 'work/server_label_correction_import_20261012/verifier_v1/corrected_labels/model.json'
    assert hashlib.sha256(model_path.read_bytes()).hexdigest() == locked['model']
    assert hashlib.sha256(LABEL_PATH.read_bytes()).hexdigest() == locked['annotations']
    assert protocol['historical_metric_reproduction_passed'] and not protocol['test_used_for_training_or_threshold_choice']
    assert protocol['environment']['numpy'] == '1.26.4' and protocol['environment']['python'].startswith('3.9.25')
    labels = {r['sequence_id']: r for r in read(LABEL_PATH)}
    ids = sorted(labels)
    lookup = {sid: i for i, sid in enumerate(ids)}
    assert len(ids) == 160 and sum(r['category'] == 'Fall' for r in labels.values()) == 79
    flags = np.array([labels[sid]['category'] == 'Fall' for sid in ids], int)
    exposure = np.array([min(float(labels[sid]['fall_onset_seconds']), float(labels[sid]['actual_duration_seconds']))
                         if flags[i] else float(labels[sid]['actual_duration_seconds']) for i, sid in enumerate(ids)]) / 3600
    summary = json.loads((SERVER / 'summary.json').read_text())
    draws = np.random.default_rng(SEED).integers(160, size=(REPS, 160))
    weights = np.array([np.bincount(draw, minlength=160) for draw in draws])
    matrices, boot, points, event_maps, alarm_maps = {}, {}, {}, {}, {}
    intervals, operating, subject_rows = [], [], []
    for stage in STAGES:
        events = {r['sequence_id']: r for r in read(SERVER / (stage + '_event_results.csv'))}
        alarms = {r['candidate_key']: r for r in read(SERVER / (stage + '_classified_alarms.csv'))}
        assert set(events) == set(ids)
        detected = np.array([int(events[sid]['detected']) if flags[i] else 0 for i, sid in enumerate(ids)])
        false = np.array([int(events[sid]['false_alarms_before_onset_or_in_adl']) for sid in ids])
        delay_ids = [i for i, sid in enumerate(ids) if detected[i]]
        delays = np.array([float(events[ids[i]]['detection_delay_ms']) / 1000 for i in delay_ids])
        metric = summary[stage]
        assert int(detected.sum()) == metric['detected_fall_events']
        assert int(false.sum()) == metric['false_alarm_count'] and len(alarms) == metric['total_alarm_rows']
        assert abs(exposure.sum() - metric['negative_exposure_hours']) < 1e-12
        assert abs(np.mean(delays) * 1000 - metric['mean_detection_delay_ms']) < 1e-9
        assert abs(np.median(delays) * 1000 - metric['median_detection_delay_ms']) < 1e-9
        matrices[stage], event_maps[stage], alarm_maps[stage] = (detected, false), events, alarms
        point = {'recall': detected.sum() / flags.sum(), 'fa_per_hour': false.sum() / exposure.sum(),
                 'precision': detected.sum() / (detected.sum() + false.sum()), 'median_delay_s': np.median(delays)}
        tp, fp = weights @ detected, weights @ false
        boot[stage] = {'recall': ratio(tp, weights @ flags), 'fa_per_hour': ratio(fp, weights @ exposure),
                       'precision': ratio(tp, tp + fp), 'median_delay_s': boot_median(delays, weights[:, delay_ids])}
        points[stage] = point
        operating.append({'stage': stage, 'detected': int(detected.sum()), 'events': 79,
                          'false_alarms': int(false.sum()), 'exposure_h': float(exposure.sum()), **point})
        for key, values in boot[stage].items():
            assert np.isfinite(values).all()
            intervals.append({'stage': stage, 'metric': key, 'estimate': point[key],
                              'ci_low': np.percentile(values, 2.5), 'ci_high': np.percentile(values, 97.5),
                              'resamples': REPS, 'videos': 160, 'subjects': 4})
        for subject in sorted({r['subject'] for r in labels.values()}):
            mask = np.array([labels[sid]['subject'] == subject for sid in ids])
            tp_sub, fp_sub = int(detected[mask].sum()), int(false[mask].sum())
            nfall, neg_h = int(flags[mask].sum()), float(exposure[mask].sum())
            subject_rows.append({'stage': stage, 'subject': subject, 'videos': int(mask.sum()),
                                 'events': nfall, 'detected': tp_sub, 'false_alarms': fp_sub,
                                 'negative_exposure_h': neg_h, 'recall': tp_sub / nfall,
                                 'fa_per_hour': fp_sub / neg_h})
    revised = 'corrected_verifier_retrospective'
    effects, comparisons = [], {}
    for reference in ('historical_primary', 'historical_final'):
        d = matrices[revised][0] - matrices[reference][0]
        lost, gained = int((d == -1).sum()), int((d == 1).sum())
        p_alarm, test = permutation(matrices[revised][1] - matrices[reference][1])
        comparisons[reference] = {'shared_detected': int(((matrices[revised][0] == 1) & (matrices[reference][0] == 1)).sum()),
                                 'new_only_detected': gained, 'old_only_detected': lost,
                                 'shared_accepted_candidates': len(set(alarm_maps[revised]) & set(alarm_maps[reference])),
                                 'new_only_accepted_candidates': len(set(alarm_maps[revised]) - set(alarm_maps[reference])),
                                 'old_only_accepted_candidates': len(set(alarm_maps[reference]) - set(alarm_maps[revised]))}
        for key in boot[revised]:
            diff = boot[revised][key] - boot[reference][key]
            effects.append({'comparison': revised + ' minus ' + reference, 'metric': key,
                            'difference': points[revised][key] - points[reference][key],
                            'ci_low': np.percentile(diff, 2.5), 'ci_high': np.percentile(diff, 97.5),
                            'p_raw': mcnemar_p(lost, gained) if key == 'recall' else p_alarm if key == 'fa_per_hour' else '',
                            'p_holm': '', 'test': 'exact McNemar' if key == 'recall' else test if key == 'fa_per_hour' else 'descriptive paired bootstrap'})
    for key in ('recall', 'fa_per_hour'):
        family = [r for r in effects if r['metric'] == key]
        for row, adjusted in zip(family, holm([r['p_raw'] for r in family])):
            row['p_holm'] = float(adjusted)
    event_changes = []
    for sid in ids:
        if labels[sid]['category'] != 'Fall':
            continue
        row = {k: labels[sid][k] for k in ('sequence_id', 'subject', 'source_relative_path', 'fall_onset_seconds')}
        for stage in STAGES:
            row[stage + '_detected'] = event_maps[stage][sid]['detected']
            row[stage + '_delay_ms'] = event_maps[stage][sid]['detection_delay_ms']
        event_changes.append(row)
    alarm_changes = []
    for key in sorted(set(alarm_maps[revised]) | set(alarm_maps['historical_final'])):
        a, b = alarm_maps[revised].get(key), alarm_maps['historical_final'].get(key)
        alarm_changes.append({'candidate_key': key, 'old_final_accepted': int(b is not None),
                              'corrected_accepted': int(a is not None),
                              'old_classification': b['classification'] if b else '',
                              'new_classification': a['classification'] if a else ''})
    prediction_rows = read(SERVER / 'corrected_verifier_predictions.csv')
    assert len(prediction_rows) == 110
    accepted_keys = {r['candidate_key'] for r in prediction_rows if int(r['accepted'])}
    assert accepted_keys == set(alarm_maps[revised])
    grouped = {}
    for row in prediction_rows:
        grouped.setdefault(row['sequence_id'], []).append(row)
    miss_rows = []
    for sid in ids:
        if labels[sid]['category'] != 'Fall' or event_maps[revised][sid]['detected'] == '1':
            continue
        candidates = grouped.get(sid, [])
        accepted = [r for r in candidates if int(r['accepted'])]
        reason = 'no_base_candidate' if not candidates else 'all_candidates_rejected' if not accepted else 'accepted_candidates_only_before_onset'
        miss_rows.append({'sequence_id': sid, 'subject': labels[sid]['subject'],
                          'source_relative_path': labels[sid]['source_relative_path'], 'decision_stage': reason,
                          'base_candidates': len(candidates), 'accepted_candidates': len(accepted),
                          'historical_final_detected': event_maps['historical_final'][sid]['detected']})
    assert len(miss_rows) == 19
    OUT.mkdir()
    for name, rows in [('operating_points.csv', operating), ('event_intervals.csv', intervals),
                       ('paired_effects.csv', effects), ('subject_metrics.csv', subject_rows),
                       ('fall_event_comparison.csv', event_changes), ('accepted_alarm_comparison.csv', alarm_changes),
                       ('corrected_miss_stage_audit.csv', miss_rows)]:
        write(OUT / name, rows)
    from collections import Counter
    audit = {'downloaded_server_protocol_verified': True, 'original_environment_verified': True,
             'all_stage_counts_delays_and_exposure_recomputed': True,
             'comparison_sets': comparisons, 'corrected_miss_stage_counts': dict(Counter(r['decision_stage'] for r in miss_rows)),
             'bootstrap': {'unit': 'complete video', 'resamples': REPS, 'seed': SEED, 'paired': True,
                           'limitations': 'four shared subjects; video intervals are conditional and do not establish subject-population confidence; revised model evaluated retrospectively'},
             'holm_families': 'two exploratory comparisons per metric, recall and alarm counts separately',
             'input_member_hashes': {str(p.relative_to(SERVER)): hashlib.sha256(p.read_bytes()).hexdigest() for p in SERVER.rglob('*') if p.is_file() and OUT not in p.parents},
             'downloaded_archive_sha256': hashlib.sha256((ROOT / 'corrected_verifier_gmd_retrospective_v1.tar.gz').read_bytes()).hexdigest()}
    (OUT / 'audit_protocol.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
    print(json.dumps({'audit': audit, 'corrected_intervals': [r for r in intervals if r['stage'] == revised],
                      'corrected_subject_metrics': [r for r in subject_rows if r['stage'] == revised]}, indent=2))


if __name__ == '__main__':
    main()
