"""URFD unchanged and unified Le2i fusion event bootstrap/paired comparisons."""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import math
from collections import defaultdict
import numpy as np
from recompute_le2i_sampling_image_studies import boot_median, ratio

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'outputs/revision_submission_final_v11'
LABELS = ROOT / 'work/le2i_label_basis_audit/omnifall_unified_v1'
OUT = LABELS / 'fusion_event_statistics_v2'
REPS, SEED = 10000, 20261004
VARIANTS = ('pose_branch_only', 'rgb_branch_only', 'fixed_0.5_late_logit',
            'quality_gated_late_logit', 'analytic_probability', 'analytic_logit')
COMPARISONS = ('quality_gated_late_logit', 'analytic_probability', 'analytic_logit')
METRICS = ('recall', 'fa_per_hour', 'precision', 'median_delay_s')


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def write(path, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def mcnemar_p(b, c):
    n = b + c
    return min(1.0, 2 * sum(math.comb(n, k) for k in range(min(b, c) + 1)) / 2**n) if n else 1.0


def permutation(diff):
    d = np.asarray(diff, int)
    d = d[d != 0]
    if not len(d):
        return 1.0, 'no discordant sequences'
    observed = abs(int(d.sum()))
    # Integer alarm differences permit exact enumeration of the sum distribution
    # by dynamic programming, even when direct 2**n enumeration is impractical.
    distribution = {0: 1}
    for value in d:
        next_distribution = defaultdict(int)
        for total, count in distribution.items():
            next_distribution[total + int(value)] += count
            next_distribution[total - int(value)] += count
        distribution = next_distribution
    extreme = sum(count for total, count in distribution.items() if abs(total) >= observed)
    return extreme / 2**len(d), 'exact paired sign-flip via integer-sum dynamic programming'


def holm(ps):
    ps = np.array(ps, float)
    order = np.argsort(ps)
    adjusted = np.maximum.accumulate(ps[order] * (len(ps) - np.arange(len(ps))))
    result = np.empty(len(ps))
    result[order] = np.minimum(adjusted, 1)
    return result


def exposures_from_urfd(path):
    result = {}
    for row in read(path):
        sid = row['sequence_id']
        result.setdefault(sid, 0.0)
        if row['target_state_id'] == '0':
            result[sid] += 1 / 20 / 3600
    return result


def main():
    if OUT.exists():
        raise RuntimeError(f'Preserve previous statistics: {OUT}')
    spec = importlib.util.spec_from_file_location('fusion_event_eval', BASE / 'scripts/external_fusion_ablation_urfd_le2i_v1.py')
    ev = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ev)
    OUT.mkdir()
    operating, intervals, effects, source_hashes = [], [], [], {}
    for dataset in ('URFD', 'Le2i'):
        if dataset == 'Le2i':
            inv = {r['sequence_id']: r for r in read(LABELS / 'video_inventory.csv')}
            events = {r['sequence_id']: {'onset_ms': float(r['onset_s']) * 1000} for r in read(LABELS / 'fall_events.csv')}
            exposure = {sid: float(r['negative_exposure_seconds']) / 3600 for sid, r in inv.items()}
        else:
            path = BASE / 'evidence/input/urfd_frame_predictions.csv'
            rows = read(path)
            inv, events, _, _ = ev.load_urfd_ground_truth(rows, BASE / 'evidence/matched_operator_control/input/urfd_events.csv')
            exposure = exposures_from_urfd(path)
        ids = sorted(inv)
        lookup = {sid: i for i, sid in enumerate(ids)}
        hours = np.array([exposure[sid] for sid in ids])
        flags = np.array([sid in events for sid in ids], int)
        draws = np.random.default_rng(SEED).integers(len(ids), size=(REPS, len(ids)))
        weights = np.array([np.bincount(x, minlength=len(ids)) for x in draws])
        matrices, points, boot = {}, {}, {}
        for variant in VARIANTS:
            if variant.startswith('analytic'):
                source = BASE / 'evidence/matched_operator_control' / dataset.lower() / variant / 'candidate_alarms.csv'
            else:
                source = BASE / 'evidence/input/server/external_fusion_ablation_urfd_le2i_server_v3' / dataset.lower() / variant / 'candidate_alarms.csv'
            alarms = read(source)
            metric, classified, per_event = ev.evaluate_events(alarms, inv, events, float(hours.sum()))
            dest = OUT / dataset.lower() / variant
            dest.mkdir(parents=True)
            write(dest / 'classified_alarms.csv', classified)
            write(dest / 'event_results.csv', per_event)
            detected, false = np.zeros(len(ids)), np.zeros(len(ids))
            delay_ids, delays = [], []
            for row in per_event:
                detected[lookup[row['sequence_id']]] = int(row['detected'])
                if row['detected']:
                    delay_ids.append(lookup[row['sequence_id']])
                    delays.append(float(row['detection_delay_ms']) / 1000)
            for row in classified:
                if row['alarm_classification'].startswith('false_alarm'):
                    false[lookup[row['sequence_id']]] += 1
            tp, fp = weights @ detected, weights @ false
            boot[variant] = np.column_stack((ratio(tp, weights @ flags), ratio(fp, weights @ hours),
                                           ratio(tp, tp + fp), boot_median(np.array(delays), weights[:, delay_ids])))
            point = np.array([metric['event_recall'], metric['false_alarms_per_hour'],
                              metric['detected_fall_events'] / (metric['detected_fall_events'] + metric['false_alarm_count']),
                              metric['median_detection_delay_s']])
            points[variant], matrices[variant] = point, (detected, false)
            operating.append({'dataset': dataset, 'variant': variant, 'events': len(events),
                              'detected': metric['detected_fall_events'], 'false_alarms': metric['false_alarm_count'],
                              'negative_exposure_hours': float(hours.sum()), **dict(zip(METRICS, point))})
            for k, key in enumerate(METRICS):
                samples = boot[variant][:, k]
                assert np.isfinite(samples).all()
                intervals.append({'dataset': dataset, 'variant': variant, 'metric': key,
                                  'estimate': point[k], 'ci_low': np.percentile(samples, 2.5),
                                  'ci_high': np.percentile(samples, 97.5), 'resamples': REPS})
            source_hashes[str(source.relative_to(ROOT))] = hashlib.sha256(source.read_bytes()).hexdigest()
        fixed = 'fixed_0.5_late_logit'
        for variant in COMPARISONS:
            d = matrices[variant][0] - matrices[fixed][0]
            fixed_only, other_only = int((d == -1).sum()), int((d == 1).sum())
            discordant = fixed_only + other_only
            p_recall = mcnemar_p(fixed_only, other_only)
            p_alarm, test = permutation(matrices[variant][1] - matrices[fixed][1])
            for k, metric in enumerate(METRICS):
                diff = boot[variant][:, k] - boot[fixed][:, k]
                effects.append({'dataset': dataset, 'comparison': variant + ' minus ' + fixed,
                                'metric': metric, 'difference': points[variant][k] - points[fixed][k],
                                'ci_low': np.percentile(diff, 2.5), 'ci_high': np.percentile(diff, 97.5),
                                'relative_change_percent': 100 * (points[variant][k] / points[fixed][k] - 1) if points[fixed][k] else '',
                                'p_raw': p_recall if metric == 'recall' else p_alarm if metric == 'fa_per_hour' else '',
                                'p_holm': '', 'test': 'exact McNemar' if metric == 'recall' else test if metric == 'fa_per_hour' else 'descriptive paired bootstrap',
                                'fixed_only_events': fixed_only, 'other_only_events': other_only})
        print(dataset, 'six variants complete', flush=True)
    for metric in ('recall', 'fa_per_hour'):
        family = [r for r in effects if r['metric'] == metric]
        assert len(family) == 6
        for row, adjusted in zip(family, holm([r['p_raw'] for r in family])):
            row['p_holm'] = float(adjusted)
    write(OUT / 'operating_points.csv', operating)
    write(OUT / 'event_intervals.csv', intervals)
    write(OUT / 'paired_effects.csv', effects)
    protocol = {'labels': 'URFD unchanged; Le2i full fixed OmniFall revision',
                'unit': 'complete video', 'resamples': REPS, 'seed': SEED,
                'comparisons_prelisted': list(COMPARISONS), 'reference': 'fixed_0.5_late_logit',
                'holm_families': 'separate recall/alarm families; each includes 3 comparisons x 2 datasets',
                'test_meaning': 'exact paired event detection test; symmetric sign-flip test on per-video alarm-count differences',
                'intervals': 'pointwise 95% percentile; delay conditional on detected events, sets can differ',
                'analytic_logit_control': 'same logit aggregation and epsilon 1e-12 as fixed; q=clip(pose_found_ratio*mean_keypoint_conf,0,1)',
                'sampling_or_training_or_tuning_changed': False, 'candidate_stage_only': True,
                'exposure': 'URFD original sampled negative endpoints; Le2i continuous annotated onset/full no-fall duration',
                'limitations': 'source labels and grouping conditional; subject/camera correlation and training variability not removed',
                'input_hashes': source_hashes}
    (OUT / 'protocol.json').write_text(json.dumps(protocol, indent=2), encoding='utf-8')
    print(json.dumps({'operating_points': operating, 'formal_comparisons': [r for r in effects if r['metric'] in ('recall','fa_per_hour')]}, indent=2))


if __name__ == '__main__':
    main()
