"""Map source-time frozen prediction endpoints, preserving unknown labels."""
from pathlib import Path
import collections
import csv
import json

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'work/le2i_label_basis_audit/omnifall_unified_v1'
PRED = ROOT / 'outputs/revision_submission_final_v11/evidence/matched_operator_control/input/le2i_frame_predictions.csv'


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def main():
    dest = OUT / 'frozen_endpoint_targets.csv'
    if dest.exists():
        raise RuntimeError(f'Preserve existing output: {dest}')
    groups = collections.defaultdict(list)
    for row in read(OUT / 'mapped_segments.csv'):
        groups[row['sequence_id']].append(row)
    targets = []
    counts = collections.Counter()
    for row in read(PRED):
        time = float(row['source_timestamp_ms']) / 1000
        states = {int(s['target_state_id']) for s in groups[row['sequence_id']]
                  if float(s['start_s']) <= time < float(s['end_s'])}
        status = 'labelled' if len(states) == 1 else ('unlabelled' if not states else 'conflicting_overlap')
        state = next(iter(states)) if len(states) == 1 else -1
        counts[status] += 1
        counts['state_' + str(state)] += 1
        targets.append({'sequence_id': row['sequence_id'], 'sample_index': row['sample_index'],
                        'source_frame_number': row['source_frame_number'],
                        'source_timestamp_ms': row['source_timestamp_ms'],
                        'target_state_id': state, 'label_status': status})
    assert len(targets) == 58328 and len({r['sequence_id'] for r in targets}) == 190
    with dest.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(targets[0]))
        writer.writeheader()
        writer.writerows(targets)
    summary = {'endpoints': len(targets), 'videos': 190, 'counts': dict(counts),
               'interval_rule': 'half-open [start,end), source_timestamp_ms / 1000',
               'unknown_target': -1, 'unknown_handling': 'exclude from frame metrics, never silently label ADL',
               'same_mapped_state_overlap': 'unambiguous mapped state retained',
               'label_basis': 'full OmniFall fall and fallen segments; other labelled activities mapped to ADL',
               'difference_from_historical_binary_labels': 'Historical onset-through-end labels are not identical to fall/fallen segment union'}
    (OUT / 'endpoint_mapping_protocol.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
