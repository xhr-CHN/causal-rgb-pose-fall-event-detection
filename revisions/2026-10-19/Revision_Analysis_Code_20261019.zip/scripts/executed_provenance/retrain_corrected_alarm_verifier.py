"""Reproduce historical development CV before corrected-label CPU training."""
from pathlib import Path
import collections
import argparse
import csv
import hashlib
import importlib.util
import json
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'outputs/revision_submission_final_v11'
LABELS = ROOT / 'work/le2i_label_basis_audit/omnifall_unified_v1'
INPUT = LABELS / 'corrected_verifier_input_v1/alarm_confirmation_features_corrected.csv'
OUT = LABELS / 'verifier_retraining_v1'
TRAINER = Path('E:/FFFfall/train_multidataset_alarm_verifier_v2.py')
HISTORY = Path('E:/FFFfall/repro_release2/causal_rgb_pose_fall_event_detection_release_candidate_v1/results/multidataset_alarm_verifier_v2_seed42/summary.json')


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def write(path, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def run(trainer, rows, label_field, folder):
    y = np.array([int(r[label_field]) for r in rows])
    datasets = np.array([r['dataset'] for r in rows], object)
    groups = np.array([r['sequence_id'] for r in rows], object)
    folds, audit = trainer.make_group_folds(datasets, groups, y)
    assert len({r['dataset'] + '::' + r['sequence_id'] for r in rows}) == 209
    for dataset, group in set(zip(datasets, groups)):
        assert len(set(folds[(datasets == dataset) & (groups == group)])) == 1
    comparison, scores, matrices = {}, {}, {}
    for name, features in trainer.FEATURE_CONFIGS.items():
        x = np.array([[float(r[f]) for f in features] for r in rows])
        score, fold_metrics = trainer.grouped_oof(x, y, datasets, folds)
        assert np.isfinite(score).all()
        threshold, metrics = trainer.select_threshold(y, score, datasets)
        comparison[name] = {'feature_count': len(features), 'selected_threshold': threshold,
                            'grouped_oof': metrics, 'folds': fold_metrics,
                            'tied_score_rows': int(len(score) - len(np.unique(score)))}
        scores[name], matrices[name] = score, x
    selected = min(trainer.FEATURE_CONFIGS, key=lambda name: (
        comparison[name]['grouped_oof']['macro_fpr'],
        -comparison[name]['grouped_oof']['macro_average_precision'],
        len(trainer.FEATURE_CONFIGS[name]), name))
    mean, scale, beta, iterations = trainer.fit_final_model(matrices[selected], y, datasets)
    model = {'model_type': 'dataset_class_balanced_standardized_l2_logistic_regression',
             'model_version': 'revision_corrected_labels_v1' if label_field == 'label_true_alarm' else 'historical_reproduction_control',
             'selected_feature_configuration': selected,
             'feature_names': trainer.FEATURE_CONFIGS[selected], 'feature_mean': mean.tolist(),
             'feature_scale': scale.tolist(), 'intercept': float(beta[0]),
             'coefficients': beta[1:].tolist(),
             'decision_threshold': comparison[selected]['selected_threshold'],
             'l2_regularization': trainer.L2_REGULARIZATION,
             'confirmation_future_samples': trainer.CONFIRMATION_FUTURE_SAMPLES,
             'maximum_added_delay_ms': trainer.MAXIMUM_ADDED_DELAY_MS,
             'evaluation_role': 'development model; no independent new blind-test result',
             'positive_class': 'first true fall event alarm', 'negative_class': 'false, early, or duplicate alarm'}
    folder.mkdir()
    write(folder / 'group_fold_assignments.csv', audit)
    prediction_rows = []
    for i, row in enumerate(rows):
        item = {k: row[k] for k in ('candidate_key', 'dataset', 'sequence_id', 'sample_index')}
        item.update({'label_true_alarm': int(y[i]), 'fold': int(folds[i] + 1)})
        for name, score in scores.items():
            item[name + '_oof_probability'] = float(score[i])
            item[name + '_oof_prediction'] = int(score[i] >= comparison[name]['selected_threshold'])
        prediction_rows.append(item)
    write(folder / 'oof_predictions.csv', prediction_rows)
    summary = {'candidates': len(rows), 'positive_candidates': int(y.sum()),
               'negative_candidates': int(len(y) - y.sum()), 'groups': 209,
               'selected_feature_configuration': selected,
               'selected_threshold': comparison[selected]['selected_threshold'],
               'selected_grouped_oof': comparison[selected]['grouped_oof'],
               'feature_configuration_comparison': comparison,
               'final_iterations': iterations,
               'leave_one_dataset_out_diagnostics': trainer.leave_one_dataset_out(matrices[selected], y, datasets, groups),
               'limitations': 'feature and threshold selection use the same OOF results; grouped CV is not nested, and video groups do not imply subject independence'}
    for name, value in [('model.json', model), ('summary.json', summary)]:
        (folder / name).write_text(json.dumps(value, indent=2), encoding='utf-8')
    return summary, prediction_rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=INPUT)
    parser.add_argument('--output-dir', type=Path, default=OUT)
    parser.add_argument('--trainer', type=Path, default=TRAINER)
    parser.add_argument('--historical-summary', type=Path, default=HISTORY)
    parser.add_argument('--historical-oof', type=Path, default=BASE / 'evidence/final_verifier_oof_predictions.csv')
    args = parser.parse_args()
    if args.output_dir.exists():
        raise RuntimeError(f'Preserve existing run: {args.output_dir}')
    rows = read(args.input)
    assert len(rows) == 281 and {r['dataset'] for r in rows} == {'URFD', 'Le2i'}
    spec = importlib.util.spec_from_file_location('original_verifier_trainer', args.trainer)
    trainer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(trainer)
    args.output_dir.mkdir(parents=True)
    control, control_rows = run(trainer, rows, 'original_label_true_alarm', args.output_dir / 'historical_control')
    historical = {r['candidate_key']: r for r in read(args.historical_oof)}
    assert set(historical) == {r['candidate_key'] for r in control_rows}
    errors = {}
    for name in trainer.FEATURE_CONFIGS:
        field = name + '_oof_probability'
        errors[name] = max(abs(r[field] - float(historical[r['candidate_key']][field])) for r in control_rows)
    historical_summary = json.loads(args.historical_summary.read_text(encoding='utf-8'))
    audit = {'max_oof_probability_errors': errors,
             'folds_match': all(r['fold'] == int(historical[r['candidate_key']]['fold']) for r in control_rows),
             'selected_configuration_matches': control['selected_feature_configuration'] == historical_summary['selected_feature_configuration'],
             'threshold_error': abs(control['selected_threshold'] - historical_summary['selected_threshold'])}
    (args.output_dir / 'historical_reproduction_audit.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
    assert audit['folds_match'] and audit['selected_configuration_matches']
    assert max(errors.values()) <= 1e-10 and audit['threshold_error'] <= 1e-10, audit
    print('Historical OOF reproduction passed', json.dumps(audit), flush=True)
    corrected, _ = run(trainer, rows, 'label_true_alarm', args.output_dir / 'corrected_labels')
    protocol = {'label_source': 'fixed OmniFall revision in parent protocol.json',
                'cpu_training': True, 'gmdcsa24_read': False, 'new_blind_test_performed': False,
                'feature_configurations': {name: len(features) for name, features in trainer.FEATURE_CONFIGS.items()},
                'folds': trainer.NUM_FOLDS, 'seed': trainer.SEED,
                'grouping': 'dataset and complete video; rebalanced folds with corrected labels',
                'threshold_rule': {'global_recall_min': trainer.GLOBAL_TARGET_RECALL,
                                   'per_dataset_recall_min': trainer.PER_DATASET_MINIMUM_RECALL},
                'historical_control_passed': True,
                'trainer_sha256': hashlib.sha256(args.trainer.read_bytes()).hexdigest(),
                'input_sha256': hashlib.sha256(args.input.read_bytes()).hexdigest(),
                'historical_gmd_metrics_apply_only_to_historical_model': True}
    import platform, sys
    protocol['environment'] = {'python': sys.version, 'numpy': np.__version__,
                               'platform': platform.platform(), 'python_executable': sys.executable}
    (args.output_dir / 'protocol.json').write_text(json.dumps(protocol, indent=2), encoding='utf-8')
    print(json.dumps({'corrected_summary': corrected, 'output': str(args.output_dir)}, indent=2), flush=True)


if __name__ == '__main__':
    main()
