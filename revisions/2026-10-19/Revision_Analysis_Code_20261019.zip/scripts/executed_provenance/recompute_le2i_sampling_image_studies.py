"""Rescore existing server sampling/image caches with unified OmniFall truth."""
from pathlib import Path
import collections
import csv
import hashlib
import importlib.util
import json
import numpy as np
from server_frame_bootstrap import metrics

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'outputs/revision_submission_final_v11'
LABELS = ROOT / 'work/le2i_label_basis_audit/omnifall_unified_v1'
OUT = LABELS / 'sampling_image_recomputed_v2'
REPS, SEED = 10000, 20261004


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def write(path, rows):
    if rows:
        with path.open('w', encoding='utf-8-sig', newline='') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)


def ratio(a, b):
    return np.divide(a, b, out=np.full_like(a, np.nan, dtype=float), where=b > 0)


def boot_median(delays, weights):
    if not len(delays):
        return np.full(len(weights), np.nan)
    order = np.argsort(delays)
    d, w = delays[order], weights[:, order]
    cumulative, total = w.cumsum(axis=1), w.sum(axis=1)
    lower = np.argmax(cumulative > ((total - 1) // 2)[:, None], axis=1)
    upper = np.argmax(cumulative > (total // 2)[:, None], axis=1)
    result = (d[lower] + d[upper]) / 2
    result[total == 0] = np.nan
    return result


def main():
    if OUT.exists():
        raise RuntimeError(f'Preserve existing study: {OUT}')
    inv = {r['sequence_id']: r for r in read(LABELS / 'video_inventory.csv')}
    events = {r['sequence_id']: {'onset_ms': float(r['onset_s']) * 1000} for r in read(LABELS / 'fall_events.csv')}
    segments = collections.defaultdict(list)
    for row in read(LABELS / 'mapped_segments.csv'):
        segments[row['sequence_id']].append(row)
    ids = sorted(inv)
    lookup = {sid: i for i, sid in enumerate(ids)}
    negative_h = np.array([float(inv[sid]['negative_exposure_seconds']) / 3600 for sid in ids])
    fall_flags = np.array([sid in events for sid in ids], int)
    draws = np.random.default_rng(SEED).integers(190, size=(REPS, 190))
    weights = np.array([np.bincount(x, minlength=190) for x in draws])
    spec = importlib.util.spec_from_file_location('frozen_ev', BASE / 'scripts/external_fusion_ablation_urfd_le2i_v1.py')
    ev = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ev)
    studies = []
    sample_root = ROOT / 'work/server_import_20261008/revision_rerun_20261008/sampling_server_v3'
    for name in ('15hz_nearest', '20hz_nearest', '20hz_left_only', '25hz_nearest'):
        studies.append(('sampling', name, sample_root / name))
    image_root = ROOT / 'work/server_audit_import_20261010/experiments/revision_additional_20261009/image_stress_v2_full/inference'
    for name in ('identity', 'dark05', 'bright15', 'half_resolution', 'rotate_minus8', 'rotate_plus8'):
        studies.append(('image_stress', name, image_root / name))
    for _, _, folder in studies:
        assert (folder / 'frame_predictions.csv').is_file() and (folder / 'candidate_alarms.csv').is_file()
    OUT.mkdir()
    operating, intervals, frame_rows, hashes = [], [], [], {}
    event_boot = {}
    for study, name, folder in studies:
        rows = read(folder / 'frame_predictions.csv')
        alarms = read(folder / 'candidate_alarms.csv')
        assert {r['sequence_id'] for r in rows} == set(inv)
        metric, classified, per_event = ev.evaluate_events(alarms, inv, events, float(negative_h.sum()))
        result_folder = OUT / study / name
        result_folder.mkdir(parents=True)
        write(result_folder / 'classified_alarms.csv', classified)
        write(result_folder / 'event_results.csv', per_event)
        detected = np.zeros(190)
        false = np.zeros(190)
        delay_ids, delays = [], []
        for row in per_event:
            detected[lookup[row['sequence_id']]] = int(row['detected'])
            if row['detected']:
                delay_ids.append(lookup[row['sequence_id']])
                delays.append(float(row['detection_delay_ms']) / 1000)
        for row in classified:
            if row['alarm_classification'].startswith('false_alarm'):
                false[lookup[row['sequence_id']]] += 1
        tp, fp = weights @ detected, weights @ false
        samples = {'event_recall': ratio(tp, weights @ fall_flags),
                   'fa_per_hour': ratio(fp, weights @ negative_h),
                   'event_precision': ratio(tp, tp + fp),
                   'median_delay_s': boot_median(np.array(delays), weights[:, delay_ids])}
        point = {'event_recall': metric['event_recall'], 'fa_per_hour': metric['false_alarms_per_hour'],
                 'event_precision': metric['detected_fall_events'] / (metric['detected_fall_events'] + metric['false_alarm_count']),
                 'median_delay_s': metric['median_detection_delay_s']}
        operating.append({'study': study, 'configuration': name, 'events': 130,
                          'detected': metric['detected_fall_events'], 'false_alarms': metric['false_alarm_count'],
                          'negative_exposure_hours': float(negative_h.sum()), **point})
        event_boot[(study, name)] = (point, samples)
        for key, values in samples.items():
            finite = values[np.isfinite(values)]
            assert len(finite) == REPS
            intervals.append({'study': study, 'configuration': name, 'metric': key,
                              'estimate': point[key], 'ci_low': np.percentile(finite, 2.5),
                              'ci_high': np.percentile(finite, 97.5), 'finite_resamples': len(finite)})
        target = []
        for row in rows:
            timestamp = float(row['source_timestamp_ms']) / 1000
            states = {int(s['target_state_id']) for s in segments[row['sequence_id']]
                      if float(s['start_s']) <= timestamp < float(s['end_s'])}
            target.append(next(iter(states)) if len(states) == 1 else -1)
        target = np.array(target)
        mask = target >= 0
        prob = ev.probability_matrix(rows, 'gated')[mask]
        for truth_name, truth in [('fall_or_fallen', target[mask] != 0), ('fall_only_reference', target[mask] == 1)]:
            f1, ap = metrics(truth.astype(int), prob, np.ones(mask.sum()))
            frame_rows.append({'study': study, 'configuration': name, 'truth_definition': truth_name,
                               'binary_macro_f1': f1, 'binary_macro_auprc': ap,
                               'endpoints': len(rows), 'labelled_endpoints': int(mask.sum()),
                               'excluded_endpoints': int((~mask).sum())})
        for filename in ('frame_predictions.csv', 'candidate_alarms.csv'):
            p = folder / filename
            hashes[str(p.relative_to(ROOT))] = hashlib.sha256(p.read_bytes()).hexdigest()
        print(study, name, 'done', flush=True)
    effects = []
    for (study, name), (point, samples) in event_boot.items():
        ref_name = 'identity' if study == 'image_stress' else '20hz_nearest'
        if name == ref_name:
            continue
        ref_point, ref_samples = event_boot[(study, ref_name)]
        for metric in samples:
            diff = samples[metric] - ref_samples[metric]
            effects.append({'study': study, 'comparison': name + ' minus ' + ref_name,
                            'metric': metric, 'difference': point[metric] - ref_point[metric],
                            'ci_low': np.percentile(diff, 2.5), 'ci_high': np.percentile(diff, 97.5)})
    write(OUT / 'event_operating_points.csv', operating)
    write(OUT / 'event_intervals.csv', intervals)
    write(OUT / 'paired_event_effects.csv', effects)
    write(OUT / 'frame_point_metrics.csv', frame_rows)
    protocol = {'label_source': 'fixed unified OmniFall revision in parent protocol.json',
                'source': 'existing original-server predictions and candidate alarms',
                'retraining': False, 'new_inference': False, 'threshold_tuning': False,
                'candidate_stage_only': True, 'new_verifier_applied': False,
                'bootstrap_unit': 'complete video', 'resamples': REPS, 'seed': SEED,
                'paired_draws_shared_for_all_configurations': True,
                'event_matching': 'historical first alarm at/after source-time onset through video end',
                'exposure': 'continuous first-fall onset or full native no-fall video duration; common denominator across configurations',
                'frame_unknown_intervals': 'excluded, never filled as ADL',
                'frame_prediction_and_score': 'same historical binary decision (three-state argmax != ADL) and fall+fallen score for both truth definitions',
                'probability_preprocessing': 'nonnegative probabilities renormalized to sum one using the original fusion evaluator, consistently with fusion bootstrap; this supersedes v1 raw-sum AP results',
                'fall_only_reference_role': 'tests original fall-interval concept under unified source; not a new falling-only classifier',
                'frame_confidence_intervals': 'not recomputed in this stage; event intervals provided',
                'limitations': 'conditional on reannotation; video groups can share subjects/cameras; sampling keeps sample counts fixed and changes physical windows; image transforms are synthetic',
                'input_hashes': hashes}
    (OUT / 'protocol.json').write_text(json.dumps(protocol, indent=2), encoding='utf-8')
    print(json.dumps(operating, indent=2))


if __name__ == '__main__':
    main()
