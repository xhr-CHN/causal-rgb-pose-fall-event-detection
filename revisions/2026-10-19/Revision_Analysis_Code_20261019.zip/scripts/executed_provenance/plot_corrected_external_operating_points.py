"""Compare frozen fusion sensitivity and alarm burden across two development sets."""
from pathlib import Path
import csv
import json
import sys
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'work/le2i_label_basis_audit/omnifall_unified_v1/fusion_event_statistics_v2'
PREFIX = ROOT / 'outputs/label_corrected_revision_20261012/manuscript_source/figures/corrected_external_operating_points'
sys.path.insert(0, 'C:/Users/xhr/.codex/skills/nature-figure/scripts')
from audit_panel_alignment import require_matplotlib_panel_alignment


def main():
    with (DATA / 'event_intervals.csv').open(encoding='utf-8-sig', newline='') as handle:
        records = list(csv.DictReader(handle))
    mpl.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'DejaVu Sans'],
                         'font.size': 7.5, 'axes.titlesize': 8, 'xtick.labelsize': 7, 'ytick.labelsize': 7,
                         'legend.fontsize': 7, 'legend.frameon': False, 'pdf.fonttype': 42, 'svg.fonttype': 'none',
                         'axes.spines.top': False, 'axes.spines.right': False, 'axes.linewidth': 0.7})
    fig, axes = plt.subplots(1, 2, figsize=(7.0866141732, 3.5433070866))
    fig.subplots_adjust(left=0.10, right=0.985, bottom=0.19, top=0.78, wspace=0.40)
    styles = [
        ('fixed_0.5_late_logit', 'Fixed logits', '#777777', 's', 5.5),
        ('pose_branch_only', 'Pose branch', '#56B4E9', 'D', 4.5),
        ('rgb_branch_only', 'RGB branch', '#CC79A7', 'd', 4.0),
        ('analytic_probability', 'Analytic probability', '#E69F00', '^', 4.5),
        ('analytic_logit', 'Analytic logits', '#009E73', 'v', 4.5),
        ('quality_gated_late_logit', 'Learned gate', '#0072B2', 'o', 5.0)]
    for ax, dataset, letter, title in zip(axes, ['URFD', 'Le2i'], ['a', 'b'], ['URFD', 'Le2i (reannotation)']):
        for variant, label, color, marker, size in styles:
            r = {x['metric']: x for x in records if x['dataset'] == dataset and x['variant'] == variant}
            assert len(r) == 4
            x, y = float(r['fa_per_hour']['estimate']), float(r['recall']['estimate'])
            xe = np.array([[x - float(r['fa_per_hour']['ci_low'])], [float(r['fa_per_hour']['ci_high']) - x]])
            ye = np.array([[y - float(r['recall']['ci_low'])], [float(r['recall']['ci_high']) - y]])
            ax.errorbar(x, y, xerr=xe, yerr=ye, color=color, marker=marker, markersize=size,
                        elinewidth=0.65, capsize=1.8, linestyle='none', label=label if dataset == 'URFD' else None)
        ax.set_ylim(0.70, 1.03)
        ax.set_xlim(0, 500 if dataset == 'URFD' else 300)
        ax.set_xlabel('False alarms per hour')
        ax.set_ylabel('Event recall')
        ax.set_title(title, loc='left', pad=12)
        ax.grid(color='#DDDDDD', linewidth=0.4)
        ax.annotate(letter, xy=(0, 1), xycoords='axes fraction', xytext=(-25, 12),
                    textcoords='offset points', fontsize=8, fontweight='bold', va='bottom')
    handles, names = axes[0].get_legend_handles_labels()
    fig.legend(handles, names, loc='upper center', bbox_to_anchor=(0.52, 0.985), ncol=3)
    fig.canvas.draw()
    require_matplotlib_panel_alignment(fig, json_out=str(PREFIX) + '.alignment.json',
        overlay_svg=str(PREFIX) + '.alignment.svg', tolerance_pt=1.5, gutter_tolerance_pt=1.5, strict=True)
    fig.savefig(str(PREFIX) + '.pdf')
    fig.savefig(str(PREFIX) + '.svg')
    fig.savefig(str(PREFIX) + '.png', dpi=600)
    fig.savefig(str(PREFIX) + '.tiff', dpi=600)
    contract = {'question': 'Does learned gating consistently improve candidate detection relative to fixed or analytic fusion?',
                'claim': 'No consistent cross-dataset advantage; analytic weighting also trades sensitivity and alarm burden',
                'archetype': 'quantitative grid', 'backend': 'Python/matplotlib',
                'data_points': 12, 'excluded_variants': 0, 'uncertainty': 'pointwise 95% complete-video percentile bootstrap, 10000 resamples',
                'panel_a': 'original URFD labels, 30 events', 'panel_b': 'fixed OmniFall Le2i labels, 130 events',
                'limits': 'different x-axis limits are used; exposure definitions differ between datasets; matched comparisons within each dataset only',
                'overlap': 'URFD RGB/fixed centers coincide and are both plotted',
                'source': 'event_intervals.csv and operating_points.csv in the unified fusion analysis'}
    PREFIX.with_suffix('.contract.json').write_text(json.dumps(contract, indent=2), encoding='utf-8')
    print(PREFIX)


if __name__ == '__main__':
    main()
