"""Unified Le2i frame intervals for matched probability/logit analytic controls."""
from pathlib import Path
import csv
import importlib.util
import json
import numpy as np
from server_frame_bootstrap import read, metrics, batched_ap

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'outputs/revision_submission_final_v11'
LABELS = ROOT / 'work/le2i_label_basis_audit/omnifall_unified_v1'
OUT = LABELS / 'analytic_frame_statistics_v1'
REPS, SEED = 10000, 20261004


def write(path, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    if OUT.exists():
        raise RuntimeError(f'Preserve existing results: {OUT}')
    rows = read(BASE / 'evidence/matched_operator_control/input/le2i_frame_predictions.csv')
    target = read(LABELS / 'frozen_endpoint_targets.csv')
    assert all(all(a[k] == b[k] for k in ('sequence_id', 'sample_index', 'source_frame_number')) for a, b in zip(rows, target)) and len(rows) == len(target) == 58328
    state = np.array([int(r['target_state_id']) for r in target])
    mask = state >= 0
    y = (state[mask] != 0).astype(int)
    ids = sorted({r['sequence_id'] for r in rows})
    lookup = {sid: i for i, sid in enumerate(ids)}
    groups = np.array([lookup[r['sequence_id']] for r, valid in zip(rows, mask) if valid])
    spec = importlib.util.spec_from_file_location('analytic_fusion_eval', BASE / 'scripts/external_fusion_ablation_urfd_le2i_v1.py')
    ev = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ev)
    pose, rgb = ev.probability_matrix(rows, 'pose'), ev.probability_matrix(rows, 'rgb')
    q = np.clip([float(r['pose_found_ratio']) * float(r['mean_keypoint_conf']) for r in rows], 0, 1)[:, None]
    logits = q * np.log(np.clip(pose, ev.EPSILON, 1)) + (1 - q) * np.log(np.clip(rgb, ev.EPSILON, 1))
    logits -= logits.max(axis=1, keepdims=True)
    exp = np.exp(logits)
    variants = {'fixed_logit': ev.fixed_equal_logit_fusion(pose, rgb),
                'analytic_probability': ev.normalize_probabilities(q * pose + (1 - q) * rgb, 'analytic_probability'),
                'analytic_logit': exp / exp.sum(axis=1, keepdims=True)}
    draws = np.random.default_rng(SEED).integers(len(ids), size=(REPS, len(ids)))
    weights = np.array([np.bincount(draw, minlength=len(ids)) for draw in draws])
    OUT.mkdir()
    output, values, points = [], {}, {}
    for name, full_prob in variants.items():
        prob = full_prob[mask]
        points[name] = metrics(y, prob, np.ones(len(y)))
        pred = prob.argmax(axis=1) != 0
        cells = np.stack([np.bincount(groups, weights=c, minlength=len(ids)) for c in
                          ((y == 1) & pred, (y == 0) & pred, (y == 0) & ~pred, (y == 1) & ~pred)], axis=1)
        tp, fp, tn, fn = (weights @ cells).T
        f1 = (2 * tp / (2 * tp + fp + fn) + 2 * tn / (2 * tn + fp + fn)) / 2
        score = np.clip(prob[:, 1] + prob[:, 2], 0, 1)
        ap = (batched_ap(y, score, groups, weights) + batched_ap(1 - y, 1 - score, groups, weights)) / 2
        values[name] = np.column_stack((f1, ap))
        assert np.isfinite(values[name]).all()
        for k, metric in enumerate(('binary_macro_f1', 'binary_macro_auprc')):
            output.append({'variant': name, 'metric': metric, 'estimate': points[name][k],
                           'ci_low': np.percentile(values[name][:, k], 2.5),
                           'ci_high': np.percentile(values[name][:, k], 97.5),
                           'videos': len(ids), 'labelled_endpoints': len(y), 'resamples': REPS})
        print(name, 'completed', flush=True)
    effects = []
    for name in ('analytic_probability', 'analytic_logit'):
        for k, metric in enumerate(('binary_macro_f1', 'binary_macro_auprc')):
            diff = values[name][:, k] - values['fixed_logit'][:, k]
            effects.append({'comparison': name + ' minus fixed_logit', 'metric': metric,
                            'difference': points[name][k] - points['fixed_logit'][k],
                            'ci_low': np.percentile(diff, 2.5), 'ci_high': np.percentile(diff, 97.5)})
    expected = {r['metric']: float(r['estimate']) for r in read(LABELS / 'frame_statistics_v1/frame_intervals.csv') if r['variant'] == 'fixed_0.5_late_logit'}
    assert np.allclose(points['fixed_logit'], [expected['binary_macro_f1'], expected['binary_macro_auprc']], rtol=0, atol=1e-12)
    write(OUT / 'frame_intervals.csv', output)
    write(OUT / 'paired_effects.csv', effects)
    (OUT / 'protocol.json').write_text(json.dumps({'labels': 'fixed OmniFall fall+fallen versus other annotated activity',
        'unknown_endpoints': 'excluded identically for all configurations', 'probabilities': 'normalized per row consistently with original fusion evaluator',
        'quality_weight': 'clip(pose_found_ratio * mean_keypoint_conf, 0, 1)', 'common_logit_epsilon': ev.EPSILON,
        'unit': 'complete video', 'resamples': REPS, 'seed': SEED, 'paired_resampling': True,
        'fixed_control_verified': True, 'training_or_threshold_tuning': False,
        'limitations': 'conditional pointwise intervals; subject/camera clustering and training variability remain'}, indent=2), encoding='utf-8')
    print(json.dumps({'metrics': output, 'effects': effects}, indent=2), flush=True)


if __name__ == '__main__':
    main()
