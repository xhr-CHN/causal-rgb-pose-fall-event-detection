"""Descriptive decomposition of nineteen revised-model missed events."""
from pathlib import Path
import csv
import collections
import sys
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'work/server_label_correction_import_20261012/corrected_verifier_gmd_retrospective_v1/audit_statistics_v1/corrected_miss_stage_audit.csv'
PREFIX = ROOT / 'outputs/label_corrected_revision_20261012/manuscript_source/figures/corrected_failure_stage_audit'
sys.path.insert(0, 'C:/Users/xhr/.codex/skills/nature-figure/scripts')
from audit_panel_alignment import require_matplotlib_panel_alignment


def main():
    with DATA.open(encoding='utf-8-sig', newline='') as handle:
        rows = list(csv.DictReader(handle))
    counts = collections.Counter(r['decision_stage'] for r in rows)
    assert len(rows) == 19 and counts == {'no_base_candidate': 4, 'all_candidates_rejected': 13, 'accepted_candidates_only_before_onset': 2}
    categories = ['No base candidate', 'All candidates rejected', 'Accepted only before onset']
    values = [4, 13, 2]
    mpl.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'DejaVu Sans'],
                         'font.size': 7.5, 'xtick.labelsize': 7, 'ytick.labelsize': 7.5,
                         'pdf.fonttype': 42, 'svg.fonttype': 'none',
                         'axes.spines.top': False, 'axes.spines.right': False, 'axes.spines.left': False})
    fig, ax = plt.subplots(figsize=(7.0866141732, 2.3622047244))
    fig.subplots_adjust(left=0.35, right=0.985, bottom=0.29, top=0.90)
    positions = np.array([2, 1, 0])
    ax.barh(positions, values, height=0.55, color=['#777777', '#0072B2', '#E69F00'])
    ax.set_yticks(positions, categories)
    ax.set_xlim(0, 20)
    ax.set_xticks([0, 5, 10, 15, 20])
    ax.tick_params(axis='y', length=0, pad=10)
    ax.set_xlabel('Missed events (n = 19)')
    ax.set_axisbelow(True)
    for position, value in zip(positions, values):
        ax.text(value + 0.35, position, f'{value} ({value / 19 * 100:.1f}%)', va='center', fontsize=7.5)
    fig.canvas.draw()
    require_matplotlib_panel_alignment(fig, json_out=str(PREFIX) + '.alignment.json',
        overlay_svg=str(PREFIX) + '.alignment.svg', tolerance_pt=1.5, gutter_tolerance_pt=1.5, strict=True)
    fig.savefig(str(PREFIX) + '.pdf')
    fig.savefig(str(PREFIX) + '.svg')
    fig.savefig(str(PREFIX) + '.png', dpi=600)
    fig.savefig(str(PREFIX) + '.tiff', dpi=600)
    print(PREFIX)


if __name__ == '__main__':
    main()
