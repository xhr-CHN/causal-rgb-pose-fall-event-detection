"""Locked corrected verifier on previously revealed GMD cache: retrospective audit."""
from pathlib import Path
import argparse
import csv
import hashlib
import importlib.util
import json
import sys
import numpy as np

EXPECTED = {
    'model': 'f733d0b3e0e5e7ffd82c0e9cd28b6e64be588dc85994939312d50d6d8df5c5d1',
    'candidates': '3aad362194960215d3e91a402bae6ef7af155871ba3783d5bd951f824d2a31ad',
    'annotations': '869eed27a8207ee4b0ed1f8faf888592e68d93997a8747c3fcf0669ca6b24387',
}


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def write(path, rows):
    if rows:
        with path.open('w', encoding='utf-8', newline='') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    assert sys.version_info[:2] == (3, 9) and np.__version__ == '1.26.4', 'Use recorded original yolo environment'
    if args.output_dir.exists():
        raise RuntimeError(f'Preserve previous audit: {args.output_dir}')
    paths = {
        'model': args.root / 'experiments/revision_label_correction_20261012/verifier_v1/corrected_labels/model.json',
        'candidates': args.root / 'experiments/gmdcsa24_frozen_inference_v1/candidate_alarms.csv',
        'annotations': args.root / 'experiments/gmdcsa24_final_blind_evaluation_v1/annotation_audit.csv',
    }
    actual_hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()}
    assert actual_hashes == EXPECTED, ('Inputs differ; inspect, do not bypass hash checks', actual_hashes)
    model = json.loads(paths['model'].read_text())
    assert model['selected_feature_configuration'] == 'pre_only_v1_compatible' and len(model['feature_names']) == 8
    candidates = read(paths['candidates'])
    assert len(candidates) == 110
    x = np.array([[float(r[f]) for f in model['feature_names']] for r in candidates])
    mean, scale = np.array(model['feature_mean']), np.array(model['feature_scale'])
    assert np.isfinite(x).all() and (scale > 0).all()
    logits = ((x - mean) / scale) @ np.array(model['coefficients']) + model['intercept']
    score = np.empty(len(logits))
    nonnegative = logits >= 0
    score[nonnegative] = 1 / (1 + np.exp(-logits[nonnegative]))
    exp = np.exp(logits[~nonnegative])
    score[~nonnegative] = exp / (1 + exp)
    predictions = []
    accepted = []
    threshold = float(model['decision_threshold'])
    for row, probability in zip(candidates, score):
        accept = int(probability >= threshold)
        predictions.append({'candidate_key': row['candidate_key'], 'sequence_id': row['sequence_id'],
                            'candidate_id': row['candidate_id'], 'sample_timestamp_ms': row['sample_timestamp_ms'],
                            'decision_timestamp_ms': row['decision_timestamp_ms'],
                            'corrected_verifier_probability': float(probability),
                            'locked_threshold': threshold, 'accepted': accept})
        if accept:
            accepted.append(row)
    args.output_dir.mkdir(parents=True)
    write(args.output_dir / 'corrected_verifier_predictions.csv', predictions)
    # Only after scores are saved, read the existing evaluation labels.
    metadata = {r['sequence_id']: r for r in read(paths['annotations'])}
    assert len(metadata) == 160
    assert sum(r['category'] == 'Fall' for r in metadata.values()) == 79
    assert sum(r['category'] == 'ADL' for r in metadata.values()) == 81
    evaluator_path = args.root / 'evaluate_gmdcsa24_final_blind_v1_fixed.py'
    if not evaluator_path.is_file():
        evaluator_path = args.root / 'causal_rgb_pose_fall_event_detection_release_candidate_v1/code/evaluate_gmdcsa24_final_blind_v1_fixed.py'
    spec = importlib.util.spec_from_file_location('historical_event_metric_helpers', evaluator_path)
    ev = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ev)
    old_primary = [r for r in candidates if int(r['primary_accepted'])]
    old_final = [r for r in candidates if int(r['final_accepted'])]
    stages = [('historical_base', candidates, 'sample_timestamp_ms', (73, 36)),
              ('historical_primary', old_primary, 'decision_timestamp_ms', (56, 12)),
              ('historical_final', old_final, 'decision_timestamp_ms', (60, 14)),
              ('corrected_verifier_retrospective', accepted, 'decision_timestamp_ms', None)]
    metrics = {}
    for name, rows, timestamp, expected in stages:
        metric, classified, events = ev.evaluate_alarm_stage(name, rows, timestamp, metadata)
        if expected:
            assert (metric['detected_fall_events'], metric['false_alarm_count']) == expected
        metrics[name] = metric
        write(args.output_dir / (name + '_classified_alarms.csv'), classified)
        write(args.output_dir / (name + '_event_results.csv'), events)
    import platform
    protocol = {
        'role': 'retrospective revision-period held-out evaluation after original test label reveal; not a new blind test',
        'model_chosen_only_from_corrected_URFD_Le2i_development': True,
        'model_threshold_and_input_hashes_locked_before_test_scoring': actual_hashes,
        'test_used_for_training_or_threshold_choice': False,
        'new_feature_extraction_or_temporal_training': False,
        'rescue_applied_to_corrected_model': False,
        'decision_schedule': 'retains stored original decision_timestamp_ms for like-stage comparison; pre-only features do not require future confirmation features',
        'primary_comparison': 'historical primary versus corrected verifier; historical final includes rescue and is contextual only',
        'historical_metric_reproduction_passed': True,
        'environment': {'python': sys.version, 'numpy': np.__version__, 'platform': platform.platform()},
        'evaluator_sha256': hashlib.sha256(evaluator_path.read_bytes()).hexdigest(),
        'threshold': threshold,
    }
    (args.output_dir / 'protocol.json').write_text(json.dumps(protocol, indent=2), encoding='utf-8')
    (args.output_dir / 'summary.json').write_text(json.dumps(metrics, indent=2), encoding='utf-8')
    print(json.dumps({'metrics': metrics, 'output': str(args.output_dir)}, indent=2), flush=True)


if __name__ == '__main__':
    main()
