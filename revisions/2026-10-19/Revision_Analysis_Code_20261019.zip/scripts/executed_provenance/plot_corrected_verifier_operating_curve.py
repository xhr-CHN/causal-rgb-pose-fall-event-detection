"""Locked revised verifier threshold trade-off; Python, quantitative two-panel grid."""
from pathlib import Path
import csv
import json
import sys
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'outputs/label_corrected_revision_20261012/verifier_operating_analysis'
PREFIX = DATA / 'corrected_verifier_operating_curves'
sys.path.insert(0, str(Path('C:/Users/xhr/.codex/skills/nature-figure/scripts')))
from audit_panel_alignment import require_matplotlib_panel_alignment


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def main():
    curve = read(DATA / 'threshold_curve.csv')
    protocol = json.loads((DATA / 'protocol.json').read_text())
    assert len(curve) == protocol['threshold_count']
    intervals = read(ROOT / 'work/server_label_correction_import_20261012/corrected_verifier_gmd_retrospective_v1/audit_statistics_v1/event_intervals.csv')
    selected = next(r for r in curve if r['is_development_locked_threshold'] == '1')
    mpl.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'DejaVu Sans'],
                         'font.size': 7.5, 'axes.titlesize': 8, 'axes.labelsize': 7.5,
                         'xtick.labelsize': 7, 'ytick.labelsize': 7, 'legend.fontsize': 7,
                         'svg.fonttype': 'none', 'pdf.fonttype': 42, 'axes.linewidth': 0.7,
                         'axes.spines.top': False, 'axes.spines.right': False, 'legend.frameon': False})
    fig, axes = plt.subplots(1, 2, figsize=(7.0866141732, 3.5433070866))
    fig.subplots_adjust(left=0.105, right=0.985, bottom=0.19, top=0.78, wspace=0.40)
    blue, gray = '#0072B2', '#777777'
    recall = np.array([float(r['recall']) for r in curve])
    assert np.all(np.diff(recall) >= 0)
    defined = np.array([r['precision'] != '' for r in curve])
    axes[0].plot(recall[defined], [float(r['precision']) for r in curve if r['precision'] != ''], color=blue, linewidth=1.1, label='Revised verifier threshold sweep')
    axes[1].plot(recall, [float(r['fa_per_hour']) for r in curve], color=blue, linewidth=1.1)
    for stage, color, marker, name in [
        ('corrected_verifier_retrospective', blue, 'o', 'Development-selected threshold'),
        ('historical_primary', gray, 'D', 'Historical primary verifier')]:
        record = {r['metric']: r for r in intervals if r['stage'] == stage}
        x = float(record['recall']['estimate'])
        xerr = np.array([[x - float(record['recall']['ci_low'])], [float(record['recall']['ci_high']) - x]])
        for ax, metric in zip(axes, ['precision', 'fa_per_hour']):
            y = float(record[metric]['estimate'])
            yerr = np.array([[y - float(record[metric]['ci_low'])], [float(record[metric]['ci_high']) - y]])
            ax.errorbar(x, y, xerr=xerr, yerr=yerr, color=color, marker=marker,
                        markersize=4.5, linestyle='none', elinewidth=0.7, capsize=2,
                        label=name if ax is axes[0] else None, zorder=4)
    axes[0].set_title('Event-level precision–recall', loc='left', pad=12)
    axes[1].set_title('Sensitivity–alarm burden', loc='left', pad=12)
    axes[0].set_ylabel('Event precision')
    axes[0].set_ylim(-0.03, 1.03)
    axes[1].set_ylabel('False alarms per hour')
    axes[1].set_ylim(-4, max(float(r['fa_per_hour']) for r in curve) * 1.1)
    for ax, label in zip(axes, ['a', 'b']):
        ax.set_xlabel('Event recall')
        ax.set_xlim(-0.03, 1.03)
        ax.grid(color='#DDDDDD', linewidth=0.4, zorder=0)
        ax.annotate(label, xy=(0, 1), xycoords='axes fraction', xytext=(-25, 12),
                    textcoords='offset points', fontweight='bold', fontsize=8, va='bottom')
    handles, names = axes[0].get_legend_handles_labels()
    fig.legend(handles, names, loc='upper center', bbox_to_anchor=(0.52, 0.985), ncol=1, labelspacing=0.5)
    fig.canvas.draw()
    require_matplotlib_panel_alignment(fig, json_out=str(PREFIX) + '.alignment.json',
        overlay_svg=str(PREFIX) + '.alignment.svg', tolerance_pt=1.5,
        gutter_tolerance_pt=1.5, strict=True)
    fig.savefig(str(PREFIX) + '.pdf')
    fig.savefig(str(PREFIX) + '.svg')
    fig.savefig(str(PREFIX) + '.png', dpi=600)
    fig.savefig(str(PREFIX) + '.tiff', dpi=600)
    contract = {'question': 'How does the frozen revised verifier trade event sensitivity for precision and alarm burden?',
                'claim': 'The development-selected operating point remains a sensitivity versus false-alarm trade-off, not deployment validation',
                'archetype': 'quantitative grid', 'backend': 'Python/matplotlib', 'width_mm': 180, 'height_mm': 90,
                'panel_a_role': 'precision trade-off over descriptive thresholds', 'panel_b_role': 'operational alarm burden for the same thresholds',
                'all_thresholds_included': len(curve), 'undefined_precision_rows_omitted_from_PR_only': int((~defined).sum()),
                'errorbars': 'pointwise 95% complete-video bootstrap intervals at revised locked and historical primary points, n=160 videos from 4 subjects',
                'inference_boundary': 'retrospective test sensitivity only; model and threshold were not selected by this curve',
                'historical_primary_point': 'contextual comparator; a different previously locked verifier, not another threshold on the revised curve'}
    (DATA / 'figure_contract.json').write_text(json.dumps(contract, indent=2), encoding='utf-8')
    print(PREFIX)


if __name__ == '__main__':
    main()
