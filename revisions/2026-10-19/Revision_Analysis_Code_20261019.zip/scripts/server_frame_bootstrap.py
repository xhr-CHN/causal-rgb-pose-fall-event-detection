"""Complete-video bootstrap for historical URFD/Le2i frame metrics.

Uses the frozen frame cache and the release evaluators; no sklearn required.
"""
from __future__ import annotations
import argparse,csv,hashlib,importlib.util,json
from pathlib import Path
import numpy as np

REPS,SEED=10000,20261004
VARIANTS=("pose_branch_only","rgb_branch_only","fixed_0.5_late_logit","quality_gated_late_logit")

def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def read(p):
    with Path(p).open(encoding="utf-8-sig",newline="") as f:return list(csv.DictReader(f))
def ap(y,s,w):
    y=np.asarray(y,int);s=np.asarray(s,float);w=np.asarray(w,float)
    pos=float(np.sum(w*y))
    if pos<=0:return np.nan
    order=np.argsort(-s,kind="mergesort");s=s[order];y=y[order];w=w[order]
    ends=np.r_[np.flatnonzero(np.diff(s)!=0),len(s)-1]
    tp=np.cumsum(w*y)[ends];den=np.cumsum(w)[ends]
    precision=np.divide(tp,den,out=np.zeros_like(tp,dtype=float),where=den>0)
    recall=tp/pos
    return float(np.sum(np.diff(np.r_[0.,recall])*precision))
def metrics(y,prob,w):
    y=np.asarray(y,int);w=np.asarray(w,float);pred=(np.argmax(prob,axis=1)!=0).astype(int)
    tp=np.sum(w*(y==1)*(pred==1));fp=np.sum(w*(y==0)*(pred==1))
    tn=np.sum(w*(y==0)*(pred==0));fn=np.sum(w*(y==1)*(pred==0))
    f1p=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.
    f1n=2*tn/(2*tn+fp+fn) if 2*tn+fp+fn else 0.
    score=np.clip(prob[:,1]+prob[:,2],0.,1.)
    return (float((f1p+f1n)/2),float((ap(y,score,w)+ap(1-y,1-score,w))/2))
def target_le2i(rows,inventory,events):
    out=[]
    for r in rows:
        s=r["sequence_id"];frame=int(r["source_frame_number"])
        out.append(int(inventory[s]["is_fall"] and events[s]["onset_frame"]<=frame<=events[s]["end_frame"]))
    return np.asarray(out,int)
def batched_ap(y,s,groups,weights):
    order=np.argsort(-s,kind="mergesort")
    sorted_score=s[order];target=y[order];group=groups[order]
    ends=np.r_[np.flatnonzero(np.diff(sorted_score)!=0),len(s)-1]
    values=[]
    for start in range(0,len(weights),32):
        w=weights[start:start+32,group]
        tp=np.cumsum(w*target,axis=1)[:,ends];den=np.cumsum(w,axis=1)[:,ends]
        total=(w*target).sum(axis=1)
        precision=np.divide(tp,den,out=np.zeros_like(tp,dtype=float),where=den>0)
        recall=np.divide(tp,total[:,None],out=np.full_like(tp,np.nan,dtype=float),where=total[:,None]>0)
        values.extend(np.sum(np.diff(np.column_stack([np.zeros(len(w)),recall]),axis=1)*precision,axis=1))
    return np.asarray(values)
def main():
    p=argparse.ArgumentParser();p.add_argument("--output-dir",required=True);p.add_argument("--urfd",required=True);p.add_argument("--le2i",required=True)
    p.add_argument("--fusion-dir",default="/home/data/yoloA27/experiments/revision_rerun_20261008/external_fusion_ablation_urfd_le2i_server_v3")
    args=p.parse_args()
    out=Path(args.output_dir)
    if out.exists():raise FileExistsError("Use a fresh output directory; preserve earlier evidence")
    out.mkdir(parents=True)
    root=Path("/home/data/yoloA27");code=root/"causal_rgb_pose_fall_event_detection_release_candidate_v1/code"
    ev=load_module("fusion_eval",code/"external_fusion_ablation_urfd_le2i_v1.py")
    blind=load_module("le2i_eval",code/"evaluate_le2i_final_blind_v1.py")
    blind.verify_frozen_inputs();inventory,events,_=blind.load_ground_truth()
    allout=[];validation=[]
    for dataset,path in (("URFD",args.urfd),("Le2i",args.le2i)):
        rows=read(path); variants=ev.build_variants(rows)
        y=ev.urfd_targets(rows) if dataset=="URFD" else target_le2i(rows,inventory,events)
        seq=np.asarray([r["sequence_id"] for r in rows]); ids=np.unique(seq); rng=np.random.default_rng(SEED)
        lookup={s:i for i,s in enumerate(ids)};groups=np.array([lookup[s] for s in seq])
        sample=rng.integers(len(ids),size=(REPS,len(ids)))
        weights=np.array([np.bincount(x,minlength=len(ids)) for x in sample])
        for name in VARIANTS:
            prob=np.asarray(variants[name],float)
            point=metrics(y,prob,np.ones(len(y)))
            ref=json.loads((Path(args.fusion_dir)/dataset.lower()/name/"summary.json").read_text())["binary_frame_level"]
            expected=[ref["binary_macro_f1"],ref["binary_macro_auprc"]]
            if not np.allclose(point,expected,rtol=0.,atol=1e-12):raise ValueError((dataset,name,point,expected))
            validation.append({"dataset":dataset,"variant":name,"actual":point,"expected":expected,"matched":True})
            pred=(prob.argmax(axis=1)!=0).astype(int)
            cells=np.stack([np.bincount(groups,weights=mask,minlength=len(ids)) for mask in
                ((y==1)&(pred==1),(y==0)&(pred==1),(y==0)&(pred==0),(y==1)&(pred==0))],axis=1)
            tp,fp,tn,fn=(weights@cells).T
            f1=(np.divide(2*tp,2*tp+fp+fn,out=np.zeros_like(tp),where=(2*tp+fp+fn)>0)+
                np.divide(2*tn,2*tn+fp+fn,out=np.zeros_like(tn),where=(2*tn+fp+fn)>0))/2
            scores=np.clip(prob[:,1]+prob[:,2],0.,1.)
            average=(batched_ap(y,scores,groups,weights)+batched_ap(1-y,1-scores,groups,weights))/2
            boot=np.column_stack([f1,average])
            for k,metric_name in enumerate(("macro_f1","macro_auprc")):
                allout.append({"dataset":dataset,"variant":name,"metric":metric_name,
                    "estimate":point[k],"ci_low":float(np.nanpercentile(boot[:,k],2.5)),
                    "ci_high":float(np.nanpercentile(boot[:,k],97.5)),
                    "sequences":len(ids),"endpoints":len(y),"resamples":REPS,"seed":SEED,
                    "finite_resamples":int(np.isfinite(boot[:,k]).sum())})
            print(dataset,name,"done",flush=True)
    with (out/"frame_intervals_server.csv").open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(allout[0]));w.writeheader();w.writerows(allout)
    (out/"frame_bootstrap_protocol.json").write_text(json.dumps({
      "unit":"complete sequence","resamples":REPS,"seed":SEED,
      "metrics":"binary macro F1 and macro AUPRC (positive and negative one-vs-rest)",
      "source":"historical frozen URFD and Le2i frame_predictions.csv",
      "labels":"URFD target_state_id; Le2i onset-through-end inventory labels",
      "AP_definition":"step-wise precision-recall integral after every complete tied-score group",
      "point_estimates_checked_against_fusion_evaluator":validation,
      "input_sha256":{str(Path(path)):hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in (args.urfd,args.le2i)},
      "no_model_or_threshold_change":True},indent=2),encoding="utf-8")
    print(json.dumps({"status":"complete","rows":len(allout),"output":str(out)}))
if __name__=="__main__":main()
