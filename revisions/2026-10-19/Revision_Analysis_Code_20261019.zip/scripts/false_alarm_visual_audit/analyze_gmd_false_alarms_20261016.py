"""Descriptive audit only. No model inference, relabeling or policy changes."""
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/gmd_false_alarm_audit_20261016'
COR = ROOT / 'work/server_label_correction_import_20261012/corrected_verifier_gmd_retrospective_v1'
OLD = ROOT / 'work/blind_cache/experiments'
PACKAGE = ROOT / 'outputs/revision_cross_camera_20261014/Submission_Package'


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def unique(rows, key):
    result = {r[key]: r for r in rows}
    assert len(result) == len(rows), key
    return result


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    before = {str(p.relative_to(PACKAGE)): sha(p) for p in PACKAGE.rglob('*') if p.is_file()}
    annotations = unique(read(OLD / 'gmdcsa24_final_blind_evaluation_v1/annotation_audit.csv'), 'sequence_id')
    candidates = unique(read(OLD / 'gmdcsa24_frozen_inference_v1/candidate_alarms.csv'), 'candidate_key')
    predictions = unique(read(COR / 'corrected_verifier_predictions.csv'), 'candidate_key')
    stages = {}
    for stage in ['historical_base', 'historical_primary', 'historical_final', 'corrected_verifier_retrospective']:
        rows = read(COR / (stage + '_classified_alarms.csv'))
        unique(rows, 'candidate_key')
        stages[stage] = rows
    assert [sum('false_alarm' in r['classification'] for r in v) for v in stages.values()] == [36, 12, 14, 14]
    details = []
    stage_sets = {s: {r['candidate_key'] for r in rows if 'false_alarm' in r['classification']} for s, rows in stages.items()}
    for stage in ['historical_final', 'corrected_verifier_retrospective']:
        for r in stages[stage]:
            if 'false_alarm' not in r['classification']:
                continue
            key = r['candidate_key']
            a, c = annotations[r['sequence_id']], candidates[key]
            assert a['subject'] == r['subject'] and c['sequence_id'] == r['sequence_id']
            p, rgb = float(c['pre_pose_fall_score_last']), float(c['pre_rgb_fall_score_last'])
            group = 'both_ge_0.5' if p >= .5 and rgb >= .5 else ('pose_only_ge_0.5' if p >= .5 else ('rgb_only_ge_0.5' if rgb >= .5 else 'neither_ge_0.5'))
            lead = float(r['fall_onset_ms']) - float(r['alarm_timestamp_ms']) if r['fall_onset_ms'] else ''
            details.append(dict(stage=stage, candidate_key=key, candidate_id=r['candidate_id'], sequence_id=r['sequence_id'],
                                source_relative_path=a['source_relative_path'], subject=r['subject'], classification=r['classification'],
                                alarm_timestamp_ms=r['alarm_timestamp_ms'], candidate_timestamp_ms=c['sample_timestamp_ms'],
                                milliseconds_before_annotated_onset=lead, source_description=a['description'], source_classes=a['classes'],
                                pose_score_at_candidate=p, rgb_score_at_candidate=rgb, branch_score_pattern=group,
                                pose_gate_weight_at_candidate=float(c['pre_pose_gate_weight_last']),
                                pre_pose_found_ratio_min=float(c['pre_pose_found_ratio_min']),
                                pre_roi_crop_ratio_min=float(c['pre_rgb_roi_crop_ratio_min']),
                                historical_primary_accepted=c['primary_accepted'], historical_rescue_accepted=c['rescue_accepted'],
                                corrected_probability=predictions[key]['corrected_verifier_probability'],
                                retained_by_both_final_versions=key in stage_sets['historical_final'] & stage_sets['corrected_verifier_retrospective'],
                                visual_review_status='not_reviewed', visual_cause='undetermined'))
    current = [r for r in details if r['stage'] == 'corrected_verifier_retrospective']
    assert len(current) == 14
    adl = [r for r in current if r['classification'] == 'false_alarm_adl']
    # Metadata-derived descriptions, NOT manually observed actions at alarm time.
    sleep = [r for r in adl if 'sleep' in r['source_description'].lower()]
    exercise = [r for r in adl if 'exercis' in r['source_description'].lower()]
    assert len(sleep) + len(exercise) == len(adl) and not {r['candidate_key'] for r in sleep} & {r['candidate_key'] for r in exercise}
    common = stage_sets['historical_final'] & stage_sets['corrected_verifier_retrospective']
    summary = {
        'stage_classifications': {s: dict(Counter(r['classification'] for r in rows)) for s, rows in stages.items()},
        'current_false_alarm_sequences': len({r['sequence_id'] for r in current}),
        'current_adl_false_alarm_sequences': len({r['sequence_id'] for r in adl}),
        'metadata_sleep_related_adl_alarms': len(sleep), 'metadata_exercise_related_adl_alarms': len(exercise),
        'current_candidate_branch_patterns': dict(Counter(r['branch_score_pattern'] for r in current)),
        'current_adl_candidate_branch_patterns': dict(Counter(r['branch_score_pattern'] for r in adl)),
        'common_final_false_alarm_candidates': len(common),
        'historical_only_false_alarm_candidates': sorted(stage_sets['historical_final'] - common),
        'corrected_only_false_alarm_candidates': sorted(stage_sets['corrected_verifier_retrospective'] - common),
        'current_pre_history_any_pose_missing': sum(r['pre_pose_found_ratio_min'] < 1 for r in current),
        'current_pre_history_any_roi_missing': sum(r['pre_roi_crop_ratio_min'] < 1 for r in current),
        'visual_review_complete': False, 'training': False, 'threshold_tuning': False,
    }
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / 'false_alarm_case_ledger.csv').open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(details[0])); writer.writeheader(); writer.writerows(details)
    summary['submission_files_unchanged'] = before == {str(p.relative_to(PACKAGE)): sha(p) for p in PACKAGE.rglob('*') if p.is_file()}
    assert summary['submission_files_unchanged']
    (OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    lines = ['# GMDCSA24误报追溯：日志与标注描述分析', '',
             '本次只分析现有记录，未重训、未调阈值、未修改最终投稿文件。未进行原视频逐例视觉复核。', '',
             '## 主要结果', '',
             '| 版本/阶段 | ADL误报 | 跌倒起点前误报 | 合计 |', '| --- | ---: | ---: | ---: |']
    for s, rows in stages.items():
        cnt = Counter(r['classification'] for r in rows)
        lines.append(f"| {s} | {cnt['false_alarm_adl']} | {cnt['false_alarm_pre_onset']} | {cnt['false_alarm_adl'] + cnt['false_alarm_pre_onset']} |")
    lines += ['', f"修订版本14次误报来自{summary['current_false_alarm_sequences']}个视频。12次ADL误报来自{summary['current_adl_false_alarm_sequences']}个视频，其中同一个运动视频出现两次误报；无跌倒视频中的两次报警不能归入‘真实跌倒后的重复报警’。",
              f"历史与修订最终版本共有{len(common)}个相同误报候选，各自独有{14-len(common)}个，不能因为总数相同就合并解释。", '',
              '## 标注元数据给出的场景线索', '',
              f'12次ADL误报中，{len(sleep)}次来自描述包含睡眠/躺卧及起身转换的视频，{len(exercise)}次来自运动相关视频。这里分类的是视频描述，不是对报警瞬间动作的人工核实，不代表这些动作已被证明导致误报。', '',
              '## 候选时刻的分支输出', '',
              '仅以0.5为描述性分界，不更改报警阈值，不把此分组当作报警策略重放或固定融合反事实。', '',
              f"14次误报中：{dict(Counter(r['branch_score_pattern'] for r in current))}。其中12次ADL误报：{dict(Counter(r['branch_score_pattern'] for r in adl))}。",
              '两分支共同高分说明错误不全是某一路完全失效时的权重分配问题。它与共享的动作/外观混淆相容，但不能单凭相关性认定原因。单路高分案例也不能证明固定融合会避免该报警；需要完整时序、同配置logit及策略重放。', '',
              f"14次误报的候选前20采样点窗口中，有{summary['current_pre_history_any_pose_missing']}例出现pose-found比例小于1，有{summary['current_pre_history_any_roi_missing']}例出现ROI-crop比例小于1。比例为1也不证明关键点准确、人物框正确或无遮挡。", '',
              '## 跌倒起点前误报', '']
    for r in current:
        if r['classification'] == 'false_alarm_pre_onset':
            lines.append(f"- {r['source_relative_path']}：决策时间早于既有起点{r['milliseconds_before_annotated_onset']:.1f} ms。应视觉核查既有时间边界，不据模型结果重新标注。")
    lines += ['', '## 适合论文补充的结论与待完成工作', '',
              '目前可支持：最终误报主要出现在非跌倒ADL片段；标注描述集中于躺卧/起身转换与运动场景；若干误报在候选时刻两模态均高分，门控无法仅靠明显的单模态缺失指示自动排除所有语义混淆。不能写成门控已被证明无效或某类动作是因果来源。', '',
              '需要原视频复核后才能给出动作级原因占比。应查看全部历史/修订误报并集，以及按受试者和标注动作匹配的未报警对照片段；不要只挑最符合预期的案例。',
              '下一步可在服务器原环境仅导出对应视频片段及对照，不需训练或再次运行模型。本地当前目录未发现与这批哈希ID直接对应的视频；尚未生成或执行服务器导出任务。', '',
              '原始依据：corrected_verifier_gmd_retrospective_v1各阶段classified_alarms.csv、corrected_verifier_predictions.csv，以及blind_cache中的annotation_audit.csv和candidate_alarms.csv。明细保留相对视频路径、候选键、标注描述、分支分数、门控权重及待视觉核验字段。', '',
              '完整视频标注描述可能覆盖多个动作，不能当作逐帧标签。候选时刻与历史决策时刻相差confirmation延迟，本报告分别保存，未混用。历史primary/final与修订accepted集合未重新选阈值。']
    (OUT / 'Review_ZH.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
