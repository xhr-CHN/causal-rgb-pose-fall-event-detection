"""Decode verified exports and make timestamped inspection sheets, no relabeling."""
import csv
import hashlib
import io
import json
import math
import zipfile
from collections import defaultdict
from pathlib import Path

import cv2
from PIL import Image, ImageDraw, ImageOps

ROOT=Path(__file__).resolve().parents[1]
ARCHIVE=ROOT/'work/gmd_false_alarm_visual_review_20261016/GMD_False_Alarm_Visual_Review_20261016.zip'
OUT=ROOT/'work/gmd_false_alarm_visual_inspection_20261016'


def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()


def read(z,n): return list(csv.DictReader(io.StringIO(z.read(n).decode('utf-8-sig'))))


def main():
    assert sha(ARCHIVE)=='a77e54ee98c48446b847f7ddf869ed20b9880c3bf97964b353ba467bc4cb1dc5'
    OUT.mkdir(exist_ok=False)
    with zipfile.ZipFile(ARCHIVE) as z:
        assert z.testzip() is None
        inventory=read(z,'exported_video_inventory.csv')
        selection={r['sequence_id']:r for r in read(z,'metadata/video_selection.csv')}
        annotations={r['sequence_id']:r for r in read(z,'metadata/annotation_subset.csv')}
        ledger=read(z,'metadata/alarm_review_ledger.csv')
        candidates={r['candidate_key']:r for r in read(z,'metadata/candidate_records_subset.csv')}
        events=defaultdict(dict)
        for r in ledger: events[r['sequence_id']][r['candidate_key']]=r
        index=[]
        for number,entry in enumerate(inventory,1):
            sid=entry['sequence_id']; role=entry['role']; a=annotations[sid]
            data=z.read(entry['archive_video']); assert hashlib.sha256(data).hexdigest()==entry['sha256']
            path=OUT/(sid+'.mp4'); path.write_bytes(data)
            cap=cv2.VideoCapture(str(path)); assert cap.isOpened(),sid
            fps=cap.get(cv2.CAP_PROP_FPS); total=int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            assert fps>0 and total>0
            duration=total/fps
            # Up to 24 overview frames, including the start and end, no random seeking.
            overview=sorted({1+round(i*(total-1)/min(23,total-1)) for i in range(min(24,total))})
            targets={}
            for key,r in sorted(events[sid].items()):
                c=candidates[key]; frame=int(float(c['source_frame_number']))
                assert abs((frame-1)*1000/fps-float(c['source_timestamp_ms']))<2.1, (sid,key,'source time mismatch')
                # Both historical and corrected decisions are 200ms later than candidate.
                decisions={float(x['alarm_timestamp_ms']) for x in ledger if x['candidate_key']==key}
                samples=[max(1,min(total,frame+round(d*fps))) for d in [-1,-.75,-.5,-.25,0,.25,.5,.75,1]]
                targets[key]=(samples,frame,decisions)
            wanted=set(overview)
            for xs,_,_ in targets.values(): wanted.update(xs)
            decoded={}; count=0
            while True:
                ok,frame=cap.read()
                if not ok: break
                count+=1
                if count in wanted: decoded[count]=Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB))
            cap.release(); assert count==total,(sid,count,total)
            assert wanted <= decoded.keys()
            def sheet(frames,target,title,cols=4,w=350,h=250,alarm=None):
                image=Image.new('RGB',(cols*w,48+math.ceil(len(frames)/cols)*h),'white'); draw=ImageDraw.Draw(image)
                draw.text((8,5),title,fill='black'); draw.text((8,23),sid+' | '+a['source_relative_path']+' | '+role,fill='black')
                for j,f in enumerate(frames):
                    x=(j%cols)*w; y=48+(j//cols)*h
                    thumb=ImageOps.contain(decoded[f],(w-8,h-34)); image.paste(thumb,(x+(w-thumb.width)//2,y+30))
                    draw.text((x+5,y+5),f'frame {f} | t={(f-1)/fps:.3f}s'+(' | CANDIDATE' if f==alarm else ''),fill='red' if f==alarm else 'black')
                image.save(target,quality=88)
            name=f'{number:02d}_overview.jpg'
            sheet(overview,OUT/name,f'Whole-video overview | fps={fps:.6f} | frames={count}')
            event_sheets=[]
            for key,(frames,frame,decisions) in targets.items():
                c=candidates[key]; name2=f'{number:02d}_candidate_{c["candidate_id"]}.jpg'
                title=f'Candidate {c["candidate_id"]} | source={float(c["source_timestamp_ms"])/1000:.3f}s | decisions={sorted(decisions)}ms'
                sheet(frames,OUT/name2,title,cols=3,w=420,h=310,alarm=frame); event_sheets.append(name2)
            index.append(dict(number=number,sequence_id=sid,role=role,source_relative_path=a['source_relative_path'],description=a['description'],classes=a['classes'],fps=fps,frames=count,duration_seconds=duration,overview=name,event_sheets=event_sheets))
            print('DECODED',number,sid,count,flush=True)
        (OUT/'inspection_index.json').write_text(json.dumps(index,indent=2),encoding='utf-8')
        print('INSPECTION_SHEETS_READY',OUT,flush=True)


if __name__=='__main__':main()
