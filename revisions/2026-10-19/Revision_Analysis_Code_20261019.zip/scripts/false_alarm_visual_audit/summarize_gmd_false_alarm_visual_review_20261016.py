"""Record observations of actually inspected contact sheets."""
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/gmd_false_alarm_visual_review_20261016'
VIS=ROOT/'work/gmd_false_alarm_visual_inspection_20261016'
OBS={
    '6':('exercise_or_bending','弯腰、手伸向小腿/地面，随后屈膝下降；不能简单描述为快速跌倒。'),
    '10':('bed_reclining_transition','人物由床沿坐姿向床面侧躺，候选时刻已接近侧卧。'),
    '33':('initial_horizontal_posture','片头人物已经侧卧在地面，候选约0.9秒，随后有转身及准备起身动作；没有观察到片头前的跌倒过程。'),
    '41':('exercise_or_bending','人物俯身、手撑地并向支撑/俯卧撑式姿态转换；是运动视频中的候选。'),
    '44':('bed_reclining_transition','由床沿坐姿抬腿、手臂支撑并侧躺到床上。'),
    '46':('pre_onset_context','候选及决策附近仍侧卧床上，后续才向床外移动并落地；保持原起点不变。'),
    '53':('bed_reclining_transition','从床沿坐姿、抬腿支撑转为侧卧。'),
    '56':('bed_reclining_transition','人物背向摄像机，从床沿坐姿转向床面躺卧，候选附近仍有腿及躯干调整。'),
    '63':('bed_reclining_transition','人物由坐姿后仰、抬腿至床面躺卧，未见该窗口内落地。'),
    '73':('initial_horizontal_posture','片头人物平躺床上，候选约0.9秒；之后才起身坐起。仅历史最终版本保留。'),
    '77':('initial_horizontal_posture','片头人物已平躺床上，候选约0.9秒，随后抬头坐起。'),
    '98':('pre_onset_context','候选附近人物俯身、手撑床、抬腿上床；不是该窗口内的床上跌落。原标注跌倒起点更晚，未调整。'),
    '100':('exercise_or_bending','人物站立分腿、弯腰并向地面伸手，候选附近保持低头俯身姿态。'),
    '101':('exercise_or_bending','同一运动视频的第二次俯身伸手动作再次产生候选；这是ADL内重复误报，不是已检出跌倒后的重复报警。'),
    '106':('initial_horizontal_posture','片头人物已躺在床上，候选约0.9秒，后续开始坐起。'),
    '109':('controlled_floor_sitting','人物由站姿屈膝、手撑地转为地面坐姿；仅历史最终版本保留，仍沿用ADL标注。'),
}
LABELS={'exercise_or_bending':'运动/弯腰/手部支撑','bed_reclining_transition':'床上躺卧转换',
        'initial_horizontal_posture':'片头已呈躺卧姿态','pre_onset_context':'跌倒起点前的非跌倒上下文',
        'controlled_floor_sitting':'下蹲并坐到地面'}


def main():
    index=json.loads((VIS/'inspection_index.json').read_text())
    with (ROOT/'outputs/gmd_false_alarm_audit_20261016/false_alarm_case_ledger.csv').open(encoding='utf-8-sig') as f:
        ledger=list(csv.DictReader(f))
    assert {r['candidate_id'] for r in ledger}==set(OBS)
    records=[]
    for r in ledger:
        r=dict(r); group,note=OBS[r['candidate_id']]
        i=next(x for x in index if x['sequence_id']==r['sequence_id'])
        detail=next(n for n in i['event_sheets'] if n.endswith('_'+r['candidate_id']+'.jpg'))
        assert (VIS/detail).is_file()
        r.update(visual_group=group,visual_observation=note,review_evidence=str(VIS/detail),
                 review_scope='review of 9-frame candidate +/-1s sheet; not exhaustive frame-by-frame annotation',
                 visual_review_status='sampled_alarm_window_reviewed',visual_cause='not_causally_established')
        records.append(r)
    counts={s:dict(Counter(r['visual_group'] for r in records if r['stage']==s)) for s in sorted({r['stage'] for r in records})}
    assert counts['corrected_verifier_retrospective']==dict(exercise_or_bending=4,bed_reclining_transition=5,initial_horizontal_posture=3,pre_onset_context=2)
    controls=[dict(number=16,observation='坐到床面并侧躺，后续平躺；有候选但两个最终版本均未报警。'),
              dict(number=17,observation='保持站立，双臂抬起放下；无候选。'),
              dict(number=18,observation='由站立屈膝坐到地面并阅读；无候选。'),
              dict(number=19,observation='面向摄像机反复下蹲/站起；无候选。'),
              dict(number=20,observation='地面坐姿向侧卧转换；有候选但两个最终版本均未报警。')]
    for r in controls:
        i=next(i for i in index if i['number']==r['number']);r.update(sequence_id=i['sequence_id'],source_relative_path=i['source_relative_path'],evidence=str(VIS/i['overview']))
    p=ROOT/'outputs/revision_cross_camera_20261014/Submission_Package'
    with (p/'FILE_MANIFEST.csv').open(encoding='utf-8-sig') as f:
        for r in csv.DictReader(f):assert hashlib.sha256((p/r['path']).read_bytes()).hexdigest()==r['sha256']
    OUT.mkdir(exist_ok=False)
    (OUT/'visual_observations.json').write_text(json.dumps(dict(records=records,controls=controls,counts=counts,
        decoded_videos=len(index),decoded_frames=sum(x['frames'] for x in index),source_archive_sha256='a77e54ee98c48446b847f7ddf869ed20b9880c3bf97964b353ba467bc4cb1dc5',
        decoded_all_frames=True,visually_inspected_all_frames=False,independent_human_double_review=False,
        inspected_alarm_sheets=16,inspected_control_overviews=5,submission_manifest_unchanged=True),ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['# GMDCSA24误报画面核验：首轮结果','',
        '核验日期：2026-10-16。已对20个原视频的哈希、ZIP CRC、完整解码帧数及候选原始帧号/时间对应进行检查，共4516帧。初步查看16张候选前后约1秒、每张9帧的细节图，以及5张对照全片均匀抽样概览；这不是对4516帧逐帧人工标注，也不是独立双人盲法审核。',
        '本轮不改标签、匹配规则、模型或阈值；未训练、未推理。投稿包清单内文件哈希仍匹配。', '',
        '## 修订版本14次误报的可见行为分组','',
        '| 描述性分组 | 次数 | 占14次误报 | 候选编号 |','| --- | ---: | ---: | --- |']
    current=[r for r in records if r['stage']=='corrected_verifier_retrospective']
    for group,count in counts['corrected_verifier_retrospective'].items():
        ids=', '.join(r['candidate_id'] for r in current if r['visual_group']==group)
        lines.append(f'| {LABELS[group]} | {count} | {count/14:.1%} | {ids} |')
    lines += ['', '分组是事后描述性整理，不是已预先定义并由双人验证的行为分类。比例只针对这14次误报，不能解读为某动作的误报概率；没有各动作负暴露时间作为分母。', '',
        '## 与仅看视频描述相比，新确认了什么','',
        '1. 三个ADL案例在片头已躺卧：33、77、106均在约0.9秒产生候选。不能统称为“快速坐下或下降引起误报”。可见的短初始上下文与既有水平姿态，提示系统有把姿态状态当作新跌倒事件的风险；这仍是解释假说。',
        '2. 五个ADL案例发生于床上坐姿到躺卧转换附近。画面可见手部支撑、抬腿或床面支承，说明真实场景中的支承面和动作意图可能重要，但未做消融来确定这些因素的因果作用。',
        '3. 四次运动相关误报中，6、100、101为明显俯身伸手，41涉及手撑地向支撑式运动姿态转换。100与101来自同一视频两次不同动作过程；不能按两个独立视频或两个独立被试计算。',
        '4. 两次起点前误报对应不同上下文：46候选/决策附近仍卧床，后续才向床外落地；98候选附近正在俯身撑床、上床，原跌倒起点在更晚处。保留其原时间边界和误报分类；本轮并未重新裁定起点。', '',
        '## 对照与阶段差异','',
        '五个对照按元数据选取后查看概览。16号床上躺卧与20号地面躺卧虽然产生候选，但两版最终均拒绝；17号站立抬臂、18号地面坐下阅读、19号反复下蹲/站起均无候选。这说明同类大场景不必然导致最终误报，也不能把弯腰/下蹲本身判为系统必然失败。',
        '对照只是目的性描述样本：subject 4躺卧转换组没有合适同受试者对照。它们不形成随机、严格配对的因果试验。',
        '历史最终版本还保留73（片头卧床后起身）及109（下蹲坐地），修订版去掉这两例，但新增41及101。因此两版14次误报的总数相同，行为构成不同；修订前后必须分别报告。', '',
        '## 与门控有关的解释边界','',
        '既有日志显示，修订版本14次误报中10次在候选时刻两分支的跌倒分数都≥0.5；候选前窗口未记录到姿态检测或ROI裁剪缺失。这与画面中的普通姿态/动作混淆相容，说明只依赖明显模态缺失的权重切换未必足以解决全部误报。',
        '但0.5仅用于描述分支分数，不是候选策略的替代阈值；单帧概率也不能重建固定logit融合的完整时序。没有做门控反事实消融，因此不能声称某次误报由门控导致，或固定融合必定能避免。',
        '原视频未叠加该时刻的检测框/关键点；pose-found和ROI-crop指标为1不证明其位置准确。不能把这些案例定性为“已排除姿态误差”，也不能据此统计准确的姿态失败比例。', '',
        '## 可用于论文的英文讨论草稿（尚未写入投稿材料）','',
        'A retrospective inspection of sampled alarm-centred frames provided a descriptive breakdown of the 14 false alarms from the revised verifier configuration. Five occurred around bed-reclining transitions, three arose in clips that already began with the person lying down, and four accompanied bending or support-based exercise. Two further alarms preceded the annotated fall onset and occurred during pre-fall bed-related activities. These observations are consistent with confusion between fall-like posture or motion and a newly occurring fall event. In ten cases, both branches assigned fall scores of at least 0.5 at the candidate time; therefore, the errors cannot all be characterized as an obvious single-modality dropout. However, these observations do not establish causal attribution to the gate or exclude inaccurate pose localization. Selected non-alarming controls also contained reclining or squatting actions. The analysis is descriptive, uses the existing annotations and decision rules, and does not estimate action-specific false-alarm rates or validate a revised model.', '',
        '## 逐案例观察','']
    unique={r['candidate_id']:r for r in records}
    for cid,r in sorted(unique.items(),key=lambda pair:int(pair[0])):
        lines.append(f"- 候选{cid}，{r['source_relative_path']}：{r['visual_observation']}")
    lines += ['', '## 下一步','',
        '可先由作者核对上述动作分组；若认可，将数值分类表和观察边界放入S2，正文Discussion保留简短解释即可，不需新增GPU训练。若要进一步把误报归因于关键点或ROI定位，则需要另行导出相同时间点的既有定位记录作叠加核验；本轮未完成此步骤。',
        '原视频及接触图仅供内部研究核查，不因下载或模糊处理自动获得再发表权限。建议论文新增内容使用数字表和已有分数曲线，不直接加入这些人物截图。']
    (OUT/'Review_ZH.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps(dict(counts=counts,decoded_frames=sum(x['frames'] for x in index),review_report=str(OUT/'Review_ZH.md'),submission_files_unchanged=True),ensure_ascii=False,indent=2))


if __name__=='__main__':main()
