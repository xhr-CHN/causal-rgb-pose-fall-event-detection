"""Rescore immutable standalone prediction caches; never train or tune a model."""
import argparse
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import numpy as np


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def write(path, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-root', type=Path, required=True)
    parser.add_argument('--original-inventory', type=Path, required=True)
    parser.add_argument('--original-events', type=Path, required=True)
    parser.add_argument('--unified-labels', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    if args.output_dir.exists():
        raise RuntimeError('Preserve existing output; select a new output directory')
    source = args.input_root / 'code/le2i_baseline_v1/external_fusion_ablation_urfd_le2i_v1.py'
    spec = importlib.util.spec_from_file_location('standalone_evaluator', source)
    ev = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ev)
    prediction_dir = args.input_root / 'experiments/le2i_standalone_baselines_v2'
    historical = {r['baseline']: r for r in read(prediction_dir / 'event_level_summary_fixed.csv')}
    # Source-selected policy recorded in the frozen inference lock. Historical
    # reproduction below independently checks the resulting candidate decisions.
    policy = dict(alpha=0.5, alarm_threshold=0.85, consecutive_evidence_frames=2,
                  reset_threshold=0.1, reset_frames=5)
    inv = {r['sequence_id']: r for r in read(args.unified_labels / 'video_inventory.csv')}
    events = {r['sequence_id']: {'onset_ms': float(r['onset_s']) * 1000}
              for r in read(args.unified_labels / 'fall_events.csv')}
    assert len(inv) == 190 and len(events) == 130
    exposure = np.array([float(inv[sid]['negative_exposure_seconds']) / 3600 for sid in sorted(inv)])
    ids = sorted(inv)
    index = {sid: i for i, sid in enumerate(ids)}
    rng = np.random.default_rng(20261004)
    weights = np.array([np.bincount(rng.integers(190, size=190), minlength=190)
                        for _ in range(10000)])
    flags = np.array([sid in events for sid in ids], int)
    results, audits, intervals, outputs, hashes = [], [], [], [], {}
    for name in ('pose_tcn', 'rgb_tcn'):
        path = prediction_dir / (name + '_frame_predictions.csv')
        rows = read(path)
        assert len(rows) == 55288 and {r['sequence_id'] for r in rows} == set(inv)
        assert len({(r['sequence_id'], r['sample_index']) for r in rows}) == len(rows)
        p = np.array([[float(r[k]) for k in ('prob_adl', 'prob_falling', 'prob_fallen')] for r in rows])
        assert np.isfinite(p).all() and (p >= 0).all()
        old_inv, old_events, _, old_exposure = ev.load_le2i_ground_truth(
            rows, args.original_inventory, args.original_events)
        alarms = ev.generate_candidate_alarms(rows, p, policy, old_inv)
        old, _, _ = ev.evaluate_events(alarms, old_inv, old_events, old_exposure)
        for key in ('total_fall_events', 'detected_fall_events', 'candidate_alarm_count',
                    'false_alarm_count', 'negative_exposure_hours', 'false_alarms_per_hour',
                    'duplicate_alarms_after_onset', 'mean_detection_delay_ms',
                    'median_detection_delay_ms', 'p95_detection_delay_ms'):
            assert abs(float(old[key]) - float(historical[name][key])) < 1e-8, (name, key)
        audits.append({'baseline': name, 'historical_reproduction': 'PASS', **old})
        new, classified, event_rows = ev.evaluate_events(alarms, inv, events, float(exposure.sum()))
        new['event_precision_excluding_duplicates'] = new['detected_fall_events'] / (
            new['detected_fall_events'] + new['false_alarm_count'])
        results.append({'baseline': name, 'window_length': 32, 'windows': len(rows), **new})
        tp = np.zeros(190); fp = np.zeros(190)
        for r in event_rows:
            tp[index[r['sequence_id']]] = int(r['detected'])
        for r in classified:
            fp[index[r['sequence_id']]] += int(r['alarm_classification'].startswith('false_alarm'))
        boot_tp, boot_fp = weights @ tp, weights @ fp
        values = {'event_recall': boot_tp / (weights @ flags),
                  'false_alarms_per_hour': boot_fp / (weights @ exposure),
                  'event_precision_excluding_duplicates': boot_tp / (boot_tp + boot_fp)}
        for key, sample in values.items():
            assert np.isfinite(sample).all()
            intervals.append(dict(baseline=name, metric=key, estimate=new[key],
                                  ci_low=float(np.percentile(sample, 2.5)),
                                  ci_high=float(np.percentile(sample, 97.5)),
                                  resamples=10000, seed=20261004))
        outputs.append((name, alarms, classified, event_rows))
        hashes[str(path.relative_to(args.input_root))] = hashlib.sha256(path.read_bytes()).hexdigest()
    args.output_dir.mkdir(parents=True)
    write(args.output_dir / 'corrected_event_metrics.csv', results)
    write(args.output_dir / 'historical_reproduction.csv', audits)
    write(args.output_dir / 'event_intervals.csv', intervals)
    for name, alarms, classified, event_rows in outputs:
        folder = args.output_dir / name
        folder.mkdir()
        write(folder / 'candidate_alarms.csv', alarms)
        write(folder / 'classified_alarms.csv', classified)
        write(folder / 'event_results.csv', event_rows)
    for label_path in (args.original_inventory, args.original_events,
                       args.unified_labels / 'video_inventory.csv',
                       args.unified_labels / 'fall_events.csv'):
        hashes[str(label_path)] = hashlib.sha256(label_path.read_bytes()).hexdigest()
    protocol = dict(training=False, new_inference=False, threshold_tuning=False,
                    policy=policy, candidate_stage_only=True, label_source='fixed OmniFall reannotation',
                    video_count=190, event_count=130, negative_exposure_hours=float(exposure.sum()),
                    matching='first source-timestamp alarm at or after onset through video end; duplicates separate',
                    bootstrap='10000 complete-video resamples, seed 20261004; conditional, not subject-independent',
                    comparability='standalone W32 versus fusion W16; full-sequence exposure includes warm-up',
                    evaluator_sha256=hashlib.sha256(source.read_bytes()).hexdigest(), input_hashes=hashes)
    (args.output_dir / 'protocol.json').write_text(json.dumps(protocol, indent=2), encoding='utf-8')
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
