"""Portable read-only checks of corrected revision artifacts (Python + NumPy)."""
import argparse
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import numpy as np


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    root = args.root
    manifest = read(root / 'FILE_MANIFEST.csv')
    for item in manifest:
        path = root / item['path']
        assert path.stat().st_size == int(item['bytes']), item['path']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256'], item['path']
    ev = module(root / 'scripts/external_fusion_ablation_urfd_le2i_v1.py', 'bundle_evaluator')
    labels = root / 'evidence/current/le2i'
    inv = {r['sequence_id']: r for r in read(labels / 'video_inventory.csv')}
    events = {r['sequence_id']: {'onset_ms': float(r['onset_s']) * 1000}
              for r in read(labels / 'fall_events.csv')}
    exposure = sum(float(r['negative_exposure_seconds']) / 3600 for r in inv.values())
    assert len(inv) == 190 and len(events) == 130
    assert abs(exposure - 0.6767282272222221) < 1e-12
    checked = 0
    expected = {(r['dataset'], r['variant']): r for r in
                read(labels / 'fusion_event_statistics_v2/operating_points.csv')}
    sources = [(name, labels / name / 'classified_alarms.csv') for name in
               ('pose_branch_only', 'rgb_branch_only', 'fixed_0.5_late_logit', 'quality_gated_late_logit')]
    sources += [(name, root / f'inputs/analytic/{name}/candidate_alarms.csv')
                for name in ('analytic_probability', 'analytic_logit')]
    for name, path in sources:
        metrics, _, _ = ev.evaluate_events(read(path), inv, events, exposure)
        target = expected[('Le2i', name)]
        assert metrics['detected_fall_events'] == int(target['detected'])
        assert metrics['false_alarm_count'] == int(target['false_alarms'])
        assert abs(metrics['false_alarms_per_hour'] - float(target['fa_per_hour'])) < 1e-8
        checked += 1
    studies = labels / 'sampling_image_recomputed_v2'
    for row in read(studies / 'event_operating_points.csv'):
        alarms = read(studies / row['study'] / row['configuration'] / 'classified_alarms.csv')
        metrics, _, _ = ev.evaluate_events(alarms, inv, events, exposure)
        assert metrics['detected_fall_events'] == int(row['detected'])
        assert metrics['false_alarm_count'] == int(row['false_alarms'])
        checked += 1
    frame_rows = read(root / 'inputs/le2i_frame_predictions.csv')
    targets = read(labels / 'frozen_endpoint_targets.csv')
    assert len(frame_rows) == len(targets) == 58328
    assert all((r['sequence_id'], r['sample_index'], r['source_frame_number']) ==
               (t['sequence_id'], t['sample_index'], t['source_frame_number'])
               for r, t in zip(frame_rows, targets))
    target = np.array([int(r['target_state_id']) for r in targets])
    mask = target >= 0
    assert mask.sum() == 55007
    helper = module(root / 'scripts/server_frame_bootstrap.py', 'frame_helper')
    intervals = {(r['variant'], r['metric']): r for r in read(labels / 'frame_statistics_v1/frame_intervals.csv')}
    for name, probabilities in ev.build_variants(frame_rows).items():
        if (name, 'binary_macro_f1') not in intervals:
            continue
        f1, ap = helper.metrics((target[mask] != 0).astype(int), probabilities[mask], np.ones(mask.sum()))
        for metric, value in [('binary_macro_f1', f1), ('binary_macro_auprc', ap)]:
            assert abs(value - float(intervals[(name, metric)]['estimate'])) < 1e-10
    verifier = root / 'evidence/current/verifier'
    model = json.loads((verifier / 'corrected_labels/model.json').read_text())
    assert hashlib.sha256((verifier / 'corrected_labels/model.json').read_bytes()).hexdigest() == \
        'f733d0b3e0e5e7ffd82c0e9cd28b6e64be588dc85994939312d50d6d8df5c5d1'
    oof = read(verifier / 'corrected_labels/oof_predictions.csv')
    y = np.array([int(r['label_true_alarm']) for r in oof])
    p = np.array([float(r['pre_only_v1_compatible_oof_probability']) for r in oof]) >= model['decision_threshold']
    confusion = [int(np.sum(y * p)), int(np.sum((1-y) * p)),
                 int(np.sum((1-y) * (~p))), int(np.sum(y * (~p)))]
    assert confusion == [145, 28, 101, 7]
    candidates = read(root / 'inputs/gmd_candidate_alarms.csv')
    x = np.array([[float(r[k]) for k in model['feature_names']] for r in candidates])
    z = (x - model['feature_mean']) / model['feature_scale']
    score = 1 / (1 + np.exp(-np.clip(z @ np.array(model['coefficients']) + model['intercept'], -60, 60)))
    retained = read(root / 'evidence/current/gmd/corrected_verifier_predictions.csv')
    assert [r['candidate_key'] for r in candidates] == [r['candidate_key'] for r in retained]
    assert np.max(abs(score - np.array([float(r['corrected_verifier_probability']) for r in retained]))) < 1e-12
    assert int(np.sum(score >= model['decision_threshold'])) == 74
    print(json.dumps(dict(status='PASS', manifest_files=len(manifest), le2i_event_configurations=checked,
                          frame_endpoints=58328, labelled_endpoints=55007, oof_confusion=confusion,
                          gmd_probabilities_reproduced=110, gmd_accepted=74,
                          retraining=False, threshold_selection=False)))


if __name__ == '__main__':
    main()
