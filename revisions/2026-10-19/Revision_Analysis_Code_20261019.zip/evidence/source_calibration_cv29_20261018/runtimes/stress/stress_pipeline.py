#!/usr/bin/env python3
"""Evaluation-only modality stress; fresh isolated outputs, no model selection."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback
import zipfile
from control_pipeline import ROOT,PY,now,bundle_check,environment_check

RESULT='gate_modality_stress_side_4090_20261018_v1'
sys.dont_write_bytecode=True


def execute(root,out,update):
    tools=Path(__file__).resolve().parent;manifest=bundle_check(tools)
    update(stage='unit_tests');subprocess.run([sys.executable,'-m','unittest','discover','-s',str(tools),'-p','test_*.py','-v'],check=True)
    env=environment_check()
    from cv_data import load_source,write_json,sha
    from suite_prepare import verify_prior,PRIOR_ARCHIVE_SHA
    from stress_conditions import cases
    from stress_runtime import freeze_controls,run_stress,CONTROL_SHA
    from control_reuse import verify_controls
    if shutil.disk_usage(out).free<3*1024**3:raise RuntimeError('Need at least3GiB free for retained diagnostics and archive')
    update(stage='source_and_archive_preflight');data=load_source(root,out);prior,reused=verify_prior(root,out)
    if json.loads((prior/'source_preflight.json').read_text())['input_sha256']!=data['input_sha256']:raise ValueError('Source identity differs from frozenCV29')
    sys.path.insert(0,str(data['code']));frozen,temps,archive=freeze_controls(root,out,data['input_sha256'])
    protocol=dict(locked_before_stress=True,fit_or_training=False,environment=env,cases=cases(),
        source='same repeatedly inspected29 source falls/6people; not independent blind evidence',
        models='all31 frozen roles:calibrated fixed,3 optimized scalars,9 original constants,9 dynamic gates,9 training-mean constants',
        synthetic_only='normalized-feature dropout/noise,not raw-image occlusion,lux or real keypoint failure experiments',
        dropout='nested2/6/10 frames per20 physical-frame period,phase SHA256(sequence_id,seed),same mask across modalities/models;pose normalized95D zero+q zero;RGB normalized256D zero only',
        noise='physical-frame-keyed Gaussian SD0.1/0.3/0.5 on normalized pose dimensions except5 quality columns;q unchanged; deliberately unflagged feature noise',
        causality='overlapping windows share identical physical-frame perturbation; no label/onset/error/prediction-dependent placement; prefixes unchanged',
        primary='fixed_085:event recall,FA/h,1s recall; all preset other policies reported; no best-condition or best-threshold selection',
        uncertainty='within-person repetition means then2000 paired6-person resamples,seed20261018,pointwise95 intervals,no p-values or multiplicity adjustment;shared fold training and repeatedly viewed data limit independence',
        expected_units=84,expected_cases=28,expected_pooled_rows=3472,clean_replay='31role probabilities/weights and372fold-policy metrics against frozen archive;no tolerance relaxation',
        originalCV29_archive_sha256=PRIOR_ARCHIVE_SHA,frozen_controls_archive_sha256=CONTROL_SHA,bundle_sha256=manifest,
        manuscript_modified=False,new_people_or_events=0,independent_validation_complete=False)
    write_json(out/'protocol.json',protocol)
    freeze_hashes={p.relative_to(out).as_posix():sha(p) for p in frozen.rglob('*') if p.is_file()}
    freeze_hashes.update({'protocol.json':sha(out/'protocol.json'),'clean_reference_fold_metrics.csv':sha(out/'clean_reference_fold_metrics.csv')})
    write_json(out/'stress_input_seal.json',dict(frozen_before_inference=True,files=freeze_hashes))
    update(stage='clean_replay_and_stress',total_units=84,units_complete=0)
    result=run_stress(data,prior,frozen,temps,archive,out,update)
    verify_controls(frozen)
    for name,h in freeze_hashes.items():
        if sha(out/name)!=h:raise ValueError('Frozen stress inputs changed: '+name)
    for name,h in {**data['input_sha256'],**reused,str(archive):CONTROL_SHA}.items():
        if sha(Path(name))!=h:raise ValueError('Read-only source changed: '+name)
    bundle_check(tools);write_json(out/'completion_summary.json',dict(status='complete',training=False,manuscript_modified=False,**result))
    update(stage='packaging');target=out/'Gate_Modality_Stress_Side_Results_20261018.zip'
    with zipfile.ZipFile(target,'x',zipfile.ZIP_STORED) as z:
        for p in sorted(p for p in out.rglob('*') if p.is_file() and p!=target and p.name!='status.json'):z.write(p,p.relative_to(out).as_posix())
    with zipfile.ZipFile(target) as z:
        if z.testzip() is not None:raise RuntimeError('Result ZIP CRC')
    update(state='COMPLETE',stage='complete',archive=str(target),archive_sha256=sha(target),archive_bytes=target.stat().st_size)
    print('ALL_FROZEN_MODALITY_STRESS_COMPLETE',out,flush=True);print('RESULT_ARCHIVE',target,sha(target),flush=True)


def main():
    for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='2'
    os.environ['CUBLAS_WORKSPACE_CONFIG']=':4096:8';os.environ['PYTHONDONTWRITEBYTECODE']='1';os.environ.setdefault('CUDA_VISIBLE_DEVICES','0')
    from cv_data import write_json
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=ROOT);a=ap.parse_args();root=a.root.resolve()
    if os.name!='posix' or root!=ROOT or root not in Path(__file__).resolve().parents:raise RuntimeError('Run only under approved4090 snapshot')
    out=root/'experiments'/RESULT
    if root not in out.resolve().parents or root not in (root/'experiments').resolve().parents:raise ValueError('Output escapes project')
    out.mkdir(parents=True,exist_ok=False);began=time.monotonic();state=dict(state='RUNNING',stage='starting',pid=os.getpid(),started_at=now(),units_complete=0,total_units=84)
    def update(**kw):
        state.update(kw,last_update_at=now(),elapsed_seconds=time.monotonic()-began);write_json(out/'status.json',state)
    try:
        try:os.nice(5)
        except OSError:pass
        update();execute(root,out,update)
    except BaseException as exc:
        update(state='INTERRUPTED' if isinstance(exc,KeyboardInterrupt) else 'FAILED',error=repr(exc));traceback.print_exc();raise


if __name__=='__main__':main()
