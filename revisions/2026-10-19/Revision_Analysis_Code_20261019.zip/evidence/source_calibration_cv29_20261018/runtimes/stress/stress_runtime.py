"""Frozen archive reuse and evaluation-only synthetic modality stress."""
import hashlib
import io
import json
from pathlib import Path
import time
import zipfile
import numpy as np
import torch
from cv_data import outer_plan,SEEDS,sha,write_json,read_csv
from cv_training import normalized,forward_branch,digest
from suite_prepare import final_branch
from bounded_prepare import videos_from_dense
from bounded_training import predict
from control_reuse import load_head,verify_controls
from control_eval import FixedWeight,read_control,paired
from stress_conditions import cases,perturb
from stress_results import StressCollector,directionality,finish_reports

CONTROL_RESULT='gate_constant_controls_cv29_4090_20261018_v1'
CONTROL_ARCHIVE='Gate_Constant_Controls_CV29_Results_20261018.zip'
CONTROL_SHA='b646515c9980d07ea54f931b820b55f43bde40224d97e33550305d7f11af218e'


def freeze_controls(root,out,source_hashes):
    original=(root/'experiments'/CONTROL_RESULT).resolve();archive=original/CONTROL_ARCHIVE
    if root.resolve() not in original.parents or json.loads((original/'status.json').read_text())['state']!='COMPLETE' or sha(archive)!=CONTROL_SHA:raise ValueError('Wrong/incomplete frozen controls archive')
    frozen=out/'frozen_controls';frozen.mkdir(exist_ok=False)
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None or len(set(z.namelist()))!=len(z.namelist()):raise ValueError('Controls CRC/duplicate entries')
        seal=json.loads(z.read('controls_seal.json'))
        if json.loads(z.read('source_preflight.json'))['input_sha256']!=source_hashes:raise ValueError('Source differs from frozen controls')
        for name,h in seal['files'].items():
            if hashlib.sha256(z.read(name)).hexdigest()!=h:raise ValueError('Frozen input changed: '+name)
        for name in list(seal['files'])+['controls_seal.json']:
            dest=(frozen/name).resolve()
            if frozen.resolve() not in dest.parents:raise ValueError('Unsafe frozen archive member')
            dest.parent.mkdir(parents=True,exist_ok=True)
            with dest.open('xb') as f:f.write(z.read(name))
        with (out/'clean_reference_fold_metrics.csv').open('xb') as f:f.write(z.read('evaluation/fold_metrics.csv'))
    verify_controls(frozen)
    temps={int(k):v for k,v in json.loads((frozen/'frozen_temperatures.json').read_text()).items()}
    write_json(out/'frozen_reuse.json',dict(archive=str(archive),archive_sha256=CONTROL_SHA,heads_trained=0,temps_refitted=False))
    return frozen,temps,archive


def roles(frozen,plan,temps,device):
    result=[('calibrated_fixed',0,FixedWeight(.5).to(device))]
    for reg in ['r005','r0005','r0']:
        result.append((f'optimized_{reg}',0,FixedWeight(read_control(frozen,plan,reg)).to(device)))
        for seed in SEEDS:
            for kind in ['constant','dynamic']:
                name=f'{kind}_{reg}_temporal';result.append((name,seed,load_head(frozen,plan,name,seed,temps,device)))
            result.append((f'mean_{reg}',seed,FixedWeight(read_control(frozen,plan,reg,seed)).to(device)))
    if len(result)!=31 or len({(a,b) for a,b,_ in result})!=31:raise ValueError('Frozen role matrix')
    return result


def replay_clean_rows(collector,fold,old):
    rows=[r for r in collector.fold_rows if r['fold']==fold]
    if len(rows)!=124:raise ValueError('Clean role matrix incomplete')
    for row in rows:
        matches=[r for r in old if (int(r['fold']),r['model'],int(r['seed']),r['policy'])==(fold,row['model'],row['seed'],row['policy'])]
        if len(matches)!=1:raise ValueError('Clean reference identity')
        previous=matches[0]
        for key in ['detected','false_alarms','duplicates','within_1s_detected','within_2s_detected']:
            if row[key]!=int(previous[key]):raise ValueError('Clean alarm replay mismatch: '+str((fold,row['model'],row['seed'],key)))
        for key in ['macro_f1','macro_auprc']:np.testing.assert_allclose(row[key],float(previous[key]),atol=1e-5,rtol=1e-5)


def run_stress(data,prior,frozen,temps,archive,out,update,device='cuda',case_plan=None,finish=True):
    from cv_data import dense_subset
    planned=cases() if case_plan is None else case_plan
    if planned[0]['condition']!='clean':raise ValueError('Clean replay must run first')
    folder=out/'evaluation';folder.mkdir(exist_ok=False)
    collectors={c['case']:StressCollector(folder/c['case']) for c in planned};directions=[];units=0;began=time.monotonic()
    old=read_csv(out/'clean_reference_fold_metrics.csv')
    with zipfile.ZipFile(archive) as z:
        for plan in outer_plan():
            fold=plan['fold'];dense=dense_subset(data,plan['outer']);branch,ck=final_branch(prior,plan,device)
            raw=dict(pose=dense['pose'],rgb=dense['rgb'],quality_indices=data['quality_indices']);p,r,q=normalized(raw,np.arange(len(dense['y'])),ck)
            branch.requires_grad_(False).eval();before=digest(branch);models=roles(frozen,plan,temps,device)
            head_hashes={(n,s):digest(m) for n,s,m in models};clean_weights={}
            for case in planned:
                update(stage='frozen_stress_inference',fold=fold,condition=case['condition'],corruption_seed=case['corruption_seed'],units_complete=units,total_units=len(planned)*3)
                unit_began=time.monotonic();sp,sr,sq,info=perturb(dense['rows'],p,r,q,data['quality_indices'],case)
                cache=forward_branch(branch,sp,sr,sq,device);cache.update(quality=sq,y=dense['y'])
                videos=videos_from_dense(dense,cache,temps[fold]);collector=collectors[case['case']]
                base,_=predict(models[0][2],videos,device)
                for name,seed,model in models:
                    probability,weights=predict(model,videos,device)
                    if case['condition']=='clean':
                        clean_weights[(name,seed)]=weights.copy()
                        with np.load(io.BytesIO(z.read(f'evaluation/fold{fold}/{name}_seed{seed}_predictions.npz')),allow_pickle=False) as a:
                            np.testing.assert_array_equal(a['y'],dense['y'])
                            np.testing.assert_allclose(probability,a['probabilities'],atol=1e-5,rtol=1e-5)
                            np.testing.assert_allclose(weights,a['gate_weights'],atol=1e-5,rtol=1e-5)
                    parameters=1 if name.startswith('optimized_') else sum(t.numel() for t in model.parameters())
                    collector.add(fold,name,seed,probability,weights,dense,base,parameters)
                    directions.append(directionality(case,fold,name,seed,weights,clean_weights[(name,seed)],info))
                target=collector.out/f'fold{fold}'/'stress_mask.npz'
                np.savez(target,affected_frames=info['affected_frames'],window_affected_fraction=info['window_affected_fraction'])
                if case['condition']=='clean':replay_clean_rows(collector,fold,old)
                units+=1;seconds=time.monotonic()-unit_began
                update(units_complete=units,unit_seconds=seconds,elapsed_inference_seconds=time.monotonic()-began)
                print('STRESS_UNIT_COMPLETE',units,'/',len(planned)*3,'fold',fold,case['case'],'seconds',round(seconds,2),flush=True)
                del cache,videos,sp,sr,sq
            if digest(branch)!=before or any(digest(m)!=head_hashes[(n,s)] for n,s,m in models):raise RuntimeError('Frozen model state changed')
            verify_controls(frozen);del branch,dense,p,r,q,models
            if device=='cuda':torch.cuda.empty_cache()
    outputs=[]
    for case in planned:
        update(stage='metrics_and_pairs',condition=case['condition'],corruption_seed=case['corruption_seed'])
        collector=collectors[case['case']];rows=collector.finish(124);paired(collector,rows);outputs.append((case,collector,rows))
    if not finish:return outputs,directions
    update(stage='paired_person_cluster_intervals')
    return finish_reports(out,outputs,directions)
