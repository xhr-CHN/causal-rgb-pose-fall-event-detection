import unittest
import numpy as np
from stress_conditions import cases,perturb


class PerturbationChecks(unittest.TestCase):
    def fixture(self):
        rng=np.random.RandomState(8);rows=[dict(sequence_id='Sx_clip',source_frame_number=i) for i in range(16,52)]
        source=rng.randn(51,95).astype('float32');rgb=rng.randn(51,256).astype('float32');q=rng.rand(51,5).astype('float32')
        ids=np.array([np.arange(r['source_frame_number']-16,r['source_frame_number']) for r in rows])
        return rows,source[ids],rgb[ids],q[ids],[0,1,2,3,4]

    def test_complete_plan(self):
        self.assertEqual(len(cases()),28);self.assertEqual(len({c['case'] for c in cases()}),28)
        self.assertEqual(sum(c['condition']=='clean' for c in cases()),1)

    def test_clean_and_inputs_not_mutated(self):
        rows,p,r,q,qi=self.fixture();before=[a.copy() for a in [p,r,q]]
        a,b,c,_=perturb(rows,p,r,q,qi,cases()[0])
        for x,y in zip([a,b,c],before):np.testing.assert_array_equal(x,y)
        case=next(c for c in cases() if c['family']=='pose_dropout');perturb(rows,p,r,q,qi,case)
        for x,y in zip([p,r,q],before):np.testing.assert_array_equal(x,y)

    def test_overlap_and_prefix(self):
        rows,p,r,q,qi=self.fixture()
        for family in ['pose_dropout','rgb_dropout','pose_noise']:
            case=next(c for c in cases() if c['family']==family)
            a,b,c,info=perturb(rows,p,r,q,qi,case)
            for x in [a,b,c]:np.testing.assert_array_equal(x[0,1:],x[1,:-1])
            prefix=perturb(rows[:11],p[:11],r[:11],q[:11],qi,case)
            for x,y in zip([a,b,c],prefix[:3]):np.testing.assert_array_equal(x[:11],y)

    def test_nested_dropouts_and_modality_isolation(self):
        rows,p,r,q,qi=self.fixture();masks=[]
        for c in [c for c in cases() if c['family']=='pose_dropout' and c['corruption_seed']==1701]:
            a,b,qq,info=perturb(rows,p,r,q,qi,c);mask=info['affected_frames'];masks.append(mask)
            np.testing.assert_array_equal(b,r);self.assertTrue(np.all(a[mask]==0));self.assertTrue(np.all(qq[mask]==0))
        self.assertTrue(np.all(~masks[0]|masks[1]));self.assertTrue(np.all(~masks[1]|masks[2]))
        c=next(c for c in cases() if c['family']=='rgb_dropout');a,b,qq,info=perturb(rows,p,r,q,qi,c)
        np.testing.assert_array_equal(a,p);np.testing.assert_array_equal(qq,q);self.assertTrue(np.all(b[info['affected_frames']]==0))

    def test_noise_quality_unchanged_seeded_and_scaled(self):
        rows,p,r,q,qi=self.fixture();cs=[c for c in cases() if c['family']=='pose_noise' and c['corruption_seed']==1701]
        results=[perturb(rows,p,r,q,qi,c) for c in cs]
        for a,b,qq,info in results:
            np.testing.assert_array_equal(a[:,:,qi],p[:,:,qi]);np.testing.assert_array_equal(b,r);np.testing.assert_array_equal(qq,q)
        np.testing.assert_allclose((results[0][0]-p)*3,results[1][0]-p,atol=5e-7,rtol=1e-5)
        different=dict(cs[0],corruption_seed=1702);a,*_=perturb(rows,p,r,q,qi,different)
        self.assertFalse(np.array_equal(a,results[0][0]))


if __name__=='__main__':unittest.main(verbosity=2)
