"""Compact retained predictions and descriptive paired stress summaries."""
from collections import defaultdict
import numpy as np
from cv_data import write_csv
from suite_eval import Collector
from gate_opt_features import frame_metrics
from gate_dynamic_utils import candidates,event_metrics,POLICIES,METRICS


class StressCollector(Collector):
    def add(self,fold,model,seed,prob,w,dense,base,parameters=0):
        y=dense['y'];prob=np.asarray(prob);w=np.asarray(w)
        if prob.shape!=(len(y),3) or w.shape!=(len(y),) or not np.isfinite(prob).all() or not np.isfinite(w).all():raise ValueError('Prediction schema')
        if not np.allclose(prob.sum(1),1,atol=1e-5) or np.any(prob<0):raise ValueError('Invalid probability')
        pred=prob.argmax(1);fp=base.argmax(1);frame=frame_metrics(y,prob)
        frame.update(frame_errors_repaired_vs_fixed=int(np.sum((fp!=y)&(pred==y))),frame_correct_spoiled_vs_fixed=int(np.sum((fp==y)&(pred!=y))),frame_predictions_changed_vs_fixed=int(np.sum(fp!=pred)))
        self.parts[(model,seed)].append((fold,y,prob,fp))
        folder=self.out/f'fold{fold}';folder.mkdir(exist_ok=True);stem=model+f'_seed{seed}'
        np.savez(folder/(stem+'_predictions.npz'),probabilities=prob,gate_weights=w)
        if not (folder/'frame_inventory.csv').exists():
            write_csv(folder/'frame_inventory.csv',dense['rows']);np.savez(folder/'targets.npz',y=y)
        persons=np.array([r['subject_id'] for r in dense['rows']]);all_alarms=[]
        for policy in POLICIES:
            alarms=candidates(dense['rows'],prob,w,policy);hours=float(np.sum(y==0)/(20*3600));met,events=event_metrics(alarms,dense['specs'],hours)
            if met['fall_events']!={1:10,2:10,3:9}[fold]:raise ValueError('Heldout event count changed')
            self.fold_rows.append(dict(model=model,seed=seed,fold=fold,policy=policy,windows=len(y),parameters=parameters,**frame,**met))
            self.events.extend(dict(model=model,seed=seed,fold=fold,policy=policy,subject_id=dense['specs'][e['sequence_id']]['subject_id'],**e) for e in events)
            all_alarms.extend(dict(policy=policy,**a) for a in alarms)
            for subject in sorted(set(persons)):
                ix=np.flatnonzero(persons==subject);specs={sid:sp for sid,sp in dense['specs'].items() if sp['subject_id']==subject}
                sm,_=event_metrics([a for a in alarms if a['sequence_id'] in specs],specs,float(np.sum(y[ix]==0)/(20*3600)))
                self.persons.append(dict(model=model,seed=seed,fold=fold,policy=policy,subject_id=int(subject),**frame_metrics(y[ix],prob[ix]),**sm))
        write_csv(folder/(stem+'_alarms.csv'),all_alarms,['policy','candidate_id','sequence_id','source_frame_number','sample_timestamp_ms','source_timestamp_ms','fall_score','evidence','gate_weight','threshold'])


def directionality(case,fold,model,seed,weights,clean,info):
    if weights.shape!=clean.shape:raise ValueError('Clean/stress weight alignment')
    affected=info['window_affected_fraction']>0;delta=weights.astype(np.float64)-clean.astype(np.float64)
    sign=info['expected_pose_weight_direction']
    return dict(**case,fold=fold,model=model,seed=seed,windows=len(weights),affected_windows=int(affected.sum()),
        pose_weight_mean=float(np.mean(weights,dtype=np.float64)),pose_weight_sd=float(np.std(weights.astype(np.float64))),
        mean_delta_vs_clean=float(np.mean(delta)),mean_affected_delta=float(np.mean(delta[affected])) if affected.any() else None,
        fraction_expected_direction=float(np.mean(sign*delta[affected]>1e-6)) if affected.any() and sign else None,
        fraction_opposite_direction=float(np.mean(sign*delta[affected]<-1e-6)) if affected.any() and sign else None)


PERSON_KEYS=['fall_events','detected','false_alarms','negative_exposure_hours','within_1s_detected']


def average_people(rows):
    groups=defaultdict(list)
    for r in rows:groups[(r['condition'],r['model'],r['policy'],r['subject_id'])].append(r)
    return {key:np.mean([[float(r[k]) for k in PERSON_KEYS] for r in values],axis=0) for key,values in groups.items()}


def paired_interval(a,b,draws):
    # Rows are already averaged within each subject; repetitions do not add people.
    def score(v,c):
        total=c@v
        return np.stack([total[:,1]/total[:,0],total[:,2]/total[:,3],total[:,4]/total[:,0]],axis=1)
    if a.shape!=b.shape or a.shape!=(6,5) or draws.shape[1]!=6:raise ValueError('Paired subject matrix')
    if np.any(a[:,0]<=0) or np.any(a[:,3]<=0) or not np.allclose(a[:,[0,3]],b[:,[0,3]],atol=1e-12,rtol=0):raise ValueError('Unequal paired denominators')
    difference=score(a,draws)-score(b,draws);point=score(a,np.ones((1,6)))-score(b,np.ones((1,6)))
    return point[0],np.quantile(difference,[.025,.975],axis=0)


def finish_reports(out,case_outputs,directions):
    pooled=[];people=[]
    for case,collector,rows in case_outputs:
        pooled.extend(dict(**case,**r) for r in rows)
        people.extend(dict(**case,**r) for r in collector.persons)
    if len(pooled)!=3472 or len(people)!=20832:raise ValueError('Incomplete stress matrix')
    write_csv(out/'all_pooled_metrics.csv',pooled);write_csv(out/'all_subject_metrics.csv',people);write_csv(out/'gate_directionality.csv',directions)
    grouped=defaultdict(list)
    for r in pooled:grouped[(r['condition'],r['model'],r['policy'])].append(r)
    summary=[]
    for (condition,model,policy),rs in sorted(grouped.items()):
        row=dict(condition=condition,model=model,policy=policy,repeated_evaluations=len(rs),unique_people=6,unique_fall_events=29)
        for k in ['detected','false_alarms','fa_per_hour','within_1s_recall','within_2s_recall','mean_delay_seconds','macro_f1','macro_auprc']:
            vals=[r[k] for r in rs if r[k] is not None];row[k+'_mean']=float(np.mean(vals)) if vals else None
        summary.append(row)
    write_csv(out/'summary_by_condition.csv',summary)
    clean={(r['model'],r['seed'],r['policy']):r for r in pooled if r['condition']=='clean'};deltas=[]
    for r in pooled:
        b=clean[(r['model'],r['seed'],r['policy'])]
        deltas.append(dict(condition=r['condition'],corruption_seed=r['corruption_seed'],model=r['model'],seed=r['seed'],policy=r['policy'],
            **{'delta_'+k:r[k]-b[k] if r[k] is not None and b[k] is not None else None for k in METRICS}))
    write_csv(out/'stress_minus_clean.csv',deltas)
    avg=average_people(people);subjects=[1,3,6,7,8,9];rng=np.random.RandomState(20261018)
    draws=np.array([np.bincount(ids,minlength=6) for ids in rng.randint(0,6,size=(2000,6))],dtype=np.float64);intervals=[]
    for condition in sorted({r['condition'] for r in pooled}):
        for reg in ['r005','r0005','r0']:
            for reference in ['calibrated_fixed',f'optimized_{reg}',f'mean_{reg}']:
                for policy in POLICIES:
                    model=f'dynamic_{reg}_temporal'
                    a=np.stack([avg[(condition,model,policy,s)] for s in subjects]);b=np.stack([avg[(condition,reference,policy,s)] for s in subjects])
                    point,bounds=paired_interval(a,b,draws)
                    for i,key in enumerate(['event_recall','fa_per_hour','within_1s_recall']):
                        intervals.append(dict(condition=condition,model=model,reference=reference,policy=policy,metric=key,delta=float(point[i]),
                            pointwise95_low=float(bounds[0,i]),pointwise95_high=float(bounds[1,i]),clusters=6,resamples=2000,
                            inference='exploratory paired person clusters; repetitions averaged before resampling; shared fold training and repeated inspection limit independence; no multiplicity adjustment or superiority claim'))
    write_csv(out/'exploratory_person_cluster_intervals.csv',intervals)
    lines=['# 冻结模型的预设模态退化诊断','',
        '仅合成特征级压力测试；不是真实遮挡、关键点提取故障或照度控制实验。6人/29事件已多轮查看，不是独立盲测。',
        '正常1次、9种退化各3个预定扰动种子，总28个case。模型、温度、常数、门限全部冻结，无重新训练或测试后调参。',
        '以下是按同一29事件合并三折后，再对门控/扰动重复求均值，绝不把重复当成新增事件或受试者。',
        '原0.85是主工作点，其他全部预设工作点保留在CSV；不能只挑有利条件。','',
        '| 条件 | 模型 | 检出/29均值 | 误报均值 | 1秒内召回 | 平均延迟秒 |',
        '| --- | --- | ---: | ---: | ---: | ---: |']
    for r in summary:
        if r['policy']=='fixed_085' and r['model'] in ['calibrated_fixed','optimized_r005','optimized_r0005','optimized_r0','dynamic_r005_temporal','dynamic_r0005_temporal','dynamic_r0_temporal']:
            vals=[f'{r[k]:.6f}' if r[k] is not None else 'NA' for k in ['detected_mean','false_alarms_mean','within_1s_recall_mean','mean_delay_seconds_mean']]
            lines.append('| '+r['condition']+' | '+r['model']+' | '+' | '.join(vals)+' |')
    lines += ['','完整对照含原常数、优化常数、均值常数化与动态门控。每个case/model_paired_differences.csv包含共同检出集合延迟和检出不一致。',
        'gate_directionality.csv检查姿态退化时权重是否下移、RGB退化时是否上移；方向变化本身不等于性能优势。',
        'exploratory_person_cluster_intervals.csv先在每人内平均所有重复，再配对重抽6人2000次；区间是未调整多重比较的点态探索性区间，不证明显著优势、非劣效或独立泛化。',
        '没有自动选最优方案、重新训练、修改标签或投稿材料。未参与选择的独立视频/人员仍需另行取得并冻结验证协议。']
    (out/'SUMMARY_ZH.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return dict(cases=28,pooled_rows=len(pooled),person_rows=len(people),interval_rows=len(intervals),unique_fall_events=29,unique_people=6)
