import unittest
import numpy as np
from stress_results import directionality,average_people,paired_interval


class StressResultChecks(unittest.TestCase):
    def test_constant_directionality_and_pose_direction(self):
        case=dict(case='a',condition='pose_dropout_10',family='pose_dropout',level=.1,corruption_seed=1701)
        info=dict(window_affected_fraction=np.ones(6),expected_pose_weight_direction=-1)
        row=directionality(case,1,'fixed',0,np.full(6,.5),np.full(6,.5),info)
        self.assertEqual(row['fraction_expected_direction'],0.)
        row=directionality(case,1,'gate',7,np.full(6,.4),np.full(6,.5),info)
        self.assertEqual(row['fraction_expected_direction'],1.)

    def test_repeats_averaged_not_added(self):
        rows=[dict(condition='clean',model='gate',policy='fixed_085',subject_id=s,fall_events=5,detected=4,false_alarms=2,negative_exposure_hours=.02,within_1s_detected=3) for s in [1,3,6,7,8,9]]
        a=average_people(rows);b=average_people(rows*9)
        for k in a:np.testing.assert_array_equal(a[k],b[k])

    def test_cluster_zero_and_known_difference(self):
        a=np.tile([5.,4.,2.,.02,3.],(6,1));draws=np.tile(np.ones(6),(2000,1))
        point,bounds=paired_interval(a,a,draws);np.testing.assert_array_equal(point,[0,0,0]);np.testing.assert_array_equal(bounds,np.zeros((2,3)))
        b=a.copy();b[:,1]-=1;b[:,2]+=1
        point,_=paired_interval(a,b,draws);np.testing.assert_allclose(point,[.2,-50,0])
        b[:,3]=.03
        with self.assertRaises(ValueError):paired_interval(a,b,draws)


if __name__=='__main__':unittest.main(verbosity=2)
