import contextlib
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile
import numpy as np
import torch
from cv_data import outer_plan,SEEDS,write_csv,read_csv
from control_eval import FixedWeight
from gate_dynamic_utils import candidates,event_metrics,POLICIES
from gate_opt_features import gate_features
from stress_conditions import cases
from stress_runtime import run_stress
from stress_results import finish_reports


class StressFlowChecks(unittest.TestCase):
    def test_mocked_full_roles_clean_replay_and_all_reports(self):
        torch.set_num_threads(2);fixtures={};names=[('calibrated_fixed',0)]
        for reg in ['r005','r0005','r0']:
            names.append((f'optimized_{reg}',0))
            for seed in SEEDS:names.extend([(f'constant_{reg}_temporal',seed),(f'dynamic_{reg}_temporal',seed),(f'mean_{reg}',seed)])
        references=[];payload={}
        for plan in outer_plan():
            fold=plan['fold'];rows=[];ys=[];specs={}
            for subject in plan['outer']:
                for category,n in [('fall',4 if subject==9 else 5),('adl',5)]:
                    for j in range(n):
                        sid=f'S{subject}_{category}_{j}';frames=np.arange(16,47);y=np.where(frames<25,0,np.where(frames<30,1,2)) if category=='fall' else np.zeros(len(frames),np.int64)
                        ys.append(y);specs[sid]=dict(category=category,onset=25 if category=='fall' else None,subject_id=subject)
                        rows.extend(dict(sequence_id=sid,subject_id=subject,source_frame_number=int(f),sample_timestamp_ms=(int(f)-1)*50.,source_timestamp_ms=(int(f)-1)*50.) for f in frames)
            y=np.concatenate(ys);prob=np.eye(3,dtype=np.float32)[y]*.98+.02/3;p=np.zeros((len(y),16,95),np.float32);p[:,:,:3]=np.log(prob)[:,None,:]
            dense=dict(y=y,rows=rows,specs=specs,pose=p,rgb=np.zeros((len(y),16,256),np.float32));fixtures[tuple(plan['outer'])]=dense
            logits=p[:,-1,:3];prob=torch.tensor(.5*(logits/2)+.5*(logits/3)).softmax(1).numpy()
            for name,seed in names:
                buffer=io.BytesIO();np.savez(buffer,y=y,probabilities=prob,gate_weights=np.full(len(y),.5,np.float32))
                payload[f'evaluation/fold{fold}/{name}_seed{seed}_predictions.npz']=buffer.getvalue()
                for policy in POLICIES:
                    alarms=candidates(rows,prob,np.full(len(y),.5),policy);m,_=event_metrics(alarms,specs,float(np.sum(y==0)/(20*3600)))
                    references.append(dict(model=name,seed=seed,fold=fold,policy=policy,macro_f1=1.,macro_auprc=1.,**{k:m[k] for k in ['detected','false_alarms','duplicates','within_1s_detected','within_2s_detected']}))
        def final(prior,plan,device):return FixedWeight(.5),dict(pose_mean=np.zeros(95,np.float32),pose_std=np.ones(95,np.float32),rgb_mean=np.zeros(256,np.float32),rgb_std=np.ones(256,np.float32))
        def forward(model,p,r,q,device):
            logits=p[:,-1,:3];prob=torch.tensor(logits).softmax(1).numpy()
            return dict(pose=logits,rgb=logits,features=gate_features(q,prob,prob,temporal=False))
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as directory,contextlib.redirect_stdout(io.StringIO()):
            out=Path(directory).resolve();archive=out/'fixture.zip'
            with zipfile.ZipFile(archive,'x') as z:
                for name,data in payload.items():z.writestr(name,data)
            write_csv(out/'clean_reference_fold_metrics.csv',references)
            temps={p['fold']:dict(pose=dict(temperature=2.),rgb=dict(temperature=3.)) for p in outer_plan()}
            short=cases()[:2]
            with patch('cv_data.dense_subset',lambda data,subjects:fixtures[tuple(subjects)]),patch('stress_runtime.final_branch',final),patch('stress_runtime.forward_branch',forward),patch('stress_runtime.roles',lambda *args:[(n,s,FixedWeight(.5)) for n,s in names]),patch('stress_runtime.verify_controls',lambda *args:None):
                outputs,directions=run_stress(dict(quality_indices=[0,1,2,3,4]),out/'prior',out/'frozen',temps,archive,out,lambda **kw:None,'cpu',short,False)
            self.assertEqual(len(outputs),2);self.assertEqual(len(directions),2*3*31)
            self.assertEqual(len(read_csv(outputs[0][1].out/'fold_metrics.csv')),372)
            # Expand fixed fixtures only to exercise all28-case aggregation, not new inference.
            complete=[(c,outputs[0 if c['condition']=='clean' else 1][1],outputs[0 if c['condition']=='clean' else 1][2]) for c in cases()]
            report=finish_reports(out,complete,directions)
            self.assertEqual(report['pooled_rows'],3472);self.assertEqual(report['person_rows'],20832);self.assertEqual(report['interval_rows'],1080)
            self.assertEqual(len(read_csv(out/'summary_by_condition.csv')),520)


if __name__=='__main__':unittest.main(verbosity=2)
