"""Label-free, physical-frame-keyed synthetic feature stress. No new data."""
import hashlib
import numpy as np

CORRUPTION_SEEDS=[1701,1702,1703]


def cases():
    result=[dict(case='clean',condition='clean',family='clean',level=0.,corruption_seed=0)]
    for family,levels in [('pose_dropout',[.1,.3,.5]),('rgb_dropout',[.1,.3,.5]),('pose_noise',[.1,.3,.5])]:
        for level in levels:
            condition=family+'_'+str(round(level*100))
            for seed in CORRUPTION_SEEDS:result.append(dict(case=condition+'_c'+str(seed),condition=condition,family=family,level=level,corruption_seed=seed))
    return result


def keyed_seed(tag,sid,seed):
    return int.from_bytes(hashlib.sha256((tag+'|'+sid+'|'+str(seed)).encode()).digest()[:4],'little')


def perturb(rows,pose,rgb,quality,quality_indices,case):
    n=len(rows);p,r,q=pose.copy(),rgb.copy(),quality.copy();qi=np.asarray(quality_indices,dtype=int)
    if p.shape!=(n,16,95) or r.shape!=(n,16,256) or q.shape!=(n,16,5) or len(set(qi.tolist()))!=5 or np.any(qi<0) or np.any(qi>=95):raise ValueError('Perturbation schema')
    family=case['family'];level=float(case['level']);seed=int(case['corruption_seed'])
    if family not in ['clean','pose_dropout','rgb_dropout','pose_noise'] or (family!='clean' and level not in [.1,.3,.5]):raise ValueError('Not a preset stress')
    affected=np.zeros((n,16),bool);grouped={}
    for i,row in enumerate(rows):grouped.setdefault(row['sequence_id'],[]).append(i)
    for sid,ids in grouped.items():
        ends=np.array([int(rows[i]['source_frame_number']) for i in ids],np.int64)
        if np.any(ends<16) or len(set(ends.tolist()))!=len(ends):raise ValueError('Invalid physical frame endpoints')
        frames=ends[:,None]-np.arange(15,-1,-1)[None,:];maximum=int(ends.max())
        if family in ['pose_dropout','rgb_dropout']:
            phase=keyed_seed('dropout',sid,seed)%20
            mask=((frames-1+phase)%20)<int(round(level*20));affected[ids]=mask
            if family=='pose_dropout':
                pp=p[ids].copy();qq=q[ids].copy();pp[mask]=0.;qq[mask]=0.;p[ids]=pp;q[ids]=qq
            else:
                rr=r[ids].copy();rr[mask]=0.;r[ids]=rr
        elif family=='pose_noise':
            generator=np.random.RandomState(keyed_seed('pose_feature_noise',sid,seed))
            field=generator.normal(size=(maximum,95)).astype(np.float32);field[:,qi]=0.
            p[ids]+=np.float32(level)*field[frames-1];affected[ids]=True
    if not all(np.isfinite(x).all() for x in [p,r,q]):raise FloatingPointError('Nonfinite corrupted features')
    return p,r,q,dict(affected_frames=affected,window_affected_fraction=affected.mean(1).astype(np.float32),
        expected_pose_weight_direction=0 if family=='clean' else (1 if family=='rgb_dropout' else -1))
