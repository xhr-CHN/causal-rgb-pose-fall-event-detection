"""Matched residual feature heads; original modules retain their state keys."""
import torch
from torch import nn


def make_model(base_class, variant):
    if variant not in ('M0','M1','M2'):
        raise ValueError('Only the three approved conditions are supported')

    class InteractionModel(base_class):
        def __init__(self):
            super().__init__(pose_dim=95,rgb_dim=256,quality_dim=5,hidden_dim=64,dropout=.2)
            self.variant = variant
            if variant != 'M0':
                self.pose_norm = nn.LayerNorm(64,elementwise_affine=False)
                self.rgb_norm = nn.LayerNorm(64,elementwise_affine=False)
                self.pose_projection = nn.Linear(64,16)
                self.rgb_projection = nn.Linear(64,16)
                self.pose_modulation = nn.Linear(26,16)
                self.rgb_modulation = nn.Linear(26,16)
                self.residual = nn.Sequential(nn.Linear(64,16),nn.ReLU(),nn.Linear(16,3))
                nn.init.zeros_(self.residual[-1].weight)
                nn.init.zeros_(self.residual[-1].bias)

        def forward(self,pose,rgb,quality):
            # Exactly one encoder pass: no double BN updates or dropout sampling.
            hp = self.pose_encoder(pose)[:,:,-1]
            hr = self.rgb_encoder(rgb)[:,:,-1]
            pl,rl = self.pose_classifier(hp),self.rgb_classifier(hr)
            pp,rp = pl.softmax(1),rl.softmax(1)
            q = torch.cat([quality.mean(1),quality.min(1).values],1)
            disagreement = (pp.detach()-rp.detach()).abs().mean(1,keepdim=True)
            inputs = torch.cat([q,self.reliability(pp.detach()),self.reliability(rp.detach()),disagreement],1)
            gl = self.gate(inputs)
            weight = gl.sigmoid()
            fused = weight*pl+(1-weight)*rl
            delta = torch.zeros_like(fused)
            if self.variant != 'M0':
                a = self.pose_projection(self.pose_norm(hp)).relu()
                b = self.rgb_projection(self.rgb_norm(hr)).relu()
                up = torch.sigmoid(self.pose_modulation(torch.cat([a,q],1)))*a
                ur = torch.sigmoid(self.rgb_modulation(torch.cat([b,q],1)))*b
                features = torch.cat([a,b,up,ur],1) if self.variant=='M1' else torch.cat([a,b,up+ur,up*ur],1)
                delta = self.residual(features)
            return dict(fused=fused+delta,pose=pl,rgb=rl,gate_logit=gl.squeeze(1),
                        pose_weight=weight.squeeze(1),pose_probabilities=pp,rgb_probabilities=rp,
                        branch_disagreement=disagreement.squeeze(1),residual_logits=delta)

    return InteractionModel()


def paired_corruption(function,pose,rgb,quality,seed):
    """Isolate augmentation RNG, preserving the main CPU and active GPU streams."""
    devices = [pose.device.index] if pose.is_cuda else []
    with torch.random.fork_rng(devices=devices):
        torch.random.default_generator.manual_seed(seed)
        if pose.is_cuda:
            with torch.cuda.device(pose.device):
                torch.cuda.manual_seed(seed)
        return function(pose,rgb,quality)
