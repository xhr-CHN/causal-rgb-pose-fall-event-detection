import contextlib
import io
from pathlib import Path
import tempfile
import unittest
import numpy as np
import torch
from bounded_training import new_head,collate,evidence_curve,loss_terms,fit_head,predict,GROUPS,group_config


def fixture_videos():
    rng=np.random.RandomState(28);videos=[]
    for i,(category,n,onset) in enumerate([('fall',34,23),('adl',19,None),('fall',29,25),('adl',24,None),('fall',31,26)]):
        frames=np.arange(16,16+n);y=np.zeros(n,np.int64) if category=='adl' else np.where(frames<onset,0,np.where(frames<onset+7,1,2))
        videos.append(dict(sequence_id='v'+str(i),subject_id=6,category=category,onset=onset,
            frames=frames,y=y,x=rng.rand(n,29).astype('float32'),pose=rng.randn(n,3).astype('float32'),rgb=rng.randn(n,3).astype('float32')))
    return videos


class BoundedChecks(unittest.TestCase):
    def test_initial_fixed_equivalence_and_bounds(self):
        for kind in ['constant','dynamic']:
            model=new_head(kind,7,'cpu');x=torch.randn(30,29)
            torch.testing.assert_close(model(x),torch.full((30,),.5),rtol=0,atol=0)
            with torch.no_grad():
                if kind=='constant':model.scalar.fill_(100)
                else:model.network[-1].bias.fill_(100)
            w=model(x);self.assertTrue(torch.all((w>=.4)&(w<=.6)))

    def test_recurrence_prefix_padding_and_video_isolation(self):
        score=torch.tensor([[.1,.8,.9,.2],[.9,.8,.5,.6]],requires_grad=True);valid=torch.tensor([[1,1,1,1],[1,1,0,0]],dtype=torch.bool)
        e=evidence_curve(score,valid)
        torch.testing.assert_close(e[0],torch.tensor([.05,.425,.6625,.43125]))
        torch.testing.assert_close(e[1],torch.tensor([.45,.625,.625,.625]))
        torch.testing.assert_close(e[:,:2],evidence_curve(score[:,:2],valid[:,:2]),rtol=0,atol=0)
        (e*valid).sum().backward();self.assertTrue(torch.all(score.grad[1,2:]==0))

    def test_masks_and_empty_positive_batch(self):
        videos=fixture_videos();batch=collate([videos[1],videos[3]],'cpu')
        self.assertEqual(int(batch['positive'].sum()),0)
        model=new_head('dynamic',7,'cpu');w=model(batch['x'].reshape(-1,29)).reshape(batch['valid'].shape)
        loss,parts=loss_terms(w,batch,torch.ones(3),True)
        self.assertTrue(torch.isfinite(loss));self.assertEqual(float(parts['early_positive'].detach()),0.)
        loss.backward();self.assertTrue(all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters()))
        batch=collate([videos[0]],'cpu');frames=videos[0]['frames'];mask=batch['positive'][0].numpy()
        np.testing.assert_array_equal(mask,(frames>=25)&(frames<=43))

    def test_training_reload_and_pair_schedules(self):
        torch.set_num_threads(2);videos=fixture_videos()
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory,contextlib.redirect_stdout(io.StringIO()):
            summaries={}
            for group in GROUPS:
                folder=Path(directory)/group
                summary=fit_head(group,7,videos,folder,lambda **kw:None,dict(fixture=True),device='cpu',epochs=2)
                summaries[group]=summary
                ck=torch.load(folder/'model.pt',map_location='cpu',weights_only=False)
                model=new_head(ck['kind'],ck['seed'],'cpu');model.load_state_dict(ck['state_dict'])
                p,w=predict(model,videos,device='cpu');self.assertEqual(len(p),sum(len(v['y']) for v in videos));self.assertTrue(np.isfinite(p).all())
                self.assertTrue(np.all((w>=.4)&(w<=.6)));self.assertEqual(summary['updates'],4)
            for kind in ['constant','dynamic']:
                for reg in ['r0005','r0']:
                    a,b=kind+'_r005_temporal',kind+'_'+reg+'_temporal'
                    self.assertEqual(summaries[a]['schedule'],summaries[b]['schedule'])
                    self.assertEqual(summaries[a]['initialization_sha256'],summaries[b]['initialization_sha256'])

    def test_coefficient_decomposition_and_finite_gradients(self):
        batch=collate(fixture_videos(),'cpu');cw=torch.ones(3)
        for value in [.05,.005,0.]:
            w=torch.full(batch['valid'].shape,.53,requires_grad=True)
            loss,parts=loss_terms(w,batch,cw,True,value)
            expected=parts['CE']+value*parts['regularization']+.1*(parts['negative']+parts['early_positive'])
            torch.testing.assert_close(loss,expected,rtol=0,atol=0)
            loss.backward();self.assertTrue(torch.isfinite(w.grad).all())
        for value in [-.1,float('nan'),float('inf')]:
            with self.assertRaises(ValueError):loss_terms(w,batch,cw,True,value)
        with self.assertRaises(ValueError):group_config('not_a_group')
        self.assertEqual(len(GROUPS),6)

    def test_gradient_difference_is_only_anchor(self):
        batch=collate(fixture_videos(),'cpu');cw=torch.ones(3)
        w=torch.full(batch['valid'].shape,.53,requires_grad=True)
        high,parts=loss_terms(w,batch,cw,True,.05);low,_=loss_terms(w,batch,cw,True,.005)
        gh=torch.autograd.grad(high,w,retain_graph=True)[0]
        gl=torch.autograd.grad(low,w,retain_graph=True)[0]
        gr=torch.autograd.grad(parts['regularization'],w)[0]
        torch.testing.assert_close(gh-gl,.045*gr,rtol=1e-4,atol=1e-7)


if __name__=='__main__':unittest.main(verbosity=2)
