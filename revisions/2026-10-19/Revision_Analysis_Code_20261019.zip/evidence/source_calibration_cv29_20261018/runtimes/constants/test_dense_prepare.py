import contextlib
import io
from pathlib import Path
import sys
import tempfile
import unittest
import numpy as np
import torch


class DensePrepareChecks(unittest.TestCase):
    def test_dense_OOF_cache_is_subject_excluded_and_replays_sparse(self):
        sys.path.insert(0,str(Path(__file__).parent/'reference_source'));torch.set_num_threads(2)
        from cv_data import SUBJECTS,outer_plan
        from cv_training import fresh_branch,normalized,forward_branch
        from bounded_prepare import prepare_fold
        rng=np.random.RandomState(12);pose=[];rgb=[];meta=[];labels=[];subjects=[];specs={}
        for subject in SUBJECTS:
            for cat in ['adl','fall']:
                sid='S'+str(subject)+'_'+cat;specs[sid]=dict(category=cat,onset=26 if cat=='fall' else None,stable=32 if cat=='fall' else None,subject_id=subject)
                p=rng.rand(44,95).astype('float32');r=rng.rand(44,256).astype('float32')
                for start in [1,5,9,13]:
                    end=start+31;pose.append(p[start-1:end]);rgb.append(r[start-1:end]);subjects.append(subject)
                    labels.append(0 if cat=='adl' or end<26 else (1 if end<32 else 2))
                    meta.append(dict(sequence_id=sid,subject_id=str(subject),start_frame_index=str(start),target_frame_index=str(end)))
        data=dict(pose=np.stack(pose),rgb=np.stack(rgb),y=np.array(labels),subjects=np.array(subjects),meta=meta,specs=specs,quality_indices=[0,1,2,3,4])
        plan=outer_plan()[0];fit_ids=np.flatnonzero(np.isin(data['subjects'],plan['fit']));positions={int(i):j for j,i in enumerate(fit_ids)}
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory,contextlib.redirect_stdout(io.StringIO()):
            root=Path(directory);prior=root/'prior';old=prior/'fold1';old.mkdir(parents=True);out=root/'out';out.mkdir()
            cached={k:np.empty((len(fit_ids),17 if k=='features' else 3),np.float32) for k in ['pose','rgb','features']}
            for subject in plan['fit']:
                folder=old/('inner_held'+str(subject));folder.mkdir();branch=fresh_branch('cpu');branch.eval()
                ck=dict(model_state_dict=branch.state_dict(),fit_subjects=sorted(set(plan['fit'])-{subject}),excluded_subjects=sorted(plan['outer']+[subject]),epochs=18,pose_mean=np.zeros(95,np.float32),pose_std=np.ones(95,np.float32),rgb_mean=np.zeros(256,np.float32),rgb_std=np.ones(256,np.float32))
                torch.save(ck,folder/'model.pt');ids=np.flatnonzero(data['subjects']==subject);p,r,q=normalized(data,ids,ck);values=forward_branch(branch,p,r,q,'cpu')
                dest=np.array([positions[int(i)] for i in ids])
                for k in cached:cached[k][dest]=values[k]
            np.savez(old/'gate_oof_clean.npz',**cached,y=data['y'][fit_ids],global_indices=fit_ids)
            videos=prepare_fold(data,prior,plan,dict(pose=dict(temperature=2.),rgb=dict(temperature=3.)),out,lambda **kw:None,device='cpu')
            self.assertEqual(len(videos),8);self.assertEqual(sum(len(v['y']) for v in videos),232)
            self.assertEqual(set(v['subject_id'] for v in videos),set(plan['fit']))
            self.assertTrue(all(np.all(np.diff(v['frames'])==1) for v in videos))
            self.assertEqual(videos[0]['x'].shape[1],29)


if __name__=='__main__':unittest.main(verbosity=2)
