"""Frozen per-person OOF encoders and frozen archive-bound temperatures."""
import hashlib
import json
from pathlib import Path
import zipfile
import numpy as np
import torch
from cv_data import sha,write_json,dense_subset
from cv_training import fresh_branch,normalized,forward_branch,digest
from gate_opt_features import gate_features
from gate_opt_calibration import softmax

SUITE='gate_suite_cv29_4090_20261018_v1'
SUITE_SHA='ff5d3639ea01bad9b870418d277a6e92d097fdbdd117ab32f6e196b12601bc03'
CAL=['OOF_calibrated_static17_pad29','OOF_calibrated_temporal29']


def verify_temperatures(root,out):
    suite=(root/'experiments'/SUITE).resolve();archive=suite/'Gate_Suite_CV29_Results_20261018.zip'
    if root.resolve() not in suite.parents or json.loads((suite/'status.json').read_text())['state']!='COMPLETE' or sha(archive)!=SUITE_SHA:raise ValueError('Wrong/incomplete calibration suite')
    reused={}
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:raise ValueError('Calibration suite ZIP CRC')
        names=['suite_training_seal.json','source_preflight.json','A_results/fold_metrics.csv']
        for fold in [1,2,3]:
            prefix='A_training/fold'+str(fold)+'/'
            names.extend([prefix+'temperatures.json',prefix+'fit_provenance.json'])
            names.extend(prefix+model+'_seed'+str(seed)+'/model.pt' for model in CAL for seed in [7,42,84])
        for name in names:
            path=(suite/name).resolve()
            if suite not in path.parents or sha(path)!=hashlib.sha256(z.read(name)).hexdigest():raise ValueError('Reused calibration file changed: '+name)
            reused[str(path)]=sha(path)
    temps={fold:json.loads((suite/('A_training/fold'+str(fold))/'temperatures.json').read_text()) for fold in [1,2,3]}
    for values in temps.values():
        if not all(.25<=values[k]['temperature']<=16 for k in ['pose','rgb']):raise ValueError('Invalid frozen temperatures')
    write_json(out/'frozen_temperatures.json',temps)
    write_json(out/'calibration_reuse.json',dict(archive=str(archive),archive_sha256=SUITE_SHA,input_sha256=reused,temperatures_refitted=False))
    return suite,temps,reused


def videos_from_dense(dense,cache,temps):
    p=(cache['pose']/float(temps['pose']['temperature'])).astype(np.float32)
    r=(cache['rgb']/float(temps['rgb']['temperature'])).astype(np.float32)
    q=cache['quality'];x=gate_features(q,softmax(p),softmax(r))
    grouped={}
    for i,row in enumerate(dense['rows']):grouped.setdefault(row['sequence_id'],[]).append(i)
    flat=[i for indices in grouped.values() for i in indices]
    if flat!=list(range(len(x))):raise ValueError('Video rows are interleaved')
    videos=[]
    for sid,indices in grouped.items():
        sp=dense['specs'][sid];frames=np.array([int(dense['rows'][i]['source_frame_number']) for i in indices],np.int64)
        if not np.all(np.diff(frames)==1):raise ValueError('Need consecutive20Hz endpoints')
        videos.append(dict(sequence_id=sid,subject_id=int(sp['subject_id']),category=sp['category'],onset=sp['onset'],
            frames=frames,y=dense['y'][indices].copy(),x=x[indices].copy(),pose=p[indices].copy(),rgb=r[indices].copy()))
    return videos


def prepare_fold(data,prior,plan,temps,out,update,device='cuda'):
    folder=out/('fold'+str(plan['fold']));folder.mkdir(exist_ok=False)
    old=prior/('fold'+str(plan['fold']))
    with np.load(old/'gate_oof_clean.npz',allow_pickle=False) as z:
        global_ids=z['global_indices'].copy();cached={k:z[k].copy() for k in ['pose','rgb','features','y']}
    fit_ids=np.flatnonzero(np.isin(data['subjects'],plan['fit']))
    np.testing.assert_array_equal(global_ids,fit_ids);np.testing.assert_array_equal(cached['y'],data['y'][fit_ids])
    position={int(i):j for j,i in enumerate(global_ids)};videos=[];checks=[]
    for subject in plan['fit']:
        update(stage='dense_OOF_preparation',fold=plan['fold'],held_fit_subject=subject)
        path=old/('inner_held'+str(subject))/'model.pt'
        ck=torch.load(path,map_location='cpu',weights_only=False)
        if ck['fit_subjects']!=sorted(set(plan['fit'])-{subject}) or set(ck['excluded_subjects'])!=set(plan['outer']+[subject]) or ck['epochs']!=18:raise ValueError('OOF encoder subject lineage mismatch')
        branch=fresh_branch(device);branch.load_state_dict(ck['model_state_dict'],strict=True);branch.requires_grad_(False).eval();before=digest(branch)
        ids=np.flatnonzero(data['subjects']==subject);a,b,q=normalized(data,ids,ck)
        sparse=forward_branch(branch,a,b,q,device);dest=np.array([position[int(i)] for i in ids]);differences={}
        for name in ['pose','rgb','features']:
            np.testing.assert_allclose(sparse[name],cached[name][dest],atol=1e-4,rtol=1e-5,err_msg='Original sparse OOF replay '+str(subject)+' '+name)
            differences['old_'+name]=float(np.max(np.abs(sparse[name]-cached[name][dest])))
            if name!='features':np.testing.assert_array_equal(sparse[name].argmax(1),cached[name][dest].argmax(1))
        dense=dense_subset(data,[subject]);raw=dict(pose=dense['pose'],rgb=dense['rgb'],quality_indices=data['quality_indices'])
        a,b,q=normalized(raw,np.arange(len(dense['y'])),ck);values=forward_branch(branch,a,b,q,device);values['quality']=q
        lookup={(r['sequence_id'],int(r['source_frame_number'])):i for i,r in enumerate(dense['rows'])}
        overlap=np.array([lookup[(data['meta'][int(i)]['sequence_id'],int(data['meta'][int(i)]['target_frame_index']))] for i in ids])
        for name in ['pose','rgb','features']:
            np.testing.assert_allclose(values[name][overlap],sparse[name],atol=1e-4,rtol=1e-5,err_msg='Dense/sparse OOF overlap '+str(subject)+' '+name)
            differences['dense_'+name]=float(np.max(np.abs(values[name][overlap]-sparse[name])))
            if name!='features':np.testing.assert_array_equal(values[name][overlap].argmax(1),sparse[name].argmax(1))
        if digest(branch)!=before:raise RuntimeError('Frozen OOF encoder changed')
        videos.extend(videos_from_dense(dense,values,temps));checks.append(dict(subject=subject,encoder_sha256=sha(path),windows=len(dense['y']),differences=differences))
        del branch,ck,dense,sparse,values
        if device=='cuda':torch.cuda.empty_cache()
    if set(v['subject_id'] for v in videos)!=set(plan['fit']) or set(v['subject_id'] for v in videos)&set(plan['outer']):raise ValueError('Training video subject leak')
    offsets=np.r_[0,np.cumsum([len(v['y']) for v in videos])]
    np.savez(folder/'dense_OOF_bank.npz',**{k:np.concatenate([v[k] for v in videos]) for k in ['x','pose','rgb','y','frames']},offsets=offsets)
    write_json(folder/'videos.json',[{k:v[k] for k in ['sequence_id','subject_id','category','onset']} for v in videos])
    write_json(folder/'provenance.json',dict(plan=plan,temperatures=temps,dense20Hz=True,no_fabricated_tails=True,checks=checks,windows=int(offsets[-1]),videos=len(videos),branch_training=False))
    print('DENSE_FIT_OOF_COMPLETE',plan['fold'],len(videos),int(offsets[-1]),flush=True)
    return videos
