"""Copy only sealed dense training banks from the completed immutable archive."""
import hashlib
import io
import json
from pathlib import Path
import zipfile
import numpy as np
from cv_data import sha,outer_plan,write_json

BOUNDED_RESULT='gate_bounded_timely_cv29_4090_20261018_v1'
BOUNDED_ARCHIVE='Gate_Bounded_Timely_CV29_Results_20261018.zip'
BOUNDED_SHA='b23e7c8c8072103c06a1d66ea99bd2b25304230f18651676a9752adfe98630ec'


def decode_bank(raw,metadata,plan):
    videos=json.loads(metadata.decode('utf-8'))
    if len({v['sequence_id'] for v in videos})!=len(videos):raise ValueError('Duplicate training sequence')
    if set(v['subject_id'] for v in videos)!=set(plan['fit']):raise ValueError('Training subject lineage')
    with np.load(io.BytesIO(raw),allow_pickle=False) as a:
        arrays={k:a[k].copy() for k in ['x','pose','rgb','y','frames','offsets']}
    offsets=arrays.pop('offsets');n=len(arrays['y'])
    if offsets.dtype.kind not in 'iu' or len(offsets)!=len(videos)+1 or offsets[0]!=0 or offsets[-1]!=n or not np.all(np.diff(offsets)>0):raise ValueError('Invalid bank offsets')
    if arrays['x'].shape!=(n,29) or arrays['pose'].shape!=(n,3) or arrays['rgb'].shape!=(n,3) or arrays['y'].shape!=(n,) or arrays['frames'].shape!=(n,):raise ValueError('Bank dimensions')
    if arrays['frames'].dtype.kind not in 'iu' or arrays['y'].dtype.kind not in 'iu' or not np.isin(arrays['y'],[0,1,2]).all():raise ValueError('Invalid frames/labels')
    if not all(np.isfinite(v).all() for v in arrays.values()):raise ValueError('Nonfinite cached bank')
    for i,v in enumerate(videos):
        for key,value in arrays.items():v[key]=value[int(offsets[i]):int(offsets[i+1])]
        if not np.all(np.diff(v['frames'])==1):raise ValueError('Non-dense bank')
        if v['category'] not in ['fall','adl'] or (v['category']=='fall' and not isinstance(v['onset'],int)):raise ValueError('Explicit annotation required')
    return videos


def reuse(root,out,temps,source_hashes):
    folder=(root/'experiments'/BOUNDED_RESULT).resolve();archive=folder/BOUNDED_ARCHIVE
    if root.resolve() not in folder.parents or json.loads((folder/'status.json').read_text())['state']!='COMPLETE':raise ValueError('Prior bounded run incomplete')
    if sha(archive)!=BOUNDED_SHA:raise ValueError('Prior bounded result ZIP hash mismatch')
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None or len(z.namelist())!=len(set(z.namelist())):raise ValueError('Prior archive CRC/duplicate entries')
        seal=json.loads(z.read('training_seal.json'))
        if seal['heads']!=36 or not seal['all_training_complete_before_outer_evaluation']:raise ValueError('Prior seal incomplete')
        sealed=seal['checkpoints_and_banks']
        if sum(k.endswith('/model.pt') for k in sealed)!=36:raise ValueError('Prior checkpoint count')
        for name,h in sealed.items():
            if hashlib.sha256(z.read(name)).hexdigest()!=h:raise ValueError('Prior seal altered: '+name)
        if json.loads(z.read('source_preflight.json'))['input_sha256']!=source_hashes:raise ValueError('Source differs from prior dense run')
        frozen=json.loads(z.read('frozen_temperatures.json'))
        if frozen!={str(k):v for k,v in temps.items()}:raise ValueError('Frozen temperature mismatch')
        prepared=out/'prepared';prepared.mkdir(exist_ok=False);banks={};copied={}
        for plan in outer_plan():
            prefix='prepared/fold'+str(plan['fold'])+'/'
            names=[prefix+name for name in ['dense_OOF_bank.npz','videos.json','provenance.json']]
            if not all(name in sealed for name in names):raise ValueError('Training bank not sealed')
            provenance=json.loads(z.read(names[2]))
            if provenance['plan']!=plan or provenance['temperatures']!=temps[plan['fold']] or not provenance['dense20Hz'] or provenance['branch_training']:raise ValueError('Cached bank role mismatch')
            banks[plan['fold']]=decode_bank(z.read(names[0]),z.read(names[1]),plan)
            for name in names:
                target=out/name;target.parent.mkdir(parents=True,exist_ok=True)
                with target.open('xb') as f:f.write(z.read(name))
                copied[name]=sha(target)
    write_json(out/'bank_reuse.json',dict(archive=str(archive),archive_sha256=BOUNDED_SHA,copied_sha256=copied,training_inputs_only=True))
    print('SEALED_DENSE_BANK_REUSE_PASS', {k:sum(len(v['y']) for v in vs) for k,vs in banks.items()},flush=True)
    return banks,{str(archive):BOUNDED_SHA}
