"""Frozen scalar and mean-collapse controls, using unchanged candidate policies."""
import json
import math
import numpy as np
import torch
from cv_data import outer_plan,dense_subset,SEEDS,read_csv,write_csv
from cv_training import normalized,forward_branch
from suite_prepare import final_branch
from suite_eval import Collector
from bounded_prepare import videos_from_dense
from bounded_training import predict
from control_math import REGS
from control_reuse import load_head,verify_controls
from gate_dynamic_utils import POLICIES,METRICS


class FixedWeight(torch.nn.Module):
    def __init__(self,weight):
        super().__init__();self.weight=float(weight)
        if not math.isfinite(self.weight) or not .4-1e-7<=self.weight<=.6+1e-7:raise ValueError('Fixed control weight')
    def forward(self,x):return torch.full((len(x),),self.weight,dtype=torch.float32,device=x.device)


def read_control(out,plan,reg,seed=None):
    name=f'optimized_{reg}.json' if seed is None else f'mean_{reg}_seed{seed}.json'
    row=json.loads((out/'derived'/f'fold{plan["fold"]}'/name).read_text())
    if row['fold']!=plan['fold'] or row['fit_subjects']!=plan['fit'] or row['excluded_subjects']!=plan['outer'] or row['outer_data_used']:raise ValueError('Control fit/outer lineage')
    if seed is None:
        if row['coefficient']!=REGS[reg] or row['interval']!=[.4,.6]:raise ValueError('Optimized scalar role')
    elif row['seed']!=seed or row['reg']!=reg:raise ValueError('Mean-collapse role')
    return row['weight_float32']


def paired(collector,rows):
    table={(r['model'],r['seed'],r['policy']):r for r in rows};events={};output=[]
    for r in collector.events:
        if r['category']=='fall':events.setdefault((r['model'],r['seed'],r['policy']),{})[r['sequence_id']]=r
    pairs=[]
    for reg in REGS:
        for seed in SEEDS:
            model=f'dynamic_{reg}_temporal'
            pairs += [(model,seed,b,bs) for b,bs in [('calibrated_fixed',0),(f'constant_{reg}_temporal',seed),(f'optimized_{reg}',0),(f'mean_{reg}',seed)]]
        pairs.append((f'optimized_{reg}',0,'calibrated_fixed',0))
    for a,seed,b,bs in pairs:
        for policy in POLICIES:
            x,y=table[(a,seed,policy)],table[(b,bs,policy)];ea,eb=events[(a,seed,policy)],events[(b,bs,policy)]
            if set(ea)!=set(eb) or len(ea)!=29:raise ValueError('Paired29 event identities')
            shared=[sid for sid in ea if ea[sid]['detected'] and eb[sid]['detected']]
            delays=[ea[sid]['delay_seconds']-eb[sid]['delay_seconds'] for sid in shared]
            row=dict(model=a,seed=seed,reference=b,reference_seed=bs,policy=policy,
                **{'delta_'+k:x[k]-y[k] if x[k] is not None and y[k] is not None else None for k in METRICS})
            row.update(A_only_detected=sum(ea[k]['detected'] and not eb[k]['detected'] for k in ea),B_only_detected=sum(eb[k]['detected'] and not ea[k]['detected'] for k in ea),
                matched_detected=len(shared),mean_delay_change_matched=float(np.mean(delays)) if delays else None,
                earlier=sum(d< -1e-8 for d in delays),later=sum(d>1e-8 for d in delays),unchanged=sum(abs(d)<=1e-8 for d in delays))
            output.append(row)
    write_csv(collector.out/'model_paired_differences.csv',output)


def evaluate_controls(data,prior,temps,out,update,device='cuda'):
    verify_controls(out);collector=Collector(out/'evaluation');previous=read_csv(out/'reused_reference_fold_metrics.csv');replayed=0
    for plan in outer_plan():
        fold=plan['fold'];update(stage='outer_evaluation',fold=fold,phase='all_controls_sealed')
        dense=dense_subset(data,plan['outer']);branch,ck=final_branch(prior,plan,device)
        raw=dict(pose=dense['pose'],rgb=dense['rgb'],quality_indices=data['quality_indices']);p,r,q=normalized(raw,np.arange(len(dense['y'])),ck)
        cache=forward_branch(branch,p,r,q,device);cache.update(quality=q,y=dense['y'])
        videos=videos_from_dense(dense,cache,temps[fold]);base,w=predict(FixedWeight(.5).to(device),videos,device)
        collector.add(fold,'calibrated_fixed',0,base,w,dense,base)
        for reg in REGS:
            value=read_control(out,plan,reg);probability,weights=predict(FixedWeight(value).to(device),videos,device)
            collector.add(fold,f'optimized_{reg}',0,probability,weights,dense,base,1)
            for seed in SEEDS:
                for kind in ['constant','dynamic']:
                    group=f'{kind}_{reg}_temporal';head=load_head(out,plan,group,seed,temps,device)
                    probability,weights=predict(head,videos,device)
                    collector.add(fold,group,seed,probability,weights,dense,base,sum(p.numel() for p in head.parameters()))
                value=read_control(out,plan,reg,seed);probability,weights=predict(FixedWeight(value).to(device),videos,device)
                collector.add(fold,f'mean_{reg}',seed,probability,weights,dense,base,0)
        for row in [v for v in collector.fold_rows if v['fold']==fold and (v['model']=='calibrated_fixed' or v['model'].startswith(('constant_','dynamic_')))]:
            old=next(v for v in previous if v['model']==row['model'] and int(v['seed'])==row['seed'] and int(v['fold'])==fold and v['policy']==row['policy'])
            for key in ['detected','false_alarms','duplicates','within_1s_detected','within_2s_detected']:
                if int(old[key])!=row[key]:raise ValueError('Reused reference alarm replay mismatch: '+str((fold,row['model'],row['seed'],key)))
            for key in ['macro_f1','macro_auprc']:np.testing.assert_allclose(row[key],float(old[key]),atol=1e-5,rtol=1e-5)
            replayed+=1
        print('CONTROLS_OUTER_FOLD_COMPLETE',fold,flush=True)
        del branch,cache,videos,dense
        if device=='cuda':torch.cuda.empty_cache()
    rows=collector.finish(124);paired(collector,rows);verify_controls(out)
    lines=['# 充分优化常数与训练均值常数化：机制对照','',
        '所有新权重仅用训练OOF确定；无分支/门控重训，无温度重拟合，全部封存后才进行本轮外层预测。',
        'optimized_r*为201点固定范围网格+局部细化的标量数值解，不是全球最优证明；使用全训练bank目标，没有AdamW衰减，与旧随机小批CE权重不完全相同。',
        'mean_r*是每个旧动态门控在训练OOF所有有效帧上的平均权重；不是外层权重均值。',
        'constant_r*_temporal、dynamic_r*_temporal均为前轮冻结的原18轮模型；不是本次重新训练。',
        '29事件/6人已多轮查看，是探索性内部机制分析。所有门限和系数都保留，不自动选最佳配置或改投稿材料。','',
        '| 模型 | 门限 | 平均检出/29 | 平均误报 | 1秒内召回 | 2秒内召回 | 平均延迟秒 | 帧宏AP |',
        '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    names=['calibrated_fixed']+[n for reg in REGS for n in [f'optimized_{reg}',f'constant_{reg}_temporal',f'mean_{reg}',f'dynamic_{reg}_temporal']]
    for name in names:
        for policy in POLICIES:
            selected=[r for r in rows if r['model']==name and r['policy']==policy];values=[]
            for key in ['detected','false_alarms','within_1s_recall','within_2s_recall','mean_delay_seconds','macro_auprc']:
                v=[r[key] for r in selected if r[key] is not None];values.append(f'{np.mean(v):.6f}' if v else 'NA')
            lines.append('| '+name+' | '+policy+' | '+' | '.join(values)+' |')
    lines += ['','解释：先看同误报/检出条件下的及时召回及同一检出集合延迟，再判断动态是否超出优化常数/训练均值控制。',
        '三个种子不是87个独立事件；某模型在已查看外层数据上较好，不构成独立选择与验证。',
        '时序替代损失不含硬锁存/复位，最终以原候选报警规则评价；不得外推论文最终验证器或部署能力。']
    (collector.out/'SUMMARY_ZH.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return dict(pooled_rows=len(rows),fold_rows=len(collector.fold_rows),subject_rows=len(collector.persons),reference_fold_rows_replayed=replayed,unique_events=29)
