import contextlib
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import torch
from cv_data import outer_plan,SEEDS,write_json,write_csv,sha,read_csv
from bounded_training import GROUPS,new_head,group_config
from bounded_eval import evaluate
from bounded_prepare import CAL
from suite_heads import new_head as old_head
from gate_opt_features import gate_features
from gate_dynamic_utils import candidates,event_metrics,POLICIES


class EvaluationChecks(unittest.TestCase):
    def test_full100_row_matrix_and_matched_delays(self):
        torch.set_num_threads(2);fixtures={}
        for plan in outer_plan():
            rows=[];ys=[];specs={}
            for subject in plan['outer']:
                for category,n in [('fall',4 if subject==9 else 5),('adl',5)]:
                    for j in range(n):
                        sid='S'+str(subject)+'_'+category+'_'+str(j);frames=np.arange(16,47)
                        y=np.where(frames<25,0,np.where(frames<30,1,2)) if category=='fall' else np.zeros(len(frames),np.int64)
                        ys.append(y);specs[sid]=dict(category=category,onset=25 if category=='fall' else None,subject_id=subject)
                        rows.extend(dict(sequence_id=sid,subject_id=subject,source_frame_number=int(f),sample_timestamp_ms=(int(f)-1)*50.,source_timestamp_ms=(int(f)-1)*50.) for f in frames)
            y=np.concatenate(ys);prob=np.eye(3,dtype=np.float32)[y]*.98+.02/3;p=np.zeros((len(y),16,95),np.float32);p[:,:,:3]=np.log(prob)[:,None,:]
            fixtures[tuple(plan['outer'])]=dict(y=y,rows=rows,specs=specs,pose=p,rgb=np.zeros((len(y),16,256),np.float32))
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory,contextlib.redirect_stdout(io.StringIO()):
            root=Path(directory);out=root/'out';out.mkdir();suite=root/'suite';suite.mkdir();(suite/'A_results').mkdir();oldmetrics=[]
            temps={p['fold']:dict(pose=dict(temperature=2.),rgb=dict(temperature=3.)) for p in outer_plan()}
            for plan in outer_plan():
                fold=plan['fold'];folder=out/'prepared'/('fold'+str(fold));folder.mkdir(parents=True);(folder/'dense_OOF_bank.npz').write_bytes(b'fixture')
                sf=suite/'A_training'/('fold'+str(fold));sf.mkdir(parents=True);write_json(sf/'fit_provenance.json',{})
                for seed in SEEDS:
                    for group in GROUPS:
                        target=out/'training'/('fold'+str(fold))/(group+'_seed'+str(seed));target.mkdir(parents=True)
                        kind=group.split('_')[0];model=new_head(kind,seed,'cpu')
                        torch.save(dict(state_dict=model.state_dict(),group=group,kind=kind,seed=seed,epochs=18,bound=.1,reg_coefficient=group_config(group)[1],provenance=dict(fit_subjects=plan['fit'],excluded_subjects=plan['outer'],temperatures=temps[fold],bank_sha256=sha(folder/'dense_OOF_bank.npz'))),target/'model.pt')
                    for name in CAL:
                        target=sf/(name+'_seed'+str(seed));target.mkdir();model=old_head(name,29,seed,'cpu')
                        torch.save(dict(state_dict=model.state_dict(),variant=name,width=29,seed=seed,epochs=18,transform=dict(variant=name,temperatures=[2.,3.],mean=[0.]*29,std=[1.]*29),provenance=dict(fit_subjects=plan['fit'],excluded_subjects=plan['outer'],fit_provenance_sha256=sha(sf/'fit_provenance.json'))),target/'model.pt')
                dense=fixtures[tuple(plan['outer'])];logits=dense['pose'][:,-1,:3]
                prob=torch.tensor(.5*(logits/2)+.5*(logits/3)).softmax(1).numpy()
                for name,seed in [('calibrated_fixed',0)]+[(c,s) for s in SEEDS for c in CAL]:
                    for policy in POLICIES:
                        a=candidates(dense['rows'],prob,np.full(len(prob),.5),policy);m,_=event_metrics(a,dense['specs'],float(np.sum(dense['y']==0)/(20*3600)))
                        oldmetrics.append(dict(model=name,seed=seed,fold=fold,policy=policy,macro_f1=1.,macro_auprc=1.,**{k:m[k] for k in ['detected','false_alarms','duplicates','within_1s_detected','within_2s_detected']}))
            write_csv(suite/'A_results/fold_metrics.csv',oldmetrics)
            def final(prior,plan,device):return None,dict(pose_mean=np.zeros(95,np.float32),pose_std=np.ones(95,np.float32),rgb_mean=np.zeros(256,np.float32),rgb_std=np.ones(256,np.float32))
            def forward(model,p,r,q,device):
                logits=p[:,-1,:3];prob=torch.tensor(logits).softmax(1).numpy()
                return dict(pose=logits,rgb=logits,features=gate_features(q,prob,prob,temporal=False))
            with patch('bounded_eval.dense_subset',lambda data,subjects:fixtures[tuple(subjects)]),patch('bounded_eval.final_branch',final),patch('bounded_eval.forward_branch',forward):
                report=evaluate(dict(quality_indices=[0,1,2,3,4]),root/'prior',suite,temps,out,lambda **kw:None,device='cpu')
            self.assertEqual(report['pooled_rows'],100);self.assertEqual(report['fold_rows'],300);self.assertEqual(report['subject_rows'],600)
            self.assertEqual(len(read_csv(out/'evaluation/model_paired_differences.csv')),156)
            self.assertTrue(all(r['fall_events']=='29' for r in read_csv(out/'evaluation/pooled_metrics_by_seed.csv')))


if __name__=='__main__':unittest.main(verbosity=2)
