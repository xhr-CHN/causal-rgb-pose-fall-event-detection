"""Training-only scalar controls; GPU FP64 evaluation, no branch gradients."""
import math
import numpy as np
import torch
from bounded_training import collate

REGS={'r005':.05,'r0005':.005,'r0':0.}


def block_evidence(score,valid):
    if score.ndim!=2 or valid.shape!=score.shape:raise ValueError('Evidence shape')
    if torch.any(valid[:,1:] & ~valid[:,:-1]):raise ValueError('Only trailing padding allowed')
    clean=torch.where(valid,score.clamp(0,1),torch.zeros_like(score));state=torch.zeros_like(clean[:,:1]);parts=[]
    for start in range(0,score.shape[1],64):
        block=clean[:,start:start+64];index=torch.arange(block.shape[1],device=score.device,dtype=score.dtype)
        value=(state+(block*torch.pow(2.,index)).cumsum(-1))*torch.pow(.5,index+1)
        parts.append(value);state=value[:,-1:]
    return torch.cat(parts,-1)


class ScalarObjective:
    """Full-bank CE plus sequence-balanced temporal terms; not minibatch CE mean."""
    def __init__(self,videos,device='cuda'):
        self.batch=collate(videos,device);self.device=device
        self.batch['pose']=self.batch['pose'].double();self.batch['rgb']=self.batch['rgb'].double()
        y=np.concatenate([v['y'] for v in videos]);counts=np.bincount(y,minlength=3)
        if np.any(counts==0):raise ValueError('Missing class')
        self.cw=torch.as_tensor(len(y)/(3.*counts),dtype=torch.float64,device=device)
        self.cache={};self.evaluations=0

    @torch.no_grad()
    def _parts(self,weights):
        b=self.batch;w=torch.as_tensor(weights,device=self.device,dtype=torch.float64)[:,None,None,None]
        logits=w*b['pose'][None]+(1-w)*b['rgb'][None]
        valid=b['valid'];flat=logits[:,valid];labels=b['y'][valid];cw=self.cw[labels]
        correct=flat.gather(-1,labels[None,:,None].expand(len(weights),-1,1)).squeeze(-1)
        ce=((flat.logsumexp(-1)-correct)*cw[None]).sum(-1)/cw.sum()
        score=logits.softmax(-1)[...,1:].sum(-1)
        e=block_evidence(score.reshape(-1,score.shape[-1]),valid.repeat(len(weights),1)).reshape(score.shape).clamp(1e-6,1-1e-6)
        def balanced(values,mask):
            count=mask.sum(-1);eligible=count>0
            means=(values*mask[None]).sum(-1)/count.clamp_min(1)[None]
            return (means*eligible[None]).sum(-1)/eligible.sum().clamp_min(1)
        neg=balanced(-torch.log1p(-e),b['negative']);pos=balanced(-torch.log(e),b['positive'])
        return torch.stack([ce,neg,pos],-1).cpu().numpy()

    def values(self,weights,coefficient):
        weights=np.asarray(weights,dtype=np.float64).reshape(-1)
        if not len(weights) or not np.isfinite(weights).all() or np.any(weights<.4-1e-7) or np.any(weights>.6+1e-7):raise ValueError('Weights outside fixed interval')
        if not math.isfinite(coefficient) or coefficient<0:raise ValueError('Invalid regularization')
        missing=sorted({float(w) for w in weights if float(w) not in self.cache})
        for start in range(0,len(missing),32):
            block=missing[start:start+32];parts=self._parts(block)
            if not np.isfinite(parts).all():raise FloatingPointError('Nonfinite scalar objective')
            self.cache.update({w:tuple(float(x) for x in p) for w,p in zip(block,parts)});self.evaluations+=len(block)
        parts=np.asarray([self.cache[float(w)] for w in weights])
        return parts[:,0]+.1*(parts[:,1]+parts[:,2])+coefficient*((weights-.5)/.1)**2


def golden(function,left,right,tolerance=1e-7,max_steps=80):
    ratio=(math.sqrt(5.)-1.)/2.;c=right-ratio*(right-left);d=left+ratio*(right-left)
    fc,fd=function(c),function(d);steps=0
    while right-left>tolerance and steps<max_steps:
        if fc<fd:right,d,fd=d,c,fc;c=right-ratio*(right-left);fc=function(c)
        else:left,c,fc=c,d,fd;d=left+ratio*(right-left);fd=function(d)
        steps+=1
    if right-left>tolerance:raise RuntimeError('Scalar refinement did not finish')
    return dict(weight=(left+right)/2.,left=left,right=right,steps=steps)


def fit_scalar(objective,coefficient,update=None):
    grid=np.linspace(.4,.6,201,dtype=np.float64);values=objective.values(grid,coefficient)
    if not np.isfinite(values).all():raise FloatingPointError('Scalar grid objective')
    best=int(np.argmin(values));indices={best}
    for i in range(1,len(grid)-1):
        if values[i]<=values[i-1] and values[i]<=values[i+1] and (values[i]<values[i-1]-1e-12 or values[i]<values[i+1]-1e-12):indices.add(i)
    candidates=[(float(w),float(v)) for w,v in zip(grid,values)];refinements=[]
    f=lambda w:float(objective.values([w],coefficient)[0])
    for i in sorted(indices):
        if i in [0,len(grid)-1]:continue
        item=golden(f,float(grid[i-1]),float(grid[i+1]));item['objective']=f(item['weight']);refinements.append(item)
        candidates.append((item['weight'],item['objective']))
        if update:update(refinements_complete=len(refinements))
    minimum=min(v for w,v in candidates)
    weight,value=min([(w,v) for w,v in candidates if v<=minimum+1e-12],key=lambda pair:abs(pair[0]-.5))
    rounded=float(np.float32(weight));selected=f(rounded);baseline=f(.5)
    if selected>baseline+1e-7:raise ValueError('Optimized scalar worse than fixed half on fit objective')
    return dict(weight_float64=weight,weight_float32=rounded,selected_objective=selected,fixed_half_objective=baseline,
        coefficient=coefficient,grid_points=201,grid_step=.001,interval=[.4,.6],refinement_tolerance=1e-7,refinements=refinements,
        at_boundary=bool(min(abs(weight-.4),abs(weight-.6))<1e-6),numerical_search_not_global_proof=True,
        objective='full-bank weighted CE + lambda normalized anchor +0.1 sequence-balanced negative/early-positive BCE; no AdamW weight decay',
        grid=[dict(weight=float(w),objective=float(v)) for w,v in zip(grid,values)])


def mean_training_weight(weights):
    w=np.asarray(weights,dtype=np.float64)
    if w.ndim!=1 or not len(w) or not np.isfinite(w).all() or np.any(w<.4-1e-7) or np.any(w>.6+1e-7):raise ValueError('Invalid training weights')
    return float(np.mean(w))
