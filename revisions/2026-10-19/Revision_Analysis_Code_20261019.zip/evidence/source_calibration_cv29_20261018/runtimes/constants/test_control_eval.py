import contextlib
import io
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch
import numpy as np
import torch
from cv_data import outer_plan,SEEDS,write_json,write_csv,sha,read_csv
from bounded_training import GROUPS,new_head,group_config
from gate_dynamic_utils import candidates,event_metrics,POLICIES
from gate_opt_features import gate_features
from control_reuse import derive_controls,seal_controls,verify_controls
from control_eval import evaluate_controls,read_control


class FullControlChecks(unittest.TestCase):
    def test_all_controls_sealed_and_full124_rows(self):
        torch.set_num_threads(2);fixtures={};banks={}
        for plan in outer_plan():
            rows=[];ys=[];specs={}
            for subject in plan['outer']:
                for category,n in [('fall',4 if subject==9 else 5),('adl',5)]:
                    for j in range(n):
                        sid=f'S{subject}_{category}_{j}';frames=np.arange(16,47)
                        y=np.where(frames<25,0,np.where(frames<30,1,2)) if category=='fall' else np.zeros(len(frames),np.int64)
                        ys.append(y);specs[sid]=dict(category=category,onset=25 if category=='fall' else None,subject_id=subject)
                        rows.extend(dict(sequence_id=sid,subject_id=subject,source_frame_number=int(f),sample_timestamp_ms=(int(f)-1)*50.,source_timestamp_ms=(int(f)-1)*50.) for f in frames)
            y=np.concatenate(ys);prob=np.eye(3,dtype=np.float32)[y]*.98+.02/3;p=np.zeros((len(y),16,95),np.float32);p[:,:,:3]=np.log(prob)[:,None,:]
            fixtures[tuple(plan['outer'])]=dict(y=y,rows=rows,specs=specs,pose=p,rgb=np.zeros((len(y),16,256),np.float32))
            videos=[]
            for subject in plan['fit']:
                for category in ['fall','adl']:
                    frames=np.arange(16,47);y=np.where(frames<25,0,np.where(frames<30,1,2)) if category=='fall' else np.zeros(len(frames),np.int64)
                    logits=np.log(np.eye(3,dtype=np.float32)[y]*.98+.02/3)
                    videos.append(dict(sequence_id=f'S{subject}_{category}',subject_id=subject,category=category,onset=25 if category=='fall' else None,
                        frames=frames,y=y,pose=logits,rgb=logits.copy(),x=np.zeros((len(y),29),np.float32)))
            banks[plan['fold']]=videos
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as directory,contextlib.redirect_stdout(io.StringIO()):
            out=Path(directory)/'out';out.mkdir();temps={p['fold']:dict(pose=dict(temperature=2.),rgb=dict(temperature=3.)) for p in outer_plan()}
            write_json(out/'frozen_temperatures.json',temps);write_json(out/'protocol.json',dict(fixture=True));previous=[]
            with self.assertRaises(ValueError):seal_controls(out)
            for plan in outer_plan():
                fold=plan['fold'];folder=out/'prepared'/f'fold{fold}';folder.mkdir(parents=True);(folder/'dense_OOF_bank.npz').write_bytes(b'fixture')
                for seed in SEEDS:
                    for group in GROUPS:
                        target=out/'training'/f'fold{fold}'/f'{group}_seed{seed}';target.mkdir(parents=True);kind,coef=group_config(group);head=new_head(kind,seed,'cpu')
                        torch.save(dict(state_dict=head.state_dict(),group=group,kind=kind,seed=seed,epochs=18,bound=.1,reg_coefficient=coef,
                            provenance=dict(fit_subjects=plan['fit'],excluded_subjects=plan['outer'],temperatures=temps[fold],bank_sha256=sha(folder/'dense_OOF_bank.npz'))),target/'model.pt')
                dense=fixtures[tuple(plan['outer'])];logits=dense['pose'][:,-1,:3];prob=torch.tensor(.5*(logits/2)+.5*(logits/3)).softmax(1).numpy()
                for name,seed in [('calibrated_fixed',0)]+[(g,s) for g in GROUPS for s in SEEDS]:
                    for policy in POLICIES:
                        alarms=candidates(dense['rows'],prob,np.full(len(prob),.5),policy);m,_=event_metrics(alarms,dense['specs'],float(np.sum(dense['y']==0)/(20*3600)))
                        previous.append(dict(model=name,seed=seed,fold=fold,policy=policy,macro_f1=1.,macro_auprc=1.,**{k:m[k] for k in ['detected','false_alarms','duplicates','within_1s_detected','within_2s_detected']}))
            write_csv(out/'reused_reference_fold_metrics.csv',previous)
            derive_controls(banks,out,temps,lambda **kw:None,'cpu');seal_controls(out);verify_controls(out)
            def final(prior,plan,device):return None,dict(pose_mean=np.zeros(95,np.float32),pose_std=np.ones(95,np.float32),rgb_mean=np.zeros(256,np.float32),rgb_std=np.ones(256,np.float32))
            def forward(model,p,r,q,device):
                logits=p[:,-1,:3];prob=torch.tensor(logits).softmax(1).numpy()
                return dict(pose=logits,rgb=logits,features=gate_features(q,prob,prob,temporal=False))
            with patch('control_eval.dense_subset',lambda data,subjects:fixtures[tuple(subjects)]),patch('control_eval.final_branch',final),patch('control_eval.forward_branch',forward):
                report=evaluate_controls(dict(quality_indices=[0,1,2,3,4]),out/'prior',temps,out,lambda **kw:None,'cpu')
            self.assertEqual(report['pooled_rows'],124);self.assertEqual(report['fold_rows'],372);self.assertEqual(report['subject_rows'],744)
            self.assertEqual(report['reference_fold_rows_replayed'],228)
            self.assertEqual(len(read_csv(out/'evaluation/model_paired_differences.csv')),156)
            self.assertTrue(all(r['fall_events']=='29' for r in read_csv(out/'evaluation/pooled_metrics_by_seed.csv')))
            bad=dict(outer_plan()[0],outer=[8,9])
            with self.assertRaises(ValueError):read_control(out,bad,'r005')
            (out/'derived/fold1/mean_r005_seed7.json').write_text('{}')
            with self.assertRaises(ValueError):verify_controls(out)


if __name__=='__main__':unittest.main(verbosity=2)
