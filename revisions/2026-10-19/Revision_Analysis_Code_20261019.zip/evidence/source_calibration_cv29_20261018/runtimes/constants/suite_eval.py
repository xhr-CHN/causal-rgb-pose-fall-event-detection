"""Common heldout event protocol; no per-model threshold cherry-picking."""
from collections import defaultdict
from pathlib import Path
import json
import numpy as np
import torch
from cv_data import write_csv,write_json,outer_plan,dense_subset,MODELS,SEEDS,read_csv,sha
from cv_training import forward_branch,normalized,new_gate,predict_gate,fresh_branch
from cv_evaluation import pooled_counts
from gate_dynamic_utils import POLICIES,METRICS,candidates,event_metrics,summarize
from gate_opt_features import frame_metrics,gate_features
from gate_opt_calibration import softmax
from suite_features import VARIANTS
from suite_heads import load_predict
from suite_prepare import final_branch


def interaction_predictions(model,p,r,q,device='cuda'):
    model.eval();values={k:[] for k in ['pose','rgb','delta','weight']}
    with torch.no_grad():
        for start in range(0,len(p),128):
            o=model(*(torch.as_tensor(v[start:start+128],device=device) for v in [p,r,q]))
            values['pose'].append(o['pose'].float().cpu().numpy());values['rgb'].append(o['rgb'].float().cpu().numpy())
            delta=o.get('residual_logits',torch.zeros_like(o['pose']))
            values['delta'].append(delta.float().cpu().numpy());values['weight'].append(o['pose_weight'].float().cpu().numpy().reshape(-1))
    v={k:np.concatenate(x) for k,x in values.items()};w=v['weight'];fixed=.5*(v['pose']+v['rgb']);gate=w[:,None]*v['pose']+(1-w[:,None])*v['rgb']
    result={'full':(softmax(gate+v['delta']),w),'gate_only':(softmax(gate),w),
        'fixed_only':(softmax(fixed),np.full(len(w),.5)),
        'fixed_plus_residual':(softmax(fixed+v['delta']),np.full(len(w),.5))}
    for prob,weight in result.values():
        if not np.isfinite(prob).all() or not np.isfinite(weight).all():raise FloatingPointError('Interaction prediction nonfinite')
    return result


class Collector:
    def __init__(self,out):
        self.out=out;out.mkdir(exist_ok=False);self.fold_rows=[];self.events=[];self.persons=[];self.parts=defaultdict(list)

    def add(self,fold,model,seed,prob,w,dense,base,parameters=0):
        y=dense['y'];frame=frame_metrics(y,prob);pred=prob.argmax(1);fp=base.argmax(1)
        frame.update(frame_errors_repaired_vs_fixed=int(np.sum((fp!=y)&(pred==y))),frame_correct_spoiled_vs_fixed=int(np.sum((fp==y)&(pred!=y))),frame_predictions_changed_vs_fixed=int(np.sum(fp!=pred)))
        self.parts[(model,seed)].append((fold,y,prob,fp))
        folder=self.out/('fold'+str(fold));folder.mkdir(exist_ok=True)
        stem=model+'_seed'+str(seed)
        np.savez(folder/(stem+'_predictions.npz'),probabilities=prob,gate_weights=w,y=y)
        write_csv(folder/(stem+'_weights.csv'),[dict(sequence_id=r['sequence_id'],source_frame_number=r['source_frame_number'],weight=float(v),dynamic_threshold=.85+.05*abs(2*float(v)-1)) for r,v in zip(dense['rows'],w)])
        persons=np.array([r['subject_id'] for r in dense['rows']]);all_alarms=[]
        for policy in POLICIES:
            alarms=candidates(dense['rows'],prob,w,policy);hours=float(np.sum(y==0)/(20*3600))
            met,events=event_metrics(alarms,dense['specs'],hours)
            if met['fall_events']!={1:10,2:10,3:9}[fold]:raise ValueError('Heldout event count changed')
            self.fold_rows.append(dict(model=model,seed=seed,fold=fold,policy=policy,windows=len(y),parameters=parameters,**frame,**met))
            self.events.extend(dict(model=model,seed=seed,fold=fold,policy=policy,subject_id=dense['specs'][e['sequence_id']]['subject_id'],**e) for e in events)
            all_alarms.extend(dict(policy=policy,**a) for a in alarms)
            for subject in sorted(set(persons)):
                ix=np.flatnonzero(persons==subject);specs={sid:sp for sid,sp in dense['specs'].items() if sp['subject_id']==subject}
                sm,_=event_metrics([a for a in alarms if a['sequence_id'] in specs],specs,float(np.sum(y[ix]==0)/(20*3600)))
                self.persons.append(dict(model=model,seed=seed,fold=fold,policy=policy,subject_id=int(subject),**frame_metrics(y[ix],prob[ix]),**sm))
        write_csv(folder/(stem+'_alarms.csv'),all_alarms,['policy','candidate_id','sequence_id','source_frame_number','sample_timestamp_ms','source_timestamp_ms','fall_score','evidence','gate_weight','threshold'])

    def finish(self,expected_pooled=None):
        pooled=[]
        for (model,seed),parts in sorted(self.parts.items()):
            if sorted(x[0] for x in parts)!=[1,2,3]:raise ValueError('Missing model fold')
            y=np.concatenate([x[1] for x in parts]);p=np.concatenate([x[2] for x in parts]);fp=np.concatenate([x[3] for x in parts]);pred=p.argmax(1)
            fm=frame_metrics(y,p);fm.update(frame_errors_repaired_vs_fixed=int(np.sum((fp!=y)&(pred==y))),frame_correct_spoiled_vs_fixed=int(np.sum((fp==y)&(pred!=y))),frame_predictions_changed_vs_fixed=int(np.sum(fp!=pred)))
            for policy in POLICIES:
                rows=[r for r in self.fold_rows if (r['model'],r['seed'],r['policy'])==(model,seed,policy)]
                ev=[r for r in self.events if (r['model'],r['seed'],r['policy'])==(model,seed,policy) and r['category']=='fall']
                if len(ev)!=29 or len({e['sequence_id'] for e in ev})!=29:raise ValueError('Duplicated/missing29 events')
                met=pooled_counts(rows,[r['delay_seconds'] for r in ev if r['delay_seconds'] is not None])
                pooled.append(dict(model=model,seed=seed,span='dense29',policy=policy,windows=len(y),parameters=rows[0]['parameters'],**fm,**met))
        if expected_pooled is not None and len(pooled)!=expected_pooled:raise ValueError('Incomplete suite matrix: '+str(len(pooled)))
        aggregates=summarize([r for r in pooled if r['seed'] in SEEDS])
        write_csv(self.out/'fold_metrics.csv',self.fold_rows);write_csv(self.out/'pooled_metrics_by_seed.csv',pooled)
        write_csv(self.out/'aggregate_metrics.csv',aggregates);write_csv(self.out/'event_results.csv',self.events);write_csv(self.out/'subject_metrics.csv',self.persons)
        # Paired policy contrasts within the same model/seed; no best threshold selection.
        table={(r['model'],r['seed'],r['policy']):r for r in pooled};deltas=[]
        for model,seed in self.parts:
            for control in POLICIES[:3]:
                a,b=table[(model,seed,'dynamic')],table[(model,seed,control)]
                deltas.append(dict(model=model,seed=seed,comparison='dynamic minus '+control,**{'delta_'+k:a[k]-b[k] if a[k] is not None and b[k] is not None else None for k in METRICS}))
        write_csv(self.out/'dynamic_paired_differences.csv',deltas)
        lines=['# 全部预设工作点：探索性比较','',
            '29个事件来自6人；三种子不是87个独立事件。不声称独立盲测或全局最优。',
            'A的种子只改变门控；B的种子改变完整模型，不能当同一种不确定性。',
            '所有门限保留，不只挑最好工作点。FA/h按总误报/总暴露计算。','',
            '| 方案 | 门限 | 召回均值 | 误报均值 | FA/h均值 | AP均值 |','| --- | --- | ---: | ---: | ---: | ---: |']
        for r in pooled:
            if r['seed']==0:lines.append('| '+r['model']+' | '+r['policy']+' | '+' | '.join(f'{r[k]:.4f}' for k in ['event_recall','false_alarms','fa_per_hour','macro_auprc'])+' |')
        for r in aggregates:lines.append('| '+r['model']+' | '+r['policy']+' | '+' | '.join(f'{r[k+"_mean"]:.4f}' for k in ['event_recall','false_alarms','fa_per_hour','macro_auprc'])+' |')
        (self.out/'SUMMARY_ZH.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
        return pooled


def evaluate_A(data,prior,out,update,device='cuda'):
    collector=Collector(out/'A_results');old=read_csv(prior/'fold_metrics.csv')
    from suite_prepare import final_branch
    for plan in outer_plan():
        fold=plan['fold'];update(stage='A_evaluation',fold=fold)
        dense=dense_subset(data,plan['outer']);branch,ck=final_branch(prior,plan,device)
        raw=dict(pose=dense['pose'],rgb=dense['rgb'],quality_indices=data['quality_indices']);p,r,q=normalized(raw,np.arange(len(dense['y'])),ck)
        bank=forward_branch(branch,p,r,q,device);bank['quality']=q;bank['y']=dense['y']
        fixed_logits=.5*(bank['pose']+bank['rgb']);z=np.exp(fixed_logits-fixed_logits.max(1,keepdims=True));fixed=z/z.sum(1,keepdims=True);n=len(fixed)
        collector.add(fold,'fixed',0,fixed,np.full(n,.5),dense,fixed)
        collector.add(fold,'original',0,bank['original'],bank['original_weight'],dense,fixed,174119)
        for weight,name in [(0.,'rgb_only'),(.25,'fixed025'),(.75,'fixed075'),(1.,'pose_only')]:
            collector.add(fold,name,0,softmax(weight*bank['pose']+(1-weight)*bank['rgb']),np.full(n,weight),dense,fixed)
        temps=json.loads((out/'A_training'/('fold'+str(fold))/'temperatures.json').read_text())
        pp=bank['pose']/temps['pose']['temperature'];rr=bank['rgb']/temps['rgb']['temperature']
        collector.add(fold,'calibrated_fixed',0,softmax(.5*(pp+rr)),np.full(n,.5),dense,fixed)
        for seed in SEEDS:
            for model in MODELS:
                path=prior/('fold'+str(fold))/(model+'_seed'+str(seed))/'model.pt';checkpoint=torch.load(path,map_location=device,weights_only=False)
                if checkpoint['group']!=model or checkpoint['seed']!=seed or checkpoint['epochs']!=18:raise ValueError('Reused head role mismatch')
                if checkpoint['provenance']['fit_subjects']!=plan['fit'] or checkpoint['provenance']['excluded_subjects']!=plan['outer']:raise ValueError('Reused head subject mismatch')
                gate=new_gate(seed,device);gate.load_state_dict(checkpoint['state_dict'],strict=True)
                cache=dict(bank,features=bank['features'][:,:17]);prob,w=predict_gate(gate,cache,device)
                collector.add(fold,model,seed,prob,w,dense,fixed,1121)
            for name in VARIANTS:
                path=out/'A_training'/('fold'+str(fold))/(name+'_seed'+str(seed))/'model.pt'
                prob,w=load_predict(path,bank,device,expected_provenance=dict(fit_subjects=plan['fit'],excluded_subjects=plan['outer'],fit_provenance_sha256=sha(path.parent.parent/'fit_provenance.json')),expected_role=(name,seed))
                summary=json.loads((path.parent/'summary.json').read_text())
                collector.add(fold,name,seed,prob,w,dense,fixed,summary['parameters'])
        # Reused controls must reproduce previous event metrics under unchanged protocol.
        for row in [r for r in collector.fold_rows if r['fold']==fold and r['model'] in ['fixed','original']+MODELS]:
            previous=next(x for x in old if x['model']==row['model'] and int(x['seed'])==row['seed'] and int(x['fold'])==fold and x['policy']==row['policy'])
            for key in ['detected','false_alarms','duplicates','within_1s_detected','within_2s_detected']:
                if int(previous[key])!=row[key]:raise ValueError('Reused event replay mismatch: '+str((fold,row['model'],row['seed'],key)))
            for key in ['macro_f1','macro_auprc']:np.testing.assert_allclose(row[key],float(previous[key]),atol=1e-5,rtol=1e-5,err_msg='Reused frame metric replay')
        del branch,bank,dense
        if device=='cuda':torch.cuda.empty_cache()
    return collector.finish(208)


def evaluate_B(data,out,update,device='cuda'):
    collector=Collector(out/'B_results')
    for plan in outer_plan():
        fold=plan['fold'];update(stage='B_evaluation',fold=fold);dense=dense_subset(data,plan['outer'])
        for seed in SEEDS:
            for variant in ['M0','M1','M2']:
                path=out/'B_training'/('fold'+str(fold))/(variant+'_seed'+str(seed))/'model.pt'
                ck=torch.load(path,map_location='cpu',weights_only=False)
                if ck['fit_subjects']!=plan['fit'] or ck['excluded_subjects']!=plan['outer'] or ck['epochs']!=18 or ck['seed']!=seed or ck['variant']!=variant or not ck['paired_corruption']:raise ValueError('Interaction protocol mismatch')
                model=fresh_branch(device,seed,variant);model.load_state_dict(ck['model_state_dict'],strict=True);model.requires_grad_(False)
                raw=dict(pose=dense['pose'],rgb=dense['rgb'],quality_indices=data['quality_indices']);p,r,q=normalized(raw,np.arange(len(dense['y'])),ck)
                predictions=interaction_predictions(model,p,r,q,device);base=predictions['fixed_only'][0]
                for ablation,(prob,w) in predictions.items():collector.add(fold,variant+'_'+ablation,seed,prob,w,dense,base,sum(p.numel() for p in model.parameters()))
                del model
        if device=='cuda':torch.cuda.empty_cache()
    return collector.finish(144)
