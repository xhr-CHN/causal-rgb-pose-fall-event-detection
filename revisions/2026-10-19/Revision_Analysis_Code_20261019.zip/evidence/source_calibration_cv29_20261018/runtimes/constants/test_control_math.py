import unittest
import numpy as np
import torch
from test_bounded import fixture_videos
from bounded_training import collate,loss_terms,evidence_curve
from control_math import block_evidence,ScalarObjective,fit_scalar,mean_training_weight


class ControlMathChecks(unittest.TestCase):
    def test_block_evidence_long_prefix_and_padding(self):
        rng=np.random.RandomState(5);score=torch.tensor(rng.rand(3,211),dtype=torch.float64)
        valid=torch.ones_like(score,dtype=torch.bool);valid[1,171:]=False;valid[2,90:]=False
        a=block_evidence(score,valid);b=evidence_curve(score,valid)
        torch.testing.assert_close(a[valid],b[valid],rtol=1e-13,atol=1e-14)
        torch.testing.assert_close(a[:,:83],block_evidence(score[:,:83],valid[:,:83]),rtol=0,atol=0)

    def test_objective_matches_reference_and_is_batched(self):
        torch.set_num_threads(2);videos=fixture_videos();obj=ScalarObjective(videos,'cpu')
        batch=collate(videos,'cpu')
        for key in ['pose','rgb']:batch[key]=batch[key].double()
        y=np.concatenate([v['y'] for v in videos]);cw=torch.tensor(len(y)/(3*np.bincount(y,minlength=3)),dtype=torch.float64)
        values=np.array([.4,.45,.5,.57,.6])
        for coefficient in [.05,.005,0.]:
            calculated=obj.values(values,coefficient)
            for w,value in zip(values,calculated):
                weight=torch.full(batch['valid'].shape,float(w),dtype=torch.float64)
                expected,_=loss_terms(weight,batch,cw,True,coefficient)
                self.assertAlmostEqual(float(expected),float(value),places=12)
        with self.assertRaises(ValueError):obj.values([.3],0.)

    def test_numerical_search_and_tie_rule(self):
        class Quadratic:
            evaluations=0
            def values(self,w,c):
                self.evaluations+=len(w);return (np.asarray(w)-.4371234)**2
        result=fit_scalar(Quadratic(),0.)
        self.assertLess(abs(result['weight_float64']-.4371234),2e-7)
        self.assertLessEqual(result['selected_objective'],result['fixed_half_objective']+1e-12)
        class Flat(Quadratic):
            def values(self,w,c):return np.zeros(len(w))
        self.assertEqual(fit_scalar(Flat(),0.)['weight_float64'],.5)

    def test_mean_is_training_frame_weighted(self):
        self.assertAlmostEqual(mean_training_weight(np.array([.4,.4,.4,.6])),.45)
        for w in [np.array([]),np.array([np.nan]),np.array([.2])]:
            with self.assertRaises(ValueError):mean_training_weight(w)


if __name__=='__main__':unittest.main(verbosity=2)
