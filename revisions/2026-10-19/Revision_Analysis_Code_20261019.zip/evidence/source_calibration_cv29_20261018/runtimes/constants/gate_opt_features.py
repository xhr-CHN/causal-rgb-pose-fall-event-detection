"""Label-free, window-local features and tie-aware diagnostic metrics."""
import numpy as np


QUALITY_NAMES = ['pose_found', 'person_conf', 'visible_keypoint_ratio',
                 'mean_keypoint_conf', 'torso_keypoint_conf']
FEATURE_NAMES = (
    [f'{s}_{n}' for s in ('mean', 'min') for n in QUALITY_NAMES]
    + [f'{b}_{s}' for b in ('pose', 'rgb') for s in ('confidence', 'entropy', 'margin')]
    + ['branch_disagreement']
    + [f'std_{n}' for n in QUALITY_NAMES]
    + [f'last_minus_first_{n}' for n in QUALITY_NAMES]
    + ['pose_missing_longest_fraction', 'pose_missing_trailing_fraction']
)


def reliability(p):
    top = np.sort(p, axis=1)
    return np.stack([top[:, -1], -(p * np.log(np.maximum(p, 1e-8))).sum(1)
                     / np.log(3.), top[:, -1] - top[:, -2]], 1)


def gate_features(quality, pose_prob, rgb_prob, temporal=True):
    """No labels, cross-video aggregation or observations beyond this W16 window."""
    q = np.asarray(quality, dtype=np.float32)
    pp, rp = (np.asarray(p, dtype=np.float32) for p in (pose_prob, rgb_prob))
    if q.ndim != 3 or q.shape[1:] != (16, 5):
        raise ValueError('Expected B x 16 x 5 quality')
    if pp.shape != (len(q), 3) or rp.shape != pp.shape:
        raise ValueError('Expected aligned B x 3 probabilities')
    if not all(np.isfinite(a).all() for a in (q, pp, rp)):
        raise ValueError('Nonfinite gate input')
    if np.any(q < 0) or np.any(q > 1):
        raise ValueError('Quality must be unnormalized and clipped to [0,1]')
    for p in (pp, rp):
        if np.any(p < 0) or not np.allclose(p.sum(1), 1., atol=1e-5):
            raise ValueError('Invalid branch probabilities')
    base = np.concatenate([q.mean(1), q.min(1), reliability(pp), reliability(rp),
                           np.abs(pp-rp).mean(1, keepdims=True)], 1)
    if not temporal:
        return base.astype(np.float32)
    missing = q[:, :, 0] < 0.5
    run = np.zeros(len(q), dtype=np.int64)
    longest = np.zeros_like(run)
    for t in range(16):
        run = np.where(missing[:, t], run + 1, 0)
        longest = np.maximum(longest, run)
    extra = np.concatenate([q.std(1, ddof=0), q[:, -1] - q[:, 0],
                            longest[:, None]/16., run[:, None]/16.], 1)
    return np.concatenate([base, extra], 1).astype(np.float32)


def average_precision(y, score):
    y = np.asarray(y, dtype=np.int64)
    s = np.asarray(score, dtype=np.float64)
    if y.sum() == 0:
        return None
    order = np.argsort(-s, kind='stable')
    y, s = y[order], s[order]
    ends = np.r_[np.flatnonzero(s[:-1] != s[1:]), len(s)-1]
    tp = np.cumsum(y)[ends]
    return float(np.sum(np.diff(np.r_[0, tp]) * tp / (ends + 1)) / y.sum())


def frame_metrics(y, probs):
    pred = probs.argmax(1)
    f1, ap = [], []
    for c in range(3):
        tp = np.sum((y == c) & (pred == c))
        den = np.sum(y == c) + np.sum(pred == c)
        f1.append(float(2*tp/den) if den else 0.)
        ap.append(average_precision(y == c, probs[:, c]))
    if any(v is None for v in ap):
        raise ValueError('Diagnostic validation must contain all three classes')
    return dict(macro_f1=float(np.mean(f1)), macro_auprc=float(np.mean(ap)))
