#!/usr/bin/env python3
"""Fixed calibrated baseline, scalar and bounded dynamic gate timeliness study."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
import zipfile
from datetime import datetime,timezone,timedelta

ROOT=Path('/data1/yoloA27_full_snapshot_20261014')
PY=Path('/home/xiaohaoran/.conda/envs/yolo4090/bin/python')
RESULT='gate_regularization_cv29_4090_20261018_v1'
sys.dont_write_bytecode=True


def now():return datetime.now(timezone(timedelta(hours=8))).isoformat(timespec='seconds')


def bundle_check(tools):
    import hashlib
    manifest=json.loads((tools/'BUNDLE_MANIFEST.json').read_text(encoding='utf-8'))
    for name,h in manifest.items():
        rel=Path(name);path=(tools/rel).resolve()
        if rel.is_absolute() or '..' in rel.parts or ':' in name or tools.resolve() not in path.parents or hashlib.sha256(path.read_bytes()).hexdigest()!=h:raise ValueError('Bundle integrity: '+name)
    return manifest


def seal(out):
    from cv_data import sha,write_json
    models=sorted((out/'training').rglob('model.pt'))
    if len(models)!=54:raise ValueError('Expected54 trained heads')
    auxiliary=sorted((out/'prepared').rglob('*'))+[out/'frozen_temperatures.json']
    hashes={p.relative_to(out).as_posix():sha(p) for p in models+auxiliary if p.is_file()}
    write_json(out/'training_seal.json',dict(heads=54,checkpoints_and_banks=hashes,all_training_complete_before_outer_evaluation=True))


def verify_seal(out):
    from cv_data import sha
    data=json.loads((out/'training_seal.json').read_text())
    if data['heads']!=54 or not data['all_training_complete_before_outer_evaluation']:raise ValueError('Incomplete training seal')
    if sum(name.endswith('/model.pt') for name in data['checkpoints_and_banks'])!=54:raise ValueError('Expected54 sealed model files')
    for name,h in data['checkpoints_and_banks'].items():
        path=(out/name).resolve()
        if out.resolve() not in path.parents or sha(path)!=h:raise ValueError('Sealed artifact changed: '+name)


def smoke(videos,out,update):
    import numpy as np
    import torch
    from bounded_training import GROUPS,fit_head
    from cv_data import write_json
    folder=out/'cuda_smoke';folder.mkdir()
    fall=[v for v in videos if v['category']=='fall'][:2];adl=[v for v in videos if v['category']=='adl'][:2]
    if len(fall)!=2 or len(adl)!=2:raise ValueError('Smoke video coverage')
    summaries=[]
    for group in GROUPS:
        summary=fit_head(group,7,fall+adl,folder/group,update,dict(smoke=True),epochs=2)
        summaries.append({k:v for k,v in summary.items() if k!='schedule'})
    write_json(folder/'report.json',dict(status='CUDA_smoke_pass',training_result=False,branches_frozen=True,groups=summaries))
    print('REGULARIZATION_CUDA_SMOKE_PASS (discarded heads)',flush=True);torch.cuda.empty_cache()


def execute(root,out,update):
    tools=Path(__file__).resolve().parent;manifest=bundle_check(tools)
    update(stage='unit_tests',phase='preflight')
    subprocess.run([sys.executable,'-m','unittest','discover','-s',str(tools),'-p','test_*.py','-v'],check=True)
    import numpy as np
    import torch
    from cv_data import load_source,outer_plan,SEEDS,write_json,write_csv,sha
    from suite_prepare import verify_prior,PRIOR_ARCHIVE_SHA
    from bounded_prepare import verify_temperatures,SUITE_SHA
    from reuse_banks import reuse,BOUNDED_SHA
    from bounded_training import GROUPS,fit_head
    if Path(sys.executable).resolve()!=PY.resolve() or sys.version_info[:3]!=(3,9,25) or np.__version__!='1.26.4' or str(torch.__version__)!='2.1.0+cu121':raise RuntimeError('Use original Python3.9.25 NumPy1.26.4 Torch2.1.0+cu121 yolo4090')
    if not torch.cuda.is_available() or torch.cuda.get_device_name(0)!='NVIDIA GeForce RTX 4090' or torch.backends.cudnn.version()!=8902:raise RuntimeError('Expected allocated4090/cuDNN8902')
    torch.set_num_threads(2);torch.set_num_interop_threads(2)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=True;torch.backends.cudnn.deterministic=True;torch.backends.cudnn.benchmark=False
    environment=dict(python=sys.version,executable=sys.executable,numpy=np.__version__,torch=str(torch.__version__),cuda=torch.version.cuda,cudnn=torch.backends.cudnn.version(),gpu=torch.cuda.get_device_name(0),gpu_mask=os.environ.get('CUDA_VISIBLE_DEVICES','0'),cpu_threads=2)
    write_json(out/'environment.json',environment)
    update(stage='archive_validation');prior,reused=verify_prior(root,out);suite,temps,more=verify_temperatures(root,out);reused.update(more)
    update(stage='source_preflight');data=load_source(root,out)
    for folder in [prior,suite]:
        old=json.loads((folder/'source_preflight.json').read_text())
        if old['input_sha256']!=data['input_sha256']:raise ValueError('Source changed since completed experiments')
    sys.path.insert(0,str(data['code']))
    write_json(out/'protocol.json',dict(locked_before_training=True,groups=GROUPS,heads=54,seeds=SEEDS,epochs=18,videos_per_batch=4,
        weight='.5+.1*tanh(g), initial output0.5 exactly; scalar or raw29-32-16-1/dropout0.1',
        loss='class-weighted CE +lambda mean(((w-.5)/.1)^2)+.1*(sequence-balanced BCE-negative +event-balanced early BCE-positive); lambda=0.05/0.005/0. All six groups include temporal loss.',
        masks='Source fit-person dense OOF only. Negative=ADL/preonset; positive=onset+2 through onset+20 frames, within covered span. No outer error supervision.',
        evidence='E=.5*previous+.5*fallscore, zero at each video start. Padding excluded. Differentiable surrogate has no latch/reset; real original alarm used only in evaluation.',
        optimizer='AdamW lr0.0008 weight_decay0.0001 clip5, FP32,18 fixed epochs, every fit video once/epoch in batches4',
        branch_retraining=False,temperature_refitting=False,previous_gate_pseudotarget_removed=True,
        source_validation_used=False,external_data_used=False,manuscript_modified=False,no_outer_selection=True,retrospective=True,
        previous_CV29_sha256=PRIOR_ARCHIVE_SHA,calibration_suite_sha256=SUITE_SHA,
        dense_training_bank_archive_sha256=BOUNDED_SHA,regularization_only_ablation=True,
        thresholds=['fixed_085','fixed_0875','fixed_090','dynamic'],primary_workpoint=.85,no_automatic_best_threshold=True,
        evaluation='same29 events, per-seed/person, within1s/2s recall, FA/common exposure, matched detection delays; old sparse freely-weighted gates only references',
        limitations='Repeated6-person development study, not new blind test/global optimum. All outer results reported, no outer-based choice. AdamW weight_decay0.0001 remains even at zero explicit anchoring penalty. Old freely weighted heads differ in density/objective.',
        environment=environment,bundle_sha256=manifest))
    update(stage='sealed_bank_reuse');banks,bank_inputs=reuse(root,out,temps,data['input_sha256']);reused.update(bank_inputs)
    prepared=out/'prepared'
    update(stage='cuda_smoke',phase='smoke_not_formal');smoke(banks[1],out,update)
    train=out/'training';train.mkdir();count=0;rows=[]
    for plan in outer_plan():
        folder=train/('fold'+str(plan['fold']));folder.mkdir()
        for seed in SEEDS:
            summaries={}
            for group in GROUPS:
                update(stage='head_training',phase='formal_training',fold=plan['fold'],heads_complete=count)
                provenance=dict(fit_subjects=plan['fit'],excluded_subjects=plan['outer'],temperatures=temps[plan['fold']],bank_sha256=sha(prepared/('fold'+str(plan['fold']))/'dense_OOF_bank.npz'))
                summary=fit_head(group,seed,banks[plan['fold']],folder/(group+'_seed'+str(seed)),update,provenance)
                count+=1;summaries[group]=summary;rows.append(dict(fold=plan['fold'],**{k:v for k,v in summary.items() if k!='schedule'}));write_csv(out/'training_summary.csv',rows)
            for kind in ['constant','dynamic']:
                for reg in ['r0005','r0']:
                    a,b=kind+'_r005_temporal',kind+'_'+reg+'_temporal'
                    if summaries[a]['schedule']!=summaries[b]['schedule'] or summaries[a]['initialization_sha256']!=summaries[b]['initialization_sha256']:raise ValueError('Paired initialization/video/dropout schedule mismatch')
            if len({r['updates'] for r in summaries.values()})!=1:raise ValueError('Unequal update budget')
    if count!=54:raise ValueError('Incomplete training')
    seal(out);verify_seal(out);update(stage='training_sealed',heads_complete=54)
    print('ALL_REGULARIZATION_HEADS_SEALED 54',flush=True)
    from bounded_eval import evaluate
    update(stage='outer_evaluation',phase='sealed_evaluation');report=evaluate(data,prior,suite,temps,out,update)
    verify_seal(out)
    for path,h in {**data['input_sha256'],**reused}.items():
        if sha(Path(path))!=h:raise RuntimeError('Read-only input changed: '+path)
    if sha(prior/'Gate_CV29_Results_20261017.zip')!=PRIOR_ARCHIVE_SHA or sha(suite/'Gate_Suite_CV29_Results_20261018.zip')!=SUITE_SHA:raise RuntimeError('Prior archive changed')
    bundle_check(tools)
    write_json(out/'completion_summary.json',dict(status='complete',heads=54,**report,branches_and_temperatures_unchanged=True,manuscript_modified=False))
    update(stage='packaging');archive=out/'Gate_Regularization_CV29_Results_20261018.zip'
    files=sorted(p for p in out.rglob('*') if p.is_file() and p!=archive and p.name!='status.json')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_STORED) as z:
        for file in files:z.write(file,file.relative_to(out).as_posix())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:raise RuntimeError('Result ZIP CRC')
    update(state='COMPLETE',stage='complete',archive=str(archive),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size)
    print('ALL_REGULARIZATION_EXPERIMENTS_COMPLETE',str(out),flush=True)
    print('RESULT_ARCHIVE',str(archive),sha(archive),flush=True)


def main():
    for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='2'
    os.environ['CUBLAS_WORKSPACE_CONFIG']=':4096:8';os.environ['PYTHONDONTWRITEBYTECODE']='1';os.environ.setdefault('CUDA_VISIBLE_DEVICES','0')
    from cv_data import write_json
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=ROOT);args=ap.parse_args();root=args.root.resolve()
    if os.name!='posix' or root!=ROOT or root not in Path(__file__).resolve().parents:raise RuntimeError('Run only in approved4090 snapshot')
    out=root/'experiments'/RESULT
    if root not in out.resolve().parents or root not in (root/'experiments').resolve().parents:raise ValueError('Output outside root')
    out.mkdir(parents=True,exist_ok=False);began=time.monotonic();state=dict(state='RUNNING',stage='starting',pid=os.getpid(),started_at=now(),heads_complete=0)
    def update(**kw):
        state.update(kw,last_update_at=now(),elapsed_seconds=time.monotonic()-began);write_json(out/'status.json',state)
    try:
        try:os.nice(5)
        except OSError:pass
        update();execute(root,out,update)
    except BaseException as exc:
        update(state='INTERRUPTED' if isinstance(exc,KeyboardInterrupt) else 'FAILED',error=repr(exc));traceback.print_exc();raise


if __name__=='__main__':main()
