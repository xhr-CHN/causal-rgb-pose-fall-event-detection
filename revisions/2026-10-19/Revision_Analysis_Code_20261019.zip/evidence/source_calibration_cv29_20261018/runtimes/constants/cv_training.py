"""Fixed-budget training; no outer data, labels or metrics used for selection."""
import hashlib
import time
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from cv_data import check_fit,write_json,write_csv,EPOCHS,MODELS
from gate_dynamic_utils import hard_masks
from gate_opt_features import gate_features


def digest(model):
    h=hashlib.sha256()
    for name,value in sorted(model.state_dict().items()):h.update(name.encode());h.update(value.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()


def sample_order(rng,n,augmented):
    ids=rng.permutation(n);u=rng.rand(n)
    views=np.where(u<.6,0,np.where(u<.8,1,2))
    return ids+(views*n if augmented else 0)


def block_mask(p,r,q,kind,indices):
    if kind not in ('pose','rgb') or len(p)!=len(indices):raise ValueError('Invalid block mask inputs')
    a,b,c=p.copy(),r.copy(),q.copy();mask=np.zeros((len(p),16),bool)
    for j,i in enumerate(indices):
        rng=np.random.RandomState(20261017+int(i)*13+(0 if kind=='pose' else 1))
        length=int(rng.choice([2,4,8,16]));start=int(rng.randint(0,17-length));mask[j,start:start+length]=True
    if kind=='pose':a[mask]=0.;c[mask]=0.
    else:b[mask]=0.
    return a,b,c,mask


def normalized(data,indices,ck):
    p=((data['pose'][indices,-16:]-ck['pose_mean'])/ck['pose_std']).astype(np.float32)
    r=((data['rgb'][indices,-16:]-ck['rgb_mean'])/ck['rgb_std']).astype(np.float32)
    q=np.clip(data['pose'][indices,-16:][:,:,data['quality_indices']],0,1).astype(np.float32)
    return p,r,q


def forward_branch(model,p,r,q,device='cuda'):
    model.eval();values={k:[] for k in ['pose','rgb','features','original','original_weight']}
    with torch.no_grad():
        for start in range(0,len(p),128):
            end=start+128;o=model(*(torch.as_tensor(x[start:end],device=device) for x in [p,r,q]))
            for k in ['pose','rgb']:values[k].append(o[k].float().cpu().numpy())
            values['features'].append(gate_features(q[start:end],o['pose_probabilities'].cpu().numpy(),o['rgb_probabilities'].cpu().numpy(),temporal=False))
            values['original'].append(o['fused'].float().softmax(1).cpu().numpy());values['original_weight'].append(o['pose_weight'].float().cpu().numpy())
    result={k:np.concatenate(v) for k,v in values.items()}
    if not all(np.isfinite(v).all() for v in result.values()):raise FloatingPointError('Nonfinite frozen branch output')
    return result


def fresh_branch(device,seed=42,variant='M0'):
    from train_quality_gated_fusion_tcn import set_seed
    from train_quality_gated_logit_fusion_v2 import ReliabilityGatedLogitFusion
    set_seed(seed)
    if variant=='M0':model=ReliabilityGatedLogitFusion(95,256,5,64,.2).to(device)
    else:
        from interaction_model import make_model
        model=make_model(ReliabilityGatedLogitFusion,variant).to(device)
    if sum(p.numel() for p in model.parameters())!=({'M0':174119,'M1':178154,'M2':178154}[variant]):raise ValueError('Branch architecture changed')
    return model


def finish_amp_step(model,optimizer,scaler):
    """Let native GradScaler back off on overflow without updating parameters."""
    bad=[name for name,p in model.named_parameters() if p.grad is not None and not torch.isfinite(p.grad).all()]
    if not any(p.grad is not None for p in model.parameters()):raise FloatingPointError('No branch gradients')
    before_scale=float(scaler.get_scale())
    before=[p.detach().clone() for p in model.parameters()] if bad else None
    if bad and not scaler.is_enabled():raise FloatingPointError('Nonfinite FP32 branch gradients: '+str(bad[:8]))
    if not bad:
        norm=torch.nn.utils.clip_grad_norm_(model.parameters(),5.)
        if not torch.isfinite(norm):raise FloatingPointError('Nonfinite unscaled branch gradient norm')
    # In particular, never clip nonfinite gradients before GradScaler handles them.
    scaler.step(optimizer);scaler.update();after_scale=float(scaler.get_scale())
    if bad:
        if not after_scale<before_scale:raise FloatingPointError('AMP overflow without loss-scale backoff')
        if any(not torch.equal(p.detach(),q) for p,q in zip(model.parameters(),before)):raise FloatingPointError('AMP overflow changed branch parameters')
    if not all(torch.isfinite(p).all() for p in model.parameters()):raise FloatingPointError('Nonfinite branch parameters after optimizer step')
    if not all(torch.isfinite(b).all() for b in model.buffers()):raise FloatingPointError('Nonfinite branch buffers')
    return dict(skipped=bool(bad),scale_before=before_scale,scale_after=after_scale,nonfinite_parameter_gradients=bad[:8])


def fit_branch(data,fit_subjects,allowed,excluded,out,update,device='cuda',epochs=EPOCHS,seed=42,variant='M0',paired=False):
    check_fit(fit_subjects,allowed,excluded);out.mkdir(exist_ok=False)
    from train_quality_gated_logit_fusion_v2 import masked_mean
    import train_quality_gated_logit_fusion_v3_w16 as v3
    ids=np.flatnonzero(np.isin(data['subjects'],fit_subjects))
    if set(data['subjects'][ids])!=set(fit_subjects):raise ValueError('Missing fit subject')
    stats={}
    for name in ['pose','rgb']:
        x=data[name][ids,-16:];mean=x.mean((0,1)).astype(np.float32);std=x.std((0,1)).astype(np.float32);std[std<1e-6]=1.
        stats[name+'_mean']=mean;stats[name+'_std']=std
    y=data['y'][ids];counts=np.bincount(y,minlength=3)
    if np.any(counts==0):raise ValueError('Missing fit class')
    p,r,q=normalized(data,ids,stats)
    tensors=[torch.as_tensor(x,device=device) for x in [p,r,q,y]]
    cw=torch.as_tensor(len(y)/(3.*counts),dtype=torch.float32,device=device)
    model=fresh_branch(device,seed,variant);optimizer=torch.optim.AdamW(model.parameters(),lr=.0008,weight_decay=.0001)
    cuda=torch.device(device).type=='cuda';scaler=torch.cuda.amp.GradScaler(enabled=cuda)
    if paired:
        torch.manual_seed(seed*10101);torch.cuda.manual_seed_all(seed*10101)
    rng=np.random.default_rng(seed);history=[];began=time.monotonic();successful=skipped=consecutive=0;overflow_events=[]
    for epoch in range(1,epochs+1):
        model.train();total=0.;order=rng.permutation(len(y));epoch_updates=epoch_skips=0
        state=torch.cuda.get_rng_state(device) if cuda else torch.get_rng_state()
        shuffle_hash=hashlib.sha256(order.tobytes()).hexdigest();dropout_hash=hashlib.sha256(state.cpu().numpy().tobytes()).hexdigest()
        for start in range(0,len(y),128):
            ix=torch.as_tensor(order[start:start+128],device=device);a,b,c=[x[ix] for x in tensors[:3]];yy=tensors[3][ix]
            if paired:
                from interaction_model import paired_corruption
                a,b,c,pbad,rbad,clean=paired_corruption(v3.corrupt_modalities_v3,a,b,c,seed*1000003+epoch*1000+start//128)
            else:a,b,c,pbad,rbad,clean=v3.corrupt_modalities_v3(a,b,c)
            optimizer.zero_grad(set_to_none=True)
            with torch.cuda.amp.autocast(enabled=cuda):
                o=model(a,b,c);target,_,_=v3.build_gate_targets(o,yy,pbad,rbad,clean)
                loss=F.cross_entropy(o['fused'],yy,weight=cw)
                loss+=.25*(masked_mean(F.cross_entropy(o['pose'],yy,weight=cw,reduction='none'),~pbad)+masked_mean(F.cross_entropy(o['rgb'],yy,weight=cw,reduction='none'),~rbad))
                loss+=.35*F.binary_cross_entropy_with_logits(o['gate_logit'],target)
            if not torch.isfinite(loss):raise FloatingPointError('Nonfinite branch loss')
            scaler.scale(loss).backward();scaler.unscale_(optimizer)
            event=finish_amp_step(model,optimizer,scaler)
            if event['skipped']:
                skipped+=1;epoch_skips+=1;consecutive+=1
                overflow_events.append(dict(epoch=epoch,batch=start//128,loss=float(loss.detach()),**event))
                write_json(out/'amp_overflow_events.json',overflow_events)
                print('AMP_OVERFLOW_BACKOFF',out.name,overflow_events[-1],flush=True)
                if consecutive>=16:raise FloatingPointError('16 consecutive AMP overflows; inspect amp_overflow_events.json')
            else:successful+=1;epoch_updates+=1;consecutive=0
            total+=float(loss.detach())*len(ix)
        history.append(dict(epoch=epoch,loss=total/len(y),optimizer_updates=epoch_updates,AMP_skipped_batches=epoch_skips,loss_scale=float(scaler.get_scale()),shuffle_sha256=shuffle_hash,dropout_rng_sha256=dropout_hash));write_csv(out/'history.csv',history)
        update(stage='branch_training',task=out.name,epoch=epoch,epochs=epochs)
        print('BRANCH',out.name,'epoch',epoch,'/',epochs,'loss',round(total/len(y),6),flush=True)
    if successful==0:raise FloatingPointError('No successful branch optimizer update; inspect AMP loss scales')
    ck=dict(model_state_dict=model.state_dict(),**stats,fit_subjects=sorted(fit_subjects),excluded_subjects=sorted(set(excluded)),seed=seed,variant=variant,paired_corruption=paired,epochs=epochs,windows=len(ids),fit_global_indices=ids.tolist(),selection='fixed final epoch, no heldout selection',seconds=time.monotonic()-began,optimizer_updates=successful,AMP_skipped_batches=skipped,final_loss_scale=float(scaler.get_scale()))
    torch.save(ck,out/'model.pt')
    write_json(out/'summary.json',{k:v for k,v in ck.items() if k not in ['model_state_dict','pose_mean','pose_std','rgb_mean','rgb_std']})
    model.requires_grad_(False).eval()
    return model,ck


def cache_views(model,ck,data,indices,device='cuda'):
    if set(data['subjects'][indices])&set(ck['fit_subjects']):raise ValueError('OOF view includes model fit subjects')
    p,r,q=normalized(data,indices,ck);before=digest(model);clean=forward_branch(model,p,r,q,device)
    views=[clean]
    for kind in ['pose','rgb']:
        a,b,c,_=block_mask(p,r,q,kind,indices);views.append(forward_branch(model,a,b,c,device))
    if digest(model)!=before:raise RuntimeError('Frozen OOF branch changed')
    def assemble(values,repeats):
        result={k:np.concatenate([v[k] for v in values]) for k in ['pose','rgb','features']}
        result['y']=np.tile(data['y'][indices],repeats);result['repair'],result['keep']=hard_masks(result['pose'],result['rgb'],result['y'])
        return result
    return assemble([clean],1),assemble(views,3)


def new_gate(seed,device):
    torch.manual_seed(seed)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)
    gate=nn.Sequential(nn.Linear(17,32),nn.ReLU(),nn.Dropout(.1),nn.Linear(32,16),nn.ReLU(),nn.Linear(16,1)).to(device)
    nn.init.zeros_(gate[-1].weight);nn.init.zeros_(gate[-1].bias)
    return gate


def gate_loss(gl,p,r,y,cw,repair,keep,hard):
    w=gl.sigmoid()[:,None];fused=w*p+(1-w)*r
    ce=F.cross_entropy(fused,y,reduction='none')
    pc=F.cross_entropy(p,y,reduction='none');rc=F.cross_entropy(r,y,reduction='none')
    target=((rc-pc)/.5).sigmoid().clamp(.1,.9).detach()
    base=F.cross_entropy(fused,y,weight=cw)+.35*F.binary_cross_entropy_with_logits(gl,target)
    fixed=F.cross_entropy(.5*(p+r),y,reduction='none').detach()
    mean=lambda x,m:(x*m).sum()/m.sum().clamp_min(1)
    return base+(.5*mean(ce,repair)+.5*mean((ce-fixed).relu(),keep) if hard else 0.)


def predict_gate(gate,cache,device='cuda'):
    gate.eval()
    with torch.no_grad():
        x=torch.as_tensor(cache['features'],dtype=torch.float32,device=device)
        w=gate(x).reshape(-1).sigmoid();p=torch.as_tensor(cache['pose'],device=device);r=torch.as_tensor(cache['rgb'],device=device)
        return (w[:,None]*p+(1-w[:,None])*r).softmax(1).cpu().numpy(),w.cpu().numpy()


def fit_gate(group,seed,clean,views,out,update,device='cuda',epochs=EPOCHS,provenance=None):
    if group not in MODELS:raise ValueError('Invalid training group')
    out.mkdir(exist_ok=False);aug=group.startswith('aug_');hard=group.endswith('hard');cache=views if aug else clean;n=len(clean['y'])
    if len(cache['y'])!=n*(3 if aug else 1):raise ValueError('Cache view alignment')
    for k in ['pose','rgb','features','y','repair','keep']:
        if len(cache[k])!=len(cache['y']) or not np.isfinite(cache[k]).all():raise ValueError('Cache field '+k)
    counts=np.bincount(clean['y'],minlength=3)
    if np.any(counts==0):raise ValueError('Gate fit class missing')
    values={k:torch.as_tensor(cache[k],dtype=torch.long if k=='y' else torch.float32,device=device) for k in ['pose','rgb','features','y','repair','keep']}
    cw=torch.as_tensor(n/(3.*counts),dtype=torch.float32,device=device)
    gate=new_gate(seed,device);initial=digest(gate)
    if sum(p.numel() for p in gate.parameters())!=1121:raise ValueError('Gate architecture')
    with torch.no_grad():
        if not torch.all(gate(values['features'][:2]).sigmoid()==.5):raise ValueError('Not fixed0.5 initialization')
    optimizer=torch.optim.AdamW(gate.parameters(),lr=.0008,weight_decay=.0001)
    rng=np.random.RandomState(seed);torch.manual_seed(seed*10101)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(seed*10101)
    history=[];schedule=[];began=time.monotonic()
    for epoch in range(1,epochs+1):
        gate.train();order=sample_order(rng,n,aug);total=0.
        rs=torch.cuda.get_rng_state(device) if torch.device(device).type=='cuda' else torch.get_rng_state()
        fingerprint=dict(order=hashlib.sha256(order.tobytes()).hexdigest(),original_order=hashlib.sha256((order%n).tobytes()).hexdigest(),dropout=hashlib.sha256(rs.cpu().numpy().tobytes()).hexdigest())
        schedule.append(fingerprint)
        for start in range(0,n,128):
            ix=torch.as_tensor(order[start:start+128],device=device);gl=gate(values['features'][ix]).reshape(-1)
            loss=gate_loss(gl,values['pose'][ix],values['rgb'][ix],values['y'][ix],cw,values['repair'][ix],values['keep'][ix],hard)
            if not torch.isfinite(loss):raise FloatingPointError('Nonfinite gate loss')
            optimizer.zero_grad(set_to_none=True);loss.backward()
            if not all(p.grad is None or torch.isfinite(p.grad).all() for p in gate.parameters()):raise FloatingPointError('Nonfinite gate gradient')
            torch.nn.utils.clip_grad_norm_(gate.parameters(),5.);optimizer.step();total+=float(loss.detach())*len(ix)
        history.append(dict(epoch=epoch,loss=total/n,**fingerprint));write_csv(out/'history.csv',history)
        update(stage='gate_training',task=out.name,epoch=epoch,epochs=epochs)
        print('GATE',out.name,'epoch',epoch,'/',epochs,'loss',round(total/n,6),flush=True)
    summary=dict(group=group,seed=seed,epochs=epochs,windows_per_epoch=n,updates_per_epoch=(n+127)//128,initialization_sha256=initial,final_state_sha256=digest(gate),schedule=schedule,seconds=time.monotonic()-began,selection='fixed final epoch; no outer labels or epoch0 fallback selection')
    torch.save(dict(state_dict=gate.state_dict(),group=group,seed=seed,epochs=epochs,provenance=provenance or {}),out/'model.pt');write_json(out/'summary.json',dict(summary,provenance=provenance or {}))
    return gate,summary
