"""Bind reused artifacts to the exact completed archive and subject lineage."""
import hashlib
import json
from pathlib import Path
import zipfile
import numpy as np
import torch
from cv_data import sha,outer_plan,read_csv,write_json
from cv_evaluation import verify_seal
from cv_training import fresh_branch,forward_branch,normalized
from gate_opt_features import gate_features
from gate_opt_calibration import softmax

PRIOR='gate_cv29_4090_20261017_v2'
PRIOR_ARCHIVE_SHA='d04bb29d7dffdd2c8fbcc4f87870aa3c7f779b6141826c868c7341d760f62972'


def verify_prior(root,out):
    prior=(root/'experiments'/PRIOR).resolve()
    if root.resolve() not in prior.parents:raise ValueError('Prior outside approved project')
    status=json.loads((prior/'status.json').read_text())
    archive=prior/'Gate_CV29_Results_20261017.zip'
    if status['state']!='COMPLETE' or sha(archive)!=PRIOR_ARCHIVE_SHA:raise ValueError('Wrong or incomplete previous CV29 archive')
    hashes={}
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:raise ValueError('Previous archive CRC failed')
        needed=['training_seal.json','protocol.json','source_preflight.json','fold_metrics.csv','pooled_metrics_by_seed.csv']
        for plan in outer_plan():
            prefix='fold'+str(plan['fold'])+'/'
            needed.extend([prefix+'gate_oof_clean.npz',prefix+'OOF_provenance.json'])
        seal=json.loads(z.read('training_seal.json'))
        needed.extend(seal['checkpoints'])
        for relative in needed:
            path=(prior/relative).resolve()
            if prior not in path.parents:raise ValueError('Unsafe reused path')
            h=sha(path)
            if hashlib.sha256(z.read(relative)).hexdigest()!=h:raise ValueError('Reused file differs from locked archive: '+relative)
            hashes[str(path)]=h
    verify_seal(prior)
    protocol=json.loads((prior/'protocol.json').read_text())
    if protocol['epochs']!=18 or protocol['outer_plan']!=outer_plan() or protocol['branch_seed']!=42:raise ValueError('Prior protocol incompatible')
    write_json(out/'prior_reuse.json',dict(prior=str(prior),archive=str(archive),archive_sha256=PRIOR_ARCHIVE_SHA,reused_file_sha256=hashes,archive_CRC=True,model_seal_verified=True))
    return prior,hashes


def final_branch(prior,plan,device='cuda'):
    ck=torch.load(prior/('fold'+str(plan['fold']))/'final_branch/model.pt',map_location='cpu',weights_only=False)
    if ck['fit_subjects']!=plan['fit'] or ck['excluded_subjects']!=plan['outer'] or ck['epochs']!=18:raise ValueError('Reused branch subject/epoch mismatch')
    model=fresh_branch(device);model.load_state_dict(ck['model_state_dict'],strict=True);model.requires_grad_(False).eval()
    return model,ck


def attach_quality(cache,quality):
    result={k:cache[k].copy() for k in ['pose','rgb','y']}
    result['quality']=quality.astype(np.float32)
    result['features']=gate_features(result['quality'],softmax(result['pose']),softmax(result['rgb']))
    if 'features' in cache:np.testing.assert_allclose(result['features'][:,:17],cache['features'][:,:17],atol=1e-5,rtol=1e-5,err_msg='Reused17-feature prefix')
    return result


def prepare_fit_bank(data,prior,plan,out,device='cuda'):
    ids=np.flatnonzero(np.isin(data['subjects'],plan['fit']));n=len(ids)
    folder=prior/('fold'+str(plan['fold']))
    provenance=json.loads((folder/'OOF_provenance.json').read_text())
    if provenance['plan']!=plan or not provenance['each_fit_window_heldout_once']:raise ValueError('OOF plan mismatch')
    used=[]
    for inner in provenance['inner_branches']:
        if set(inner['fit_subjects'])&set(plan['outer']+[inner['held_subject']]):raise ValueError('Indirect OOF subject leak')
        indices=np.asarray(inner['global_indices'],np.int64)
        if set(data['subjects'][indices])!={inner['held_subject']}:raise ValueError('OOF subject identity')
        used.extend(indices.tolist())
    if sorted(used)!=ids.tolist() or len(set(used))!=len(used):raise ValueError('OOF rows not exactly outer-fit rows')
    with np.load(folder/'gate_oof_clean.npz',allow_pickle=False) as z:
        np.testing.assert_array_equal(z['global_indices'],ids);np.testing.assert_array_equal(z['y'],data['y'][ids])
        cached={k:z[k].copy() for k in ['pose','rgb','features','y']}
    q=np.clip(data['pose'][ids,-16:][:,:,data['quality_indices']],0,1).astype(np.float32)
    oof=attach_quality(cached,q)
    branch,ck=final_branch(prior,plan,device)
    p,r,qq=normalized(data,ids,ck);insample=forward_branch(branch,p,r,qq,device);insample['y']=data['y'][ids]
    insample=attach_quality(insample,q)
    # These in-sample predictions are training diagnostics, never outer scores.
    destination=out/('fold'+str(plan['fold']));destination.mkdir(exist_ok=False)
    np.savez(destination/'OOF_training_bank.npz',**oof,global_indices=ids)
    np.savez(destination/'in_sample_training_bank.npz',**insample,global_indices=ids)
    write_json(destination/'fit_provenance.json',dict(fit_subjects=plan['fit'],excluded_subjects=plan['outer'],global_indices=ids.tolist(),OOF_prefix_verified=True,source='archive-bound old OOF cache; training in-sample bank regenerated from same fit4 branch'))
    del branch
    if device=='cuda':torch.cuda.empty_cache()
    return oof,insample
