"""Pure NumPy protocol logic; labels never enter the online threshold function."""
from collections import defaultdict
from pathlib import PurePosixPath
import numpy as np

POLICIES=('fixed_085','fixed_0875','fixed_090','dynamic')
METRICS=('macro_f1','macro_auprc','event_recall','false_alarms','fa_per_hour','within_1s_recall','within_2s_recall','mean_delay_seconds','median_delay_seconds','duplicates','frame_errors_repaired_vs_fixed','frame_correct_spoiled_vs_fixed','frame_predictions_changed_vs_fixed')


def check_relative(value):
    p=PurePosixPath(str(value).replace('\\','/'))
    if p.is_absolute() or '..' in p.parts or ':' in str(p):raise ValueError('Unsafe relative path: '+str(value))
    return p.as_posix()


def softmax(x):
    x=np.asarray(x,dtype=np.float64);z=np.exp(x-x.max(1,keepdims=True))
    return z/z.sum(1,keepdims=True)


def thresholds(weights,policy):
    w=np.asarray(weights,dtype=np.float64)
    if w.ndim!=1 or not np.isfinite(w).all() or np.any((w<0)|(w>1)):raise ValueError('Invalid gate weights')
    if policy=='dynamic':return .85+.05*np.abs(2*w-1)
    if policy not in POLICIES:raise ValueError('Unknown policy')
    return np.full(w.shape,{'fixed_085':.85,'fixed_0875':.875,'fixed_090':.90}[policy])


def hard_masks(pose,rgb,labels):
    p,r,y=np.asarray(pose),np.asarray(rgb),np.asarray(labels)
    if p.shape!=r.shape or p.shape!=(len(y),3) or not np.isfinite(p).all() or not np.isfinite(r).all():raise ValueError('Invalid logits')
    if not np.issubdtype(y.dtype,np.integer) or not np.isin(y,[0,1,2]).all():raise ValueError('Invalid labels')
    fixed=(.5*(p+r)).argmax(1);keep=fixed==y
    return (~keep)&((p.argmax(1)==y)|(r.argmax(1)==y)),keep


def masked_mean(values,mask):
    x,m=np.asarray(values),np.asarray(mask,dtype=bool)
    if x.shape!=m.shape:raise ValueError('Mask shape mismatch')
    return float(x[m].mean()) if m.any() else 0.


def candidates(rows,probabilities,weights,policy):
    p=np.asarray(probabilities,dtype=np.float64);tau=thresholds(weights,policy)
    if p.shape!=(len(rows),3) or tau.shape!=(len(rows),) or not np.isfinite(p).all():raise ValueError('Prediction alignment mismatch')
    if np.any(p<0) or not np.allclose(p.sum(1),1,atol=1e-5):raise ValueError('Invalid probabilities')
    grouped=defaultdict(list)
    for i,r in enumerate(rows):grouped[r['sequence_id']].append(i)
    result=[]
    for sid,indices in sorted(grouped.items()):
        indices.sort(key=lambda i:int(rows[i]['source_frame_number']))
        frames=[int(rows[i]['source_frame_number']) for i in indices]
        if len(set(frames))!=len(frames):raise ValueError('Duplicate endpoint')
        evidence=0.;above=below=0;latched=False
        for i in indices:
            score=float(np.clip(p[i,1]+p[i,2],0,1));evidence=.5*evidence+.5*score
            if not latched:
                above=above+1 if evidence>=tau[i] else 0
                if above>=2:
                    result.append(dict(candidate_id=len(result)+1,sequence_id=sid,
                        source_frame_number=int(rows[i]['source_frame_number']),sample_timestamp_ms=float(rows[i]['sample_timestamp_ms']),
                        source_timestamp_ms=float(rows[i]['source_timestamp_ms']),fall_score=score,evidence=evidence,
                        gate_weight=float(weights[i]),threshold=float(tau[i])))
                    latched=True;above=below=0
            else:
                below=below+1 if evidence<=.1 else 0
                if below>=5:latched=False;below=0
    return result


def event_metrics(alarms,specs,negative_hours):
    if not np.isfinite(negative_hours) or negative_hours<=0:raise ValueError('Missing common negative exposure')
    by=defaultdict(list)
    for r in alarms:
        if r['sequence_id'] not in specs:raise ValueError('Unknown sequence')
        by[r['sequence_id']].append(int(r['source_frame_number']))
    events=[];delays=[];fp=dup=det=timely1=timely2=0
    for sid,sp in sorted(specs.items()):
        fs=sorted(by[sid]);fall=sp['category']=='fall';onset=sp['onset']
        before=[f for f in fs if fall and f<onset];after=[f for f in fs if fall and f>=onset]
        adl=len(fs) if not fall else 0;early=len(before);duplicate=max(0,len(after)-1)
        delay=(after[0]-onset)/20 if after else None
        fp+=adl+early;dup+=duplicate;det+=bool(after)
        timely1+=int(delay is not None and delay<=1);timely2+=int(delay is not None and delay<=2)
        if delay is not None:delays.append(delay)
        events.append(dict(sequence_id=sid,category=sp['category'],onset_frame=onset,detected=int(bool(after)),
                           first_postonset_frame=after[0] if after else None,delay_seconds=delay,
                           early_false_alarms=early,adl_false_alarms=adl,duplicates=duplicate))
    n=sum(s['category']=='fall' for s in specs.values())
    if not n:raise ValueError('No fall events')
    return dict(fall_events=n,detected=int(det),event_recall=det/n,false_alarms=fp,fa_per_hour=fp/negative_hours,
        negative_exposure_hours=negative_hours,duplicates=dup,candidate_count=len(alarms),
        within_1s_detected=timely1,within_1s_recall=timely1/n,within_2s_detected=timely2,within_2s_recall=timely2/n,
        mean_delay_seconds=float(np.mean(delays)) if delays else None,
        median_delay_seconds=float(np.median(delays)) if delays else None),events


def summarize(rows):
    groups=defaultdict(list)
    for r in rows:groups[(r['model'],r['span'],r['policy'])].append(r)
    result=[]
    for (model,span,policy),rs in sorted(groups.items()):
        if sorted(r['seed'] for r in rs)!=[7,42,84]:raise ValueError('Incomplete or duplicate seed group')
        row=dict(model=model,span=span,policy=policy,runs=3)
        for key in METRICS:
            values=[r[key] for r in rs if r.get(key) is not None]
            row[key+'_valid_runs']=len(values)
            row[key+'_mean']=float(np.mean(values)) if values else None
            row[key+'_sample_sd']=float(np.std(values,ddof=1)) if len(values)>1 else None
        result.append(row)
    return result
