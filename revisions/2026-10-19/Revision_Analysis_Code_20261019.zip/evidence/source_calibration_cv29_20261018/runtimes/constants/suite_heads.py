"""Fixed18-epoch heads with source-fit-only transforms; no outer selection."""
import time
import hashlib
import numpy as np
import torch
from torch import nn
from cv_data import write_csv,write_json
from cv_training import gate_loss,digest
from suite_features import fit_transform,transform


class ConstantHead(nn.Module):
    def __init__(self):super().__init__();self.logit=nn.Parameter(torch.zeros(1))
    def forward(self,x):return self.logit.expand(len(x),1)


def new_head(name,width,seed,device):
    torch.manual_seed(seed)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)
    if name=='learned_constant':return ConstantHead().to(device)
    model=nn.Sequential(nn.Linear(width,32),nn.ReLU(),nn.Dropout(.1),nn.Linear(32,16),nn.ReLU(),nn.Linear(16,1)).to(device)
    nn.init.zeros_(model[-1].weight);nn.init.zeros_(model[-1].bias)
    return model


def fit_head(name,seed,bank,out,update,provenance,device='cuda',epochs=18):
    out.mkdir(exist_ok=False);params=fit_transform(name,bank);transformed=transform(name,bank,params)
    t={k:torch.as_tensor(v,device=device) for k,v in transformed.items()}
    y=torch.as_tensor(bank['y'],dtype=torch.long,device=device);n=len(y);counts=np.bincount(bank['y'],minlength=3)
    if np.any(counts==0):raise ValueError('Training class missing')
    cw=torch.as_tensor(n/(3.*counts),dtype=torch.float32,device=device)
    empty=torch.zeros(n,device=device);model=new_head(name,t['x'].shape[1],seed,device)
    initial=digest(model);optimizer=torch.optim.AdamW(model.parameters(),lr=.0008,weight_decay=.0001)
    torch.manual_seed(seed*10101)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(seed*10101)
    rng=np.random.RandomState(seed);history=[];began=time.monotonic()
    for epoch in range(1,epochs+1):
        model.train();order=rng.permutation(n);total=0.
        state=torch.cuda.get_rng_state(device) if torch.device(device).type=='cuda' else torch.get_rng_state()
        shuffle_hash=hashlib.sha256(order.tobytes()).hexdigest();dropout_hash=hashlib.sha256(state.cpu().numpy().tobytes()).hexdigest()
        for start in range(0,n,128):
            ix=torch.as_tensor(order[start:start+128],device=device);gl=model(t['x'][ix]).reshape(-1)
            loss=gate_loss(gl,t['pose'][ix],t['rgb'][ix],y[ix],cw,empty[ix],empty[ix],False)
            if not torch.isfinite(loss):raise FloatingPointError('Nonfinite head loss')
            optimizer.zero_grad(set_to_none=True);loss.backward()
            if not all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters()):raise FloatingPointError('Nonfinite head gradients')
            torch.nn.utils.clip_grad_norm_(model.parameters(),5.);optimizer.step();total+=float(loss.detach())*len(ix)
        history.append(dict(epoch=epoch,loss=total/n,shuffle_sha256=shuffle_hash,dropout_rng_sha256=dropout_hash));write_csv(out/'history.csv',history)
        update(stage='A_head_training',task=out.name,epoch=epoch,epochs=epochs)
        print('A_HEAD',out.name,epoch,'/',epochs,'loss',round(total/n,6),flush=True)
    checkpoint=dict(state_dict=model.state_dict(),variant=name,seed=seed,width=t['x'].shape[1],epochs=epochs,transform=params,provenance=provenance)
    torch.save(checkpoint,out/'model.pt');write_json(out/'transform.json',params)
    summary=dict(variant=name,seed=seed,epochs=epochs,windows=n,parameters=sum(p.numel() for p in model.parameters()),initialization_sha256=initial,final_state_sha256=digest(model),seconds=time.monotonic()-began)
    write_json(out/'summary.json',summary)
    # Verify actual serialized head and transform, not just a live model.
    a,w=load_predict(out/'model.pt',bank,device)
    if not np.isfinite(a).all() or not np.isfinite(w).all():raise FloatingPointError('Head reload failed')
    return summary


def load_predict(path,bank,device='cuda',expected_provenance=None,expected_role=None):
    ck=torch.load(path,map_location=device,weights_only=False)
    if expected_role is not None and (ck['variant'],ck['seed'])!=expected_role:raise ValueError('Head variant/seed role mismatch')
    if expected_provenance is not None:
        if ck['epochs']!=18:raise ValueError('Head epoch budget mismatch')
        for name,value in expected_provenance.items():
            if ck['provenance'].get(name)!=value:raise ValueError('Head provenance mismatch: '+name)
    model=new_head(ck['variant'],ck['width'],ck['seed'],device);model.load_state_dict(ck['state_dict'],strict=True);model.eval()
    values=transform(ck['variant'],bank,ck['transform'])
    with torch.no_grad():
        w=model(torch.as_tensor(values['x'],device=device)).reshape(-1).sigmoid()
        p=torch.as_tensor(values['pose'],device=device);r=torch.as_tensor(values['rgb'],device=device)
        return (w[:,None]*p+(1-w[:,None])*r).softmax(1).cpu().numpy(),w.cpu().numpy()
