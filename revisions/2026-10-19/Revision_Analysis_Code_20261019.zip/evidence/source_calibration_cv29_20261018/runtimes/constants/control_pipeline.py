#!/usr/bin/env python3
"""One-shot training-only scalar controls and sealed retrospective evaluation."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
import zipfile
from datetime import datetime,timezone,timedelta

ROOT=Path('/data1/yoloA27_full_snapshot_20261014')
PY=Path('/home/xiaohaoran/.conda/envs/yolo4090/bin/python')
RESULT='gate_constant_controls_cv29_4090_20261018_v1'
sys.dont_write_bytecode=True


def now():return datetime.now(timezone(timedelta(hours=8))).isoformat(timespec='seconds')


def bundle_check(tools):
    manifest=json.loads((tools/'BUNDLE_MANIFEST.json').read_text(encoding='utf-8'))
    for name,h in manifest.items():
        path=(tools/name).resolve()
        if Path(name).is_absolute() or '..' in Path(name).parts or ':' in name or tools.resolve() not in path.parents or hashlib.sha256(path.read_bytes()).hexdigest()!=h:raise ValueError('Bundle integrity: '+name)
    return manifest


def environment_check():
    import numpy as np
    import torch
    if Path(sys.executable).resolve()!=PY.resolve() or sys.version_info[:3]!=(3,9,25) or np.__version__!='1.26.4' or str(torch.__version__)!='2.1.0+cu121':raise RuntimeError('Use original Python3.9.25 NumPy1.26.4 Torch2.1.0+cu121 yolo4090')
    if not torch.cuda.is_available() or torch.cuda.get_device_name(0)!='NVIDIA GeForce RTX 4090' or torch.backends.cudnn.version()!=8902:raise RuntimeError('Expected allocated4090/cuDNN8902')
    torch.set_num_threads(2);torch.set_num_interop_threads(2)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=True;torch.backends.cudnn.deterministic=True;torch.backends.cudnn.benchmark=False
    return dict(python=sys.version,executable=sys.executable,numpy=np.__version__,torch=str(torch.__version__),cuda=torch.version.cuda,cudnn=torch.backends.cudnn.version(),gpu=torch.cuda.get_device_name(0),gpu_mask=os.environ.get('CUDA_VISIBLE_DEVICES','0'),cpu_threads=2,scalar_objective_dtype='float64',outer_prediction_dtype='float32')


def cuda_smoke(videos,out,update):
    import numpy as np
    import torch
    from bounded_training import collate,loss_terms
    from control_math import ScalarObjective,fit_scalar
    from cv_data import write_json
    small=[v for v in videos if v['category']=='fall'][:2]+[v for v in videos if v['category']=='adl'][:2]
    if len(small)!=4:raise ValueError('Smoke category coverage')
    objective=ScalarObjective(small,'cuda');batch=collate(small,'cuda')
    for name in ['pose','rgb']:batch[name]=batch[name].double()
    y=np.concatenate([v['y'] for v in small]);cw=torch.as_tensor(len(y)/(3.*np.bincount(y,minlength=3)),device='cuda',dtype=torch.float64)
    errors=[]
    for coefficient in [.05,.005,0.]:
        values=objective.values([.4,.5,.6],coefficient)
        for weight,value in zip([.4,.5,.6],values):
            loss,_=loss_terms(torch.full(batch['valid'].shape,weight,device='cuda',dtype=torch.float64),batch,cw,True,coefficient)
            difference=abs(float(loss)-float(value));errors.append(difference)
            if difference>1e-10:raise ValueError('CUDA full-bank loss consistency')
    result=fit_scalar(objective,.005)
    write_json(out/'cuda_smoke.json',dict(status='pass',max_objective_difference=max(errors),scalar_weight=result['weight_float32'],used_for_final_controls=False))
    update(stage='cuda_smoke_complete');print('CONSTANT_CONTROLS_CUDA_SMOKE_PASS (discarded fit)',flush=True)
    del objective,batch;torch.cuda.empty_cache()


def execute(root,out,update):
    tools=Path(__file__).resolve().parent;manifest=bundle_check(tools)
    update(stage='unit_tests')
    subprocess.run([sys.executable,'-m','unittest','discover','-s',str(tools),'-p','test_*.py','-v'],check=True)
    env=environment_check()
    from cv_data import load_source,write_json,sha
    from suite_prepare import verify_prior,PRIOR_ARCHIVE_SHA
    from bounded_prepare import verify_temperatures,SUITE_SHA
    from control_reuse import reuse_latest,derive_controls,seal_controls,verify_controls,REG_SHA
    from control_eval import evaluate_controls
    write_json(out/'environment.json',env)
    update(stage='archive_validation');prior,reused=verify_prior(root,out);suite,temps,more=verify_temperatures(root,out);reused.update(more)
    update(stage='source_preflight');data=load_source(root,out)
    for folder in [prior,suite]:
        if json.loads((folder/'source_preflight.json').read_text())['input_sha256']!=data['input_sha256']:raise ValueError('Source differs from prior runs')
    sys.path.insert(0,str(data['code']))
    write_json(out/'protocol.json',dict(locked_before_derivation=True,source='6 original training people, same retrospective outer29 events',
        scalar_fits=9,mean_controls=27,newly_trained_heads=0,reused_heads=54,coefficients=[.05,.005,0.],
        full_bank_objective='global valid-frame class-weighted CE + lambda*mean(((w-.5)/.1)^2) +.1*(sequence-balanced negative BCE + early-positive BCE)',
        objective_difference_from_prior='Global CE weighting is not identical to stochastic mean of minibatch CE ratios. Numerical scalar fit has no AdamW decay; this is a stronger diagnostic control, not an isolated optimizer/architecture ablation.',
        scalar_search='fixed[0.4,0.6],201-point grid0.001,all detected local minima and grid-best interior bracket refined by golden search tolerance1e-7,max80; endpoints+0.5 included; not mathematical global optimality proof',
        mean_control='per dynamic checkpoint: arithmetic mean of valid training-OOF frame weights only, labels not used for mean; no outer-frame averages',
        scope='all36 derived controls sealed before outer inference; no model/threshold selection on outer metrics',
        thresholds=['fixed_085','fixed_0875','fixed_090','dynamic'],primary_workpoint=.85,
        evaluation='124 pooled rows,372 fold rows,744 subject rows; same candidate rules,subject/seed/event results,common-detection-set delay differences',
        limitations='29 already-inspected events/6people,retrospective repeated development,not new blind evidence or global optimum;three seeds not87 independent events',
        branch_retraining=False,gate_retraining=False,temperature_refitting=False,external_data_used=False,original_validation_subjects_used=False,manuscript_modified=False,
        previous_CV29_sha256=PRIOR_ARCHIVE_SHA,calibration_suite_sha256=SUITE_SHA,regularization_archive_sha256=REG_SHA,bundle_sha256=manifest,environment=env))
    update(stage='frozen_head_bank_reuse');banks,more=reuse_latest(root,out,temps,data['input_sha256']);reused.update(more)
    update(stage='cuda_smoke');cuda_smoke(banks[1],out,update)
    update(stage='training_only_control_derivation');derive_controls(banks,out,temps,update)
    seal_controls(out);verify_controls(out);update(stage='controls_sealed',scalar_fits_complete=9,mean_controls_complete=27)
    print('ALL_CONSTANT_CONTROLS_SEALED 9 optimized +27 mean controls;54 frozen reused heads',flush=True)
    report=evaluate_controls(data,prior,temps,out,update);verify_controls(out)
    for path,h in {**data['input_sha256'],**reused}.items():
        if sha(Path(path))!=h:raise RuntimeError('Read-only source changed: '+path)
    if sha(prior/'Gate_CV29_Results_20261017.zip')!=PRIOR_ARCHIVE_SHA or sha(suite/'Gate_Suite_CV29_Results_20261018.zip')!=SUITE_SHA:raise ValueError('Prior archive changed')
    bundle_check(tools)
    write_json(out/'completion_summary.json',dict(status='complete',scalar_fits=9,mean_controls=27,reused_heads=54,new_training=False,manuscript_modified=False,**report))
    update(stage='packaging');archive=out/'Gate_Constant_Controls_CV29_Results_20261018.zip'
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_STORED) as z:
        for p in sorted(p for p in out.rglob('*') if p.is_file() and p!=archive and p.name!='status.json'):z.write(p,p.relative_to(out).as_posix())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:raise RuntimeError('Output ZIP CRC')
    update(state='COMPLETE',stage='complete',archive=str(archive),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size)
    print('ALL_CONSTANT_CONTROLS_EXPERIMENTS_COMPLETE',out,flush=True);print('RESULT_ARCHIVE',archive,sha(archive),flush=True)


def main():
    for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='2'
    os.environ['CUBLAS_WORKSPACE_CONFIG']=':4096:8';os.environ['PYTHONDONTWRITEBYTECODE']='1';os.environ.setdefault('CUDA_VISIBLE_DEVICES','0')
    from cv_data import write_json
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=ROOT);args=ap.parse_args();root=args.root.resolve()
    if os.name!='posix' or root!=ROOT or root not in Path(__file__).resolve().parents:raise RuntimeError('Run only under approved4090 root')
    out=root/'experiments'/RESULT
    if root not in out.resolve().parents or root not in (root/'experiments').resolve().parents:raise ValueError('Output outside project')
    out.mkdir(parents=True,exist_ok=False);began=time.monotonic();state=dict(state='RUNNING',stage='starting',pid=os.getpid(),started_at=now(),scalar_fits_complete=0,mean_controls_complete=0)
    def update(**kw):
        state.update(kw,last_update_at=now(),elapsed_seconds=time.monotonic()-began);write_json(out/'status.json',state)
    try:
        try:os.nice(5)
        except OSError:pass
        update();execute(root,out,update)
    except BaseException as exc:
        update(state='INTERRUPTED' if isinstance(exc,KeyboardInterrupt) else 'FAILED',error=repr(exc));traceback.print_exc();raise


if __name__=='__main__':main()
