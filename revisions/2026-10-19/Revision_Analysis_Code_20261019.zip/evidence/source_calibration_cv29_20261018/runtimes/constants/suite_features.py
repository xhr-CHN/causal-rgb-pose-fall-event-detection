"""Locked historical-idea matrix; fit transforms never receive outer data."""
import numpy as np
from gate_opt_calibration import fit_temperature,softmax
from gate_opt_features import gate_features

VARIANTS=('learned_constant','in_sample_static17_pad29','in_sample_temporal29',
 'OOF_raw_static17_pad29','OOF_zscore_static17_pad29','OOF_raw_temporal29',
 'OOF_zscore_temporal29','OOF_static17_pad23','OOF_semantic23',
 'OOF_calibrated_static17_pad29','OOF_calibrated_temporal29')


def feature_array(name,bank,temps):
    if name not in VARIANTS:raise ValueError('Unknown variant')
    p=(bank['pose']/temps[0]).astype(np.float32);r=(bank['rgb']/temps[1]).astype(np.float32)
    pp,rp=softmax(p),softmax(r)
    full=gate_features(bank['quality'],pp,rp)
    if name=='learned_constant':x=np.zeros((len(p),1),np.float32)
    elif name=='OOF_semantic23':x=np.concatenate([full[:,:17],pp,rp],1)
    elif name=='OOF_static17_pad23':x=np.concatenate([full[:,:17],np.zeros((len(p),6),np.float32)],1)
    else:x=full
    return x,p,r


def fit_transform(name,bank):
    if name not in VARIANTS:raise ValueError('Unknown variant')
    reports=[fit_temperature(bank[k],bank['y']) for k in ['pose','rgb']] if 'calibrated' in name else []
    temps=[r['temperature'] for r in reports] if reports else [1.,1.]
    x,_,_=feature_array(name,bank,temps)
    if 'zscore' in name:
        mean=x.mean(0).astype(np.float32);std=x.std(0).astype(np.float32);std[std<1e-6]=1.
    else:mean=np.zeros(x.shape[1],np.float32);std=np.ones(x.shape[1],np.float32)
    return dict(variant=name,temperatures=temps,temperature_fits=reports,mean=mean.tolist(),std=std.tolist(),fit_windows=len(x),fit_data='outer-fit training bank only')


def transform(name,bank,params):
    if params['variant']!=name:raise ValueError('Transform/variant mismatch')
    x,p,r=feature_array(name,bank,params['temperatures'])
    x=((x-np.asarray(params['mean'],np.float32))/np.asarray(params['std'],np.float32)).astype(np.float32)
    if 'static17' in name:x[:,17:]=0.
    if not all(np.isfinite(v).all() for v in [x,p,r]):raise FloatingPointError('Nonfinite transformed features')
    return dict(x=x,pose=p,rgb=r)
