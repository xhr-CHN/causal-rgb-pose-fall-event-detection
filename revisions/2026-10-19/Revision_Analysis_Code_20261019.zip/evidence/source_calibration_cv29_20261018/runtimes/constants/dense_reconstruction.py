"""Recover stored frame values only; never interpolate gaps or invent tails."""
import numpy as np


def reconstruct(windows,starts,ends):
    x=np.asarray(windows)
    starts,ends=np.asarray(starts),np.asarray(ends)
    if x.ndim!=3 or len(starts)!=len(x) or len(ends)!=len(x) or not len(x):
        raise ValueError('Invalid windows or frame indices')
    if not np.issubdtype(starts.dtype,np.integer) or not np.issubdtype(ends.dtype,np.integer):
        raise ValueError('Frame indices must be integers')
    if np.any(starts<1) or np.any(ends-starts+1!=x.shape[1]) or not np.isfinite(x).all():
        raise ValueError('Invalid frame span or nonfinite features')
    first,last=int(starts.min()),int(ends.max())
    dense=np.empty((last-first+1,x.shape[2]),dtype=x.dtype)
    coverage=np.zeros(last-first+1,np.int32)
    comparisons=0
    for row in np.argsort(starts,kind='stable'):
        left,right=int(starts[row])-first,int(ends[row])-first+1
        previous=coverage[left:right]>0
        if previous.any():
            comparisons+=int(previous.sum())
            if not np.array_equal(dense[left:right][previous],x[row][previous]):
                difference=np.max(np.abs(dense[left:right][previous].astype(float)-x[row][previous].astype(float)))
                raise ValueError('Overlapping values differ; no averaging permitted. Max difference='+str(difference))
        dense[left:right]=x[row]
        coverage[left:right]+=1
    if np.any(coverage==0):
        raise ValueError('Frame coverage has gaps; no interpolation permitted')
    for row in range(len(x)):
        assert np.array_equal(dense[starts[row]-first:ends[row]-first+1],x[row])
    return np.arange(first,last+1,dtype=np.int64),dense,coverage,comparisons
