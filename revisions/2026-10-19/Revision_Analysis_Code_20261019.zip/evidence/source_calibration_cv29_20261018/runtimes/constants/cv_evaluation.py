"""Dense held-out event evaluation, pooled counts and shared-branch controls."""
from collections import defaultdict
from pathlib import Path
import numpy as np
import torch
from cv_data import MODELS,SEEDS,outer_plan,dense_subset,write_csv,write_json,sha
from cv_training import fresh_branch,forward_branch,new_gate,predict_gate,normalized,digest
from gate_dynamic_utils import POLICIES,METRICS,candidates,event_metrics,summarize
from gate_opt_features import frame_metrics


def pooled_counts(rows,delays):
    if sorted(r['fold'] for r in rows)!=[1,2,3]:raise ValueError('Require exactly all three folds')
    result={k:int(sum(r[k] for r in rows)) for k in ['fall_events','detected','false_alarms','duplicates','candidate_count','within_1s_detected','within_2s_detected']}
    if result['fall_events']!=29:raise ValueError('Require29 distinct falls per comparison')
    hours=float(sum(r['negative_exposure_hours'] for r in rows))
    if hours<=0:raise ValueError('Missing pooled exposure')
    result.update(event_recall=result['detected']/29,fa_per_hour=result['false_alarms']/hours,negative_exposure_hours=hours,
                  within_1s_recall=result['within_1s_detected']/29,within_2s_recall=result['within_2s_detected']/29,
                  mean_delay_seconds=float(np.mean(delays)) if len(delays) else None,median_delay_seconds=float(np.median(delays)) if len(delays) else None)
    return result


def verify_seal(out):
    import json
    seal=json.loads((out/'training_seal.json').read_text(encoding='utf-8'))
    if seal['branch_models']!=15 or seal['gate_models']!=36 or len(seal['checkpoints'])!=51 or not seal.get('all_training_complete_before_outer_evaluation'):raise ValueError('Incomplete training seal')
    for relative,h in seal['checkpoints'].items():
        path=(out/relative).resolve()
        if out.resolve() not in path.parents or sha(path)!=h:raise ValueError('Checkpoint changed after seal: '+relative)
    return seal


def evaluate_all(data,out,update,device='cuda'):
    verify_seal(out)
    fold_rows=[];event_rows=[];person_rows=[];pooled_prediction=defaultdict(list)
    alarm_fields=['model','seed','fold','policy','candidate_id','sequence_id','source_frame_number','sample_timestamp_ms','source_timestamp_ms','fall_score','evidence','gate_weight','threshold']
    for plan in outer_plan():
        fold=plan['fold'];update(stage='outer_evaluation',fold=fold)
        folder=out/('fold'+str(fold));dense=dense_subset(data,plan['outer'])
        evalout=folder/'evaluation';evalout.mkdir(exist_ok=False)
        ck=torch.load(folder/'final_branch/model.pt',map_location='cpu',weights_only=False)
        if ck['fit_subjects']!=plan['fit'] or set(ck['fit_subjects'])&set(plan['outer']):raise ValueError('Final branch subject leak')
        branch=fresh_branch(device);branch.load_state_dict(ck['model_state_dict'],strict=True);branch.requires_grad_(False).eval()
        # All raw dense data belong only to this fold's heldout people.
        ix=np.arange(len(dense['y']));raw=dict(pose=dense['pose'],rgb=dense['rgb'],quality_indices=data['quality_indices'])
        p,r,q=normalized(raw,ix,ck);before=digest(branch);cache=forward_branch(branch,p,r,q,device)
        if digest(branch)!=before:raise RuntimeError('Frozen evaluation branch changed')
        fixed_logits=.5*(cache['pose']+cache['rgb'])
        z=np.exp(fixed_logits-fixed_logits.max(1,keepdims=True));fixed=z/z.sum(1,keepdims=True)
        predictions=[('fixed',0,fixed,np.full(len(fixed),.5)),('original',0,cache['original'],cache['original_weight'])]
        cache['y']=dense['y']
        for seed in SEEDS:
            for model in MODELS:
                checkpoint=torch.load(folder/(model+'_seed'+str(seed))/'model.pt',map_location=device,weights_only=False)
                if checkpoint['epochs']!=18 or checkpoint['seed']!=seed or checkpoint['group']!=model:raise ValueError('Gate checkpoint protocol mismatch')
                prov=checkpoint['provenance']
                if prov['fit_subjects']!=plan['fit'] or prov['excluded_subjects']!=plan['outer']:raise ValueError('Gate checkpoint subject mismatch')
                if prov['OOF_provenance_sha256']!=sha(folder/'OOF_provenance.json'):raise ValueError('Gate OOF provenance changed')
                gate=new_gate(seed,device);gate.load_state_dict(checkpoint['state_dict'],strict=True);gate.requires_grad_(False)
                prob,w=predict_gate(gate,cache,device);predictions.append((model,seed,prob,w))
        subject_array=np.array([r['subject_id'] for r in dense['rows']]);all_alarms=[]
        for model,seed,prob,w in predictions:
            np.savez(evalout/(model+'_seed'+str(seed)+'_predictions.npz'),probabilities=prob,gate_weights=w,y=dense['y'])
            write_csv(evalout/(model+'_seed'+str(seed)+'_gate_trace.csv'),[dict(sequence_id=row['sequence_id'],source_frame_number=row['source_frame_number'],gate_weight=float(weight),dynamic_threshold=.85+.05*abs(2*float(weight)-1)) for row,weight in zip(dense['rows'],w)])
            pooled_prediction[(model,seed)].append((fold,dense['y'],prob,fixed.argmax(1)))
            base=frame_metrics(dense['y'],prob)
            base.update(frame_errors_repaired_vs_fixed=int(np.sum((fixed.argmax(1)!=dense['y'])&(prob.argmax(1)==dense['y']))),frame_correct_spoiled_vs_fixed=int(np.sum((fixed.argmax(1)==dense['y'])&(prob.argmax(1)!=dense['y']))),frame_predictions_changed_vs_fixed=int(np.sum(fixed.argmax(1)!=prob.argmax(1))))
            for policy in POLICIES:
                alarms=candidates(dense['rows'],prob,w,policy);hours=float(np.sum(dense['y']==0)/(20*3600))
                metrics,events=event_metrics(alarms,dense['specs'],hours)
                if metrics['fall_events']!={1:10,2:10,3:9}[fold]:raise ValueError('Outer event count changed')
                fold_rows.append(dict(model=model,seed=seed,fold=fold,policy=policy,windows=len(prob),**base,**metrics))
                event_rows.extend(dict(model=model,seed=seed,fold=fold,policy=policy,subject_id=dense['specs'][e['sequence_id']]['subject_id'],**e) for e in events)
                all_alarms.extend(dict(model=model,seed=seed,fold=fold,policy=policy,**a) for a in alarms)
                for subject in plan['outer']:
                    si=np.flatnonzero(subject_array==subject);sps={sid:sp for sid,sp in dense['specs'].items() if sp['subject_id']==subject}
                    sa=[a for a in alarms if a['sequence_id'] in sps]
                    met,_=event_metrics(sa,sps,float(np.sum(dense['y'][si]==0)/(20*3600)))
                    person_rows.append(dict(model=model,seed=seed,fold=fold,policy=policy,subject_id=subject,**frame_metrics(dense['y'][si],prob[si]),**met))
        write_csv(evalout/'candidate_alarms.csv',all_alarms,alarm_fields)
        write_csv(evalout/'endpoint_inventory.csv',dense['rows'])
        del branch,ck,p,r,q,cache,dense,predictions
        if torch.device(device).type=='cuda':torch.cuda.empty_cache()
    pooled=[]
    for (model,seed),parts in sorted(pooled_prediction.items()):
        if sorted(p[0] for p in parts)!=[1,2,3]:raise ValueError('Missing held-out fold predictions')
        y=np.concatenate([p[1] for p in parts]);p=np.concatenate([p[2] for p in parts]);fp=np.concatenate([p[3] for p in parts])
        fm=frame_metrics(y,p)
        fm.update(frame_errors_repaired_vs_fixed=int(np.sum((fp!=y)&(p.argmax(1)==y))),frame_correct_spoiled_vs_fixed=int(np.sum((fp==y)&(p.argmax(1)!=y))),frame_predictions_changed_vs_fixed=int(np.sum(fp!=p.argmax(1))))
        for policy in POLICIES:
            rs=[r for r in fold_rows if (r['model'],r['seed'],r['policy'])==(model,seed,policy)]
            er=[r for r in event_rows if (r['model'],r['seed'],r['policy'])==(model,seed,policy) and r['category']=='fall']
            if len(er)!=29 or len({r['sequence_id'] for r in er})!=29:raise ValueError('Duplicate or missing held-out event')
            met=pooled_counts(rs,[r['delay_seconds'] for r in er if r['delay_seconds'] is not None])
            pooled.append(dict(model=model,seed=seed,span='dense_29_events',policy=policy,windows=len(y),**fm,**met))
    if len(fold_rows)!=168 or len(pooled)!=56 or len(person_rows)!=336:raise ValueError('Incomplete comparison matrix')
    aggregates=summarize([r for r in pooled if r['model'] in MODELS])
    write_csv(out/'fold_metrics.csv',fold_rows);write_csv(out/'pooled_metrics_by_seed.csv',pooled)
    write_csv(out/'aggregate_metrics.csv',aggregates);write_csv(out/'event_results.csv',event_rows);write_csv(out/'subject_metrics.csv',person_rows)
    table={(r['model'],r['seed'],r['policy']):r for r in pooled};paired=[]
    for seed in SEEDS:
        comparisons=[]
        for policy in POLICIES:
            for a,b in [('baseline','fixed'),('hard','baseline'),('aug_baseline','baseline'),('aug_hard','hard'),('aug_hard','aug_baseline')]+[(m,'original') for m in MODELS]:
                comparisons.append((a,policy,b,policy))
        for model in MODELS:
            for control in POLICIES[:3]:comparisons.append((model,'dynamic',model,control))
        for a,pa,b,pb in comparisons:
            x,z=table[(a,seed,pa)],table[(b,0 if b in ['fixed','original'] else seed,pb)]
            paired.append(dict(seed=seed,comparison=a+'/'+pa+' minus '+b+'/'+pb,**{'delta_'+k:x[k]-z[k] if x[k] is not None and z[k] is not None else None for k in METRICS}))
    write_csv(out/'paired_differences.csv',paired)
    # Fixed weight dynamic threshold must exactly equal fixed0.85 for every fold.
    for fold in [1,2,3]:
        a=next(r for r in fold_rows if (r['fold'],r['model'],r['policy'])==(fold,'fixed','fixed_085'))
        b=next(r for r in fold_rows if (r['fold'],r['model'],r['policy'])==(fold,'fixed','dynamic'))
        if {k:v for k,v in a.items() if k!='policy'}!={k:v for k,v in b.items() if k!='policy'}:raise ValueError('Fixed0.5 dynamic control differs')
    verify_seal(out)
    lines=['# 29事件按人留出比较','',
        '29个不同跌倒事件来自6人，三个门控种子不是87个独立事件。',
        '全部训练18轮固定预算，无外层选模；源内部回顾性交叉验证，不是新盲测。',
        '固定融合与original参考共享每折新训练分支；original不是历史全6人模型。',
        '分支种子固定42，三个种子仅反映门控初始化变化。',
        '先看事件召回、误报及及时检出，再看帧AP和条件延迟。','',
        '| 方案 | 门限 | 平均召回 | 平均误报次数 | 平均FA/h | 平均帧AP |','| --- | --- | ---: | ---: | ---: | ---: |']
    for r in pooled:
        if r['model'] in ['fixed','original']:
            lines.append('| '+r['model']+' | '+r['policy']+' | '+ ' | '.join(f'{r[k]:.4f}' for k in ['event_recall','false_alarms','fa_per_hour','macro_auprc'])+' |')
    for r in aggregates:lines.append('| '+r['model']+' | '+r['policy']+' | '+' | '.join(f'{r[k+"_mean"]:.4f}' for k in ['event_recall','false_alarms','fa_per_hour','macro_auprc'])+' |')
    lines+=['','不要将三个折的FA/h简单平均：本报告按误报总数除以负暴露总时长。',
        '三个折训练数据互相重叠，同一人有多个事件；未把门控种子SD当作受试者独立置信区间。',
        '预先固定18轮是受控试验预算，不代表最优收敛。本轮不根据外层表现事后挑检查点或门限。',
        '训练增强是窗口内特征连续缺失，不是新增独立人员或真实摄像机/照度。',
        '未使用原4/5号验证人员、外部数据和最终盲测，也未改最终投稿材料。']
    (out/'SUMMARY_ZH.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return dict(fold_metric_rows=len(fold_rows),pooled_rows=len(pooled),aggregate_rows=len(aggregates),subject_rows=len(person_rows),paired_rows=len(paired),unique_events=29)
