"""Two bounded scalar temperatures fitted ONLY to OOF training NLL."""
import numpy as np
from gate_opt_features import reliability

BOUNDS=(.25,16.)


def nll(logits,labels,temperature=1.):
    z=np.asarray(logits,dtype=np.float64)/temperature
    y=np.asarray(labels,dtype=np.int64)
    if z.ndim!=2 or z.shape!=(len(y),3) or not np.isfinite(z).all() or temperature<=0:
        raise ValueError('Invalid temperature/logits')
    z=z-z.max(1,keepdims=True)
    return float(np.mean(np.log(np.exp(z).sum(1))-z[np.arange(len(y)),y]))


def fit_temperature(logits,labels):
    """Deterministic bounded golden search in log T; no validation inputs."""
    a,b=np.log(BOUNDS)
    ratio=(np.sqrt(5.)-1)/2
    c,d=b-ratio*(b-a),a+ratio*(b-a)
    fc,fd=nll(logits,labels,np.exp(c)),nll(logits,labels,np.exp(d))
    for _ in range(80):
        if fc<fd:
            b,d,fd=d,c,fc
            c=b-ratio*(b-a); fc=nll(logits,labels,np.exp(c))
        else:
            a,c,fc=c,d,fd
            d=a+ratio*(b-a); fd=nll(logits,labels,np.exp(d))
    candidates=(1.,BOUNDS[0],BOUNDS[1],float(np.exp((a+b)/2)))
    t=min(candidates,key=lambda v:nll(logits,labels,v))
    return dict(temperature=float(t),bounds=list(BOUNDS),
                oof_fit_nll_before=nll(logits,labels),oof_fit_nll_after=nll(logits,labels,t),
                at_boundary=bool(abs(t-BOUNDS[0])<1e-6 or abs(t-BOUNDS[1])<1e-6))


def softmax(logits):
    z=np.asarray(logits,dtype=np.float64)
    z=z-z.max(1,keepdims=True); e=np.exp(z)
    return (e/e.sum(1,keepdims=True)).astype(np.float32)


def recalibrate_features(features,pose_logits,rgb_logits):
    out=np.asarray(features,dtype=np.float32).copy()
    pp,rp=softmax(pose_logits),softmax(rgb_logits)
    out[:,10:13]=reliability(pp)
    out[:,13:16]=reliability(rp)
    out[:,16]=np.abs(pp-rp).mean(1)
    return out
