"""Five-group endpoint plus historical references; no outer model selection."""
import json
from pathlib import Path
import numpy as np
import torch
from cv_data import outer_plan,dense_subset,SEEDS,sha,read_csv,write_csv
from cv_training import normalized,forward_branch
from suite_prepare import final_branch
from suite_eval import Collector
from suite_heads import load_predict
from bounded_prepare import videos_from_dense,CAL
from bounded_training import GROUPS,new_head,predict,group_config
from gate_dynamic_utils import POLICIES,METRICS


class FixedHalf(torch.nn.Module):
    def forward(self,x):return torch.full((len(x),),.5,dtype=torch.float32,device=x.device)


def evaluate(data,prior,suite,temps,out,update,device='cuda'):
    collector=Collector(out/'evaluation');previous=read_csv(suite/'A_results/fold_metrics.csv')
    for plan in outer_plan():
        fold=plan['fold'];update(stage='outer_evaluation',fold=fold)
        dense=dense_subset(data,plan['outer']);branch,ck=final_branch(prior,plan,device)
        raw=dict(pose=dense['pose'],rgb=dense['rgb'],quality_indices=data['quality_indices']);p,r,q=normalized(raw,np.arange(len(dense['y'])),ck)
        cache=forward_branch(branch,p,r,q,device);cache['quality']=q;cache['y']=dense['y']
        videos=videos_from_dense(dense,cache,temps[fold]);base,w=predict(FixedHalf().to(device),videos,device)
        collector.add(fold,'calibrated_fixed',0,base,w,dense,base)
        for seed in SEEDS:
            for group in GROUPS:
                path=out/'training'/('fold'+str(fold))/(group+'_seed'+str(seed))/'model.pt'
                checkpoint=torch.load(path,map_location=device,weights_only=False)
                prov=checkpoint['provenance']
                if checkpoint['group']!=group or checkpoint['seed']!=seed or checkpoint['epochs']!=18 or checkpoint['bound']!=.1:raise ValueError('Head role/budget mismatch')
                if checkpoint['reg_coefficient']!=group_config(group)[1]:raise ValueError('Regularization role mismatch')
                if prov['fit_subjects']!=plan['fit'] or prov['excluded_subjects']!=plan['outer'] or prov['temperatures']!=temps[fold]:raise ValueError('Head subject/temperature mismatch')
                if prov['bank_sha256']!=sha(out/'prepared'/('fold'+str(fold))/'dense_OOF_bank.npz'):raise ValueError('Training bank changed')
                model=new_head(checkpoint['kind'],seed,device);model.load_state_dict(checkpoint['state_dict'],strict=True)
                probability,weights=predict(model,videos,device)
                collector.add(fold,group,seed,probability,weights,dense,base,sum(p.numel() for p in model.parameters()))
            for original,name in zip(CAL,['old_cal17','old_cal29']):
                path=suite/'A_training'/('fold'+str(fold))/(original+'_seed'+str(seed))/'model.pt'
                ckold=torch.load(path,map_location='cpu',weights_only=False)
                frozen=[temps[fold][k]['temperature'] for k in ['pose','rgb']]
                if ckold['transform']['temperatures']!=frozen:raise ValueError('Old calibration temperature differs')
                probability,weights=load_predict(path,cache,device,expected_provenance=dict(fit_subjects=plan['fit'],excluded_subjects=plan['outer'],fit_provenance_sha256=sha(path.parent.parent/'fit_provenance.json')),expected_role=(original,seed))
                collector.add(fold,name,seed,probability,weights,dense,base,1505)
        # Same calibrated baseline and historical heads must preserve event counts.
        for row in [v for v in collector.fold_rows if v['fold']==fold and v['model'] in ['calibrated_fixed','old_cal17','old_cal29']]:
            name={'old_cal17':CAL[0],'old_cal29':CAL[1]}.get(row['model'],row['model'])
            old=next(v for v in previous if v['model']==name and int(v['seed'])==row['seed'] and int(v['fold'])==fold and v['policy']==row['policy'])
            for key in ['detected','false_alarms','duplicates','within_1s_detected','within_2s_detected']:
                if int(old[key])!=row[key]:raise ValueError('Frozen reference event replay mismatch: '+str((fold,name,row['seed'],key)))
            for key in ['macro_f1','macro_auprc']:np.testing.assert_allclose(row[key],float(old[key]),atol=1e-5,rtol=1e-5)
        del branch,dense,videos,cache
        if device=='cuda':torch.cuda.empty_cache()
    rows=collector.finish(100)
    paired_reports(collector,rows)
    lines=['# 校准门控：正则强度配对消融','',
        '六组新门控均密集OOF训练18轮、相同视频批次和固定温度；没有重新训练分支。',
        '显式锚定正则系数为0.05、0.005、0；AdamW weight_decay保持0.0001。每档均含常数权重和动态门控，时序损失不变。',
        '参考旧自由门控训练密度和损失不同，不能把两者差异仅归因于权重范围。',
        '29个已查看事件、6人，仍是探索性内部评价，不是独立盲测。','',
        '| 方案 | 门限 | 平均检出/29 | 平均误报 | 1秒内召回 | 2秒内召回 | 平均延迟秒 |','| --- | --- | ---: | ---: | ---: | ---: | ---: |']
    for name in ['calibrated_fixed']+GROUPS+['old_cal17','old_cal29']:
        for policy in POLICIES:
            values=[r for r in rows if r['model']==name and r['policy']==policy]
            vals=[]
            for key in ['detected','false_alarms','within_1s_recall','within_2s_recall','mean_delay_seconds']:
                valid=[r[key] for r in values if r[key] is not None];vals.append(f'{np.mean(valid):.4f}' if valid else 'NA')
            lines.append('| '+name+' | '+policy+' | '+' | '.join(vals)+' |')
    lines+=['','首先在同一门限比较检出/误报/1秒内召回，不能只比较平均延迟。',
        'model_paired_differences.csv报告同一检出集合的延迟变化、检出不一致数量与共同事件数。',
        '三个种子不是87个独立事件，种子SD不是受试者独立置信区间。',
        '时序损失只模拟连续证据，不等于真实锁存/复位报警；最终指标仍用原报警规则计算。',
        '不按外层结果选检查点/门限，不自动将任何方案写入投稿材料。']
    (collector.out/'SUMMARY_ZH.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return dict(pooled_rows=len(rows),fold_rows=len(collector.fold_rows),subject_rows=len(collector.persons),unique_events=29)


def paired_reports(collector,rows):
    table={(r['model'],r['seed'],r['policy']):r for r in rows};events={}
    for r in collector.events:
        if r['category']=='fall':events.setdefault((r['model'],r['seed'],r['policy']),{})[r['sequence_id']]=r
    pairs=[(g,'calibrated_fixed') for g in GROUPS]
    pairs += [('dynamic_'+reg+'_temporal','constant_'+reg+'_temporal') for reg in ['r005','r0005','r0']]
    pairs += [(kind+'_'+reg+'_temporal',kind+'_r005_temporal') for kind in ['constant','dynamic'] for reg in ['r0005','r0']]
    output=[]
    for seed in SEEDS:
        for a,b in pairs:
            for policy in POLICIES:
                bs=0 if b=='calibrated_fixed' else seed;x,z=table[(a,seed,policy)],table[(b,bs,policy)]
                ea,eb=events[(a,seed,policy)],events[(b,bs,policy)]
                if set(ea)!=set(eb) or len(ea)!=29:raise ValueError('Paired event identity')
                shared=[k for k in ea if ea[k]['detected'] and eb[k]['detected']]
                delays=[ea[k]['delay_seconds']-eb[k]['delay_seconds'] for k in shared]
                record=dict(seed=seed,policy=policy,comparison=a+' minus '+b,**{'delta_'+k:x[k]-z[k] if x[k] is not None and z[k] is not None else None for k in METRICS})
                record.update(A_only_detected=sum(ea[k]['detected'] and not eb[k]['detected'] for k in ea),B_only_detected=sum(eb[k]['detected'] and not ea[k]['detected'] for k in ea),matched_detected=len(shared),mean_delay_change_matched=float(np.mean(delays)) if delays else None)
                output.append(record)
    write_csv(collector.out/'model_paired_differences.csv',output)
