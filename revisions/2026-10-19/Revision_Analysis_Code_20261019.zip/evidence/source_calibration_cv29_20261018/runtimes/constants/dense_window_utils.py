import numpy as np


def windows_at(raw,frames,endpoints,width=16):
    raw,frames,endpoints=np.asarray(raw),np.asarray(frames),np.asarray(endpoints)
    if raw.ndim!=2 or len(raw)!=len(frames) or not np.all(np.diff(frames)==1):
        raise ValueError('Expected contiguous, aligned feature indices')
    starts=endpoints-frames[0]-width+1
    if np.any(starts<0) or np.any(starts+width>len(raw)):
        raise ValueError('Requested endpoint outside known covered span')
    return np.stack([raw[int(i):int(i)+width] for i in starts])


def state_targets(frames,category,onset=None,stable=None):
    frames=np.asarray(frames)
    if category=='adl':return np.zeros(len(frames),np.int64)
    if category!='fall' or onset is None or stable is None or not 1<=onset<stable:
        raise ValueError('Explicit fall boundaries required; no label guessing')
    return np.where(frames<onset,0,np.where(frames<stable,1,2)).astype(np.int64)
