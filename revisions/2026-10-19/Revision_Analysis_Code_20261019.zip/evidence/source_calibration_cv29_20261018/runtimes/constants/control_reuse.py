"""Archive-bound frozen heads, banks and training-only derived controls."""
import hashlib
import json
from pathlib import Path
import zipfile
import numpy as np
import torch
from cv_data import outer_plan,SEEDS,sha,write_json,write_csv
from reuse_banks import decode_bank
from bounded_training import GROUPS,new_head,predict,group_config
from control_math import REGS,ScalarObjective,fit_scalar,mean_training_weight

REG_RESULT='gate_regularization_cv29_4090_20261018_v1'
REG_ARCHIVE='Gate_Regularization_CV29_Results_20261018.zip'
REG_SHA='7aa12ea5d5dc95d43b234ba1d844ac2df83bbbd5ceee82f32e2efc5ce7b1a98c'


def reuse_latest(root,out,temps,source_hashes):
    folder=(root/'experiments'/REG_RESULT).resolve();archive=folder/REG_ARCHIVE
    if root.resolve() not in folder.parents or json.loads((folder/'status.json').read_text())['state']!='COMPLETE':raise ValueError('Regularization run incomplete')
    if sha(archive)!=REG_SHA:raise ValueError('Regularization archive hash')
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None or len(z.namelist())!=len(set(z.namelist())):raise ValueError('Regularization archive CRC/duplicates')
        sealed=json.loads(z.read('training_seal.json'))
        if sealed['heads']!=54 or not sealed['all_training_complete_before_outer_evaluation']:raise ValueError('Prior seal incomplete')
        hashes=sealed['checkpoints_and_banks']
        expected={f'training/fold{p["fold"]}/{g}_seed{s}/model.pt' for p in outer_plan() for g in GROUPS for s in SEEDS}
        if {n for n in hashes if n.endswith('/model.pt')}!=expected:raise ValueError('Prior head role matrix')
        for name,h in hashes.items():
            if hashlib.sha256(z.read(name)).hexdigest()!=h:raise ValueError('Prior sealed file altered: '+name)
        if json.loads(z.read('source_preflight.json'))['input_sha256']!=source_hashes:raise ValueError('Source identity changed')
        if json.loads(z.read('frozen_temperatures.json'))!={str(k):v for k,v in temps.items()}:raise ValueError('Temperature identity')
        banks={};names=set(expected)|{'evaluation/fold_metrics.csv','frozen_temperatures.json'}
        for plan in outer_plan():
            prefix=f'prepared/fold{plan["fold"]}/';required=[prefix+n for n in ['dense_OOF_bank.npz','videos.json','provenance.json']]
            if not set(required)<=set(hashes):raise ValueError('Unsealed training bank')
            prov=json.loads(z.read(required[2]))
            if prov['plan']!=plan or prov['temperatures']!=temps[plan['fold']] or not prov['dense20Hz'] or prov['branch_training']:raise ValueError('Bank lineage')
            banks[plan['fold']]=decode_bank(z.read(required[0]),z.read(required[1]),plan);names.update(required)
        for name in sorted(names):
            target=(out/name).resolve()
            if out.resolve() not in target.parents:raise ValueError('Archive path outside result')
            if name=='frozen_temperatures.json':
                if target.read_bytes()!=z.read(name):raise ValueError('Frozen temperature encoding mismatch')
                continue
            if name=='evaluation/fold_metrics.csv':target=out/'reused_reference_fold_metrics.csv'
            target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as f:f.write(z.read(name))
        write_json(out/'regularization_reuse.json',dict(archive=str(archive),archive_sha256=REG_SHA,reused_heads=54,branch_training=False,gate_training=False,fit_only=True))
    return banks,{str(archive):REG_SHA}


def load_head(out,plan,group,seed,temps,device):
    ck=torch.load(out/'training'/f'fold{plan["fold"]}'/f'{group}_seed{seed}'/'model.pt',map_location=device,weights_only=False)
    prov=ck['provenance'];kind,coefficient=group_config(group)
    if ck['kind']!=kind or ck['group']!=group or ck['seed']!=seed or ck['epochs']!=18 or ck['bound']!=.1 or ck['reg_coefficient']!=coefficient:raise ValueError('Reused head role')
    if prov['fit_subjects']!=plan['fit'] or prov['excluded_subjects']!=plan['outer'] or prov['temperatures']!=temps[plan['fold']]:raise ValueError('Reused head subject/temperature lineage')
    if prov['bank_sha256']!=sha(out/'prepared'/f'fold{plan["fold"]}'/'dense_OOF_bank.npz'):raise ValueError('Bank changed since head fit')
    model=new_head(kind,seed,device);model.load_state_dict(ck['state_dict'],strict=True);model.requires_grad_(False).eval()
    return model


def derive_controls(banks,out,temps,update,device='cuda'):
    derived=out/'derived';derived.mkdir(exist_ok=False);fit_rows=[];mean_rows=[];count=0
    for plan in outer_plan():
        fold=plan['fold'];videos=banks[fold]
        if set(v['subject_id'] for v in videos)!=set(plan['fit']):raise ValueError('Fit bank people')
        folder=derived/f'fold{fold}';folder.mkdir();obj=ScalarObjective(videos,device)
        for reg,coefficient in REGS.items():
            update(stage='scalar_fitting',fold=fold,task=reg,scalar_fits_complete=count)
            result=fit_scalar(obj,coefficient)
            result.update(fold=fold,fit_subjects=plan['fit'],excluded_subjects=plan['outer'],training_windows=sum(len(v['y']) for v in videos),outer_data_used=False)
            write_json(folder/f'optimized_{reg}.json',result);count+=1
            fit_rows.append({k:v for k,v in result.items() if k not in ['grid','refinements','fit_subjects','excluded_subjects']})
            print('SCALAR_CONTROL_COMPLETE',fold,reg,'weight',result['weight_float32'],'loss',result['selected_objective'],'vs_half',result['fixed_half_objective'],flush=True)
            for seed in SEEDS:
                group=f'dynamic_{reg}_temporal';model=load_head(out,plan,group,seed,temps,device)
                _,weights=predict(model,videos,device);mean=mean_training_weight(weights)
                row=dict(fold=fold,reg=reg,seed=seed,weight_float64=mean,weight_float32=float(np.float32(mean)),training_windows=len(weights),
                    training_weight_sd=float(np.std(weights.astype(np.float64))),definition='valid training OOF frames equally weighted; no outer frames',
                    fit_subjects=plan['fit'],excluded_subjects=plan['outer'],outer_data_used=False,
                    source_head_sha256=sha(out/'training'/f'fold{fold}'/f'{group}_seed{seed}'/'model.pt'))
                write_json(folder/f'mean_{reg}_seed{seed}.json',row)
                mean_rows.append({k:v for k,v in row.items() if k not in ['fit_subjects','excluded_subjects']})
                update(stage='mean_control_derivation',fold=fold,task=f'{reg}_seed{seed}',scalar_fits_complete=count,mean_controls_complete=len(mean_rows))
                print('TRAIN_MEAN_CONTROL_COMPLETE',fold,reg,seed,'weight',row['weight_float32'],flush=True)
        del obj
        if device=='cuda':torch.cuda.empty_cache()
    if count!=9 or len(mean_rows)!=27:raise ValueError('Derived controls incomplete')
    write_csv(out/'scalar_fit_summary.csv',fit_rows);write_csv(out/'mean_control_summary.csv',mean_rows)
    update(stage='controls_derived',scalar_fits_complete=9,mean_controls_complete=27)


def seal_controls(out):
    models=list((out/'training').rglob('model.pt'))
    if len(models)!=54:raise ValueError('Expected54 frozen reused heads')
    expected={f'derived/fold{fold}/optimized_{reg}.json' for fold in [1,2,3] for reg in REGS}
    expected|={f'derived/fold{fold}/mean_{reg}_seed{seed}.json' for fold in [1,2,3] for reg in REGS for seed in SEEDS}
    actual={p.relative_to(out).as_posix() for p in (out/'derived').rglob('*.json')}
    if actual!=expected:raise ValueError('Expected9 optimized plus27 mean controls')
    files=models+[out/n for n in sorted(expected)]+[p for p in (out/'prepared').rglob('*') if p.is_file()]+[out/'frozen_temperatures.json',out/'protocol.json']
    hashes={p.relative_to(out).as_posix():sha(p) for p in files}
    write_json(out/'controls_seal.json',dict(reused_heads=54,newly_trained_heads=0,scalar_fits=9,mean_controls=27,all_controls_frozen_before_outer_evaluation=True,files=hashes))


def verify_controls(out):
    sealed=json.loads((out/'controls_seal.json').read_text())
    if sealed['scalar_fits']!=9 or sealed['mean_controls']!=27 or sealed['reused_heads']!=54 or sealed['newly_trained_heads']!=0 or not sealed['all_controls_frozen_before_outer_evaluation']:raise ValueError('Controls not completely sealed')
    for name,h in sealed['files'].items():
        path=(out/name).resolve()
        if out.resolve() not in path.parents or sha(path)!=h:raise ValueError('Frozen control altered: '+name)
