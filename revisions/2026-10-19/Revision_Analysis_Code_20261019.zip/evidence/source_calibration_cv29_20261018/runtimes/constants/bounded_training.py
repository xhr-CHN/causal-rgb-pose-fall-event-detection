"""Baseline-centred, whole-video calibrated gate; no branch gradients."""
import hashlib
import time
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from cv_data import write_csv,write_json

REGULARIZATIONS={'r005':.05,'r0005':.005,'r0':0.}
GROUPS=[kind+'_'+reg+'_temporal' for reg in REGULARIZATIONS for kind in ['constant','dynamic']]


def group_config(group):
    if group not in GROUPS:raise ValueError('Unknown regularization group')
    kind,reg,_=group.split('_')
    return kind,REGULARIZATIONS[reg]


def parameter_digest(model):
    h=hashlib.sha256()
    for key,value in sorted(model.state_dict().items()):
        h.update(key.encode());h.update(value.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()


class BoundedHead(nn.Module):
    def __init__(self,kind):
        super().__init__();self.kind=kind
        if kind=='constant':self.scalar=nn.Parameter(torch.zeros(1))
        elif kind=='dynamic':
            self.network=nn.Sequential(nn.Linear(29,32),nn.ReLU(),nn.Dropout(.1),nn.Linear(32,16),nn.ReLU(),nn.Linear(16,1))
            nn.init.zeros_(self.network[-1].weight);nn.init.zeros_(self.network[-1].bias)
        else:raise ValueError('Unknown head')
    def forward(self,x):
        g=self.scalar.expand(len(x)) if self.kind=='constant' else self.network(x).reshape(-1)
        return .5+.1*torch.tanh(g)


def new_head(kind,seed,device):
    torch.manual_seed(seed)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)
    return BoundedHead(kind).to(device)


def collate(videos,device):
    if not videos:raise ValueError('Empty video batch')
    b=len(videos);t=max(len(v['y']) for v in videos)
    arrays=dict(x=np.zeros((b,t,29),np.float32),pose=np.zeros((b,t,3),np.float32),rgb=np.zeros((b,t,3),np.float32),
        y=np.full((b,t),-100,np.int64),valid=np.zeros((b,t),bool),negative=np.zeros((b,t),bool),positive=np.zeros((b,t),bool))
    for j,v in enumerate(videos):
        n=len(v['y']);frames=np.asarray(v['frames'])
        if not n or not np.all(np.diff(frames)==1):raise ValueError('Temporal training requires dense consecutive source frames')
        for name in ['x','pose','rgb','y']:
            if len(v[name])!=n:raise ValueError('Video alignment')
            arrays[name][j,:n]=v[name]
        arrays['valid'][j,:n]=True
        if v['category']=='adl':arrays['negative'][j,:n]=True
        elif v['category']=='fall':
            onset=int(v['onset']);arrays['negative'][j,:n]=frames<onset
            arrays['positive'][j,:n]=(frames>=onset+2)&(frames<=onset+20)
        else:raise ValueError('Explicit video category required')
    return {k:torch.as_tensor(v,device=device) for k,v in arrays.items()}


def evidence_curve(score,valid):
    if score.shape!=valid.shape or score.ndim!=2:raise ValueError('Evidence shape')
    state=torch.zeros_like(score[:,0]);result=[]
    for t in range(score.shape[1]):
        state=torch.where(valid[:,t],.5*state+.5*score[:,t].clamp(0,1),state)
        result.append(state)
    return torch.stack(result,1)


def sequence_mean(values,mask):
    count=mask.sum(1);per=(values*mask).sum(1)/count.clamp_min(1)
    eligible=count>0
    return (per*eligible).sum()/eligible.sum().clamp_min(1)


def loss_terms(w,batch,cw,temporal,reg_coefficient=.05):
    if not np.isfinite(reg_coefficient) or reg_coefficient<0:raise ValueError('Invalid regularization coefficient')
    valid=batch['valid'];logits=w[:,:,None]*batch['pose']+(1-w[:,:,None])*batch['rgb']
    ce=F.cross_entropy(logits[valid],batch['y'][valid],weight=cw)
    regularization=(((w[valid]-.5)/.1)**2).mean()
    score=logits.softmax(-1)[:,:,1:].sum(-1);e=evidence_curve(score,valid).clamp(1e-6,1-1e-6)
    neg=sequence_mean(-torch.log1p(-e),batch['negative'])
    pos=sequence_mean(-torch.log(e),batch['positive'])
    total=ce+reg_coefficient*regularization+(.1*(neg+pos) if temporal else 0.)
    return total,dict(CE=ce,regularization=regularization,negative=neg,early_positive=pos)


def predict(model,videos,device='cuda'):
    model.eval();probabilities=[];weights=[]
    with torch.no_grad():
        for v in videos:
            x=torch.as_tensor(v['x'],device=device);w=model(x)
            p=torch.as_tensor(v['pose'],device=device);r=torch.as_tensor(v['rgb'],device=device)
            probabilities.append((w[:,None]*p+(1-w[:,None])*r).softmax(1).cpu().numpy());weights.append(w.cpu().numpy())
    return np.concatenate(probabilities),np.concatenate(weights)


def fit_head(group,seed,videos,out,update,provenance,device='cuda',epochs=18):
    kind,reg_coefficient=group_config(group)
    out.mkdir(exist_ok=False);temporal=True
    y=np.concatenate([v['y'] for v in videos]);counts=np.bincount(y,minlength=3)
    if np.any(counts==0):raise ValueError('Missing fit class')
    cw=torch.as_tensor(len(y)/(3.*counts),dtype=torch.float32,device=device)
    model=new_head(kind,seed,device);optimizer=torch.optim.AdamW(model.parameters(),lr=.0008,weight_decay=.0001)
    initialization_sha256=parameter_digest(model)
    with torch.no_grad():
        if not torch.all(model(torch.as_tensor(videos[0]['x'][:2],device=device))==.5):raise ValueError('Initial gate must equal fixed0.5')
    torch.manual_seed(seed*10101)
    if torch.cuda.is_available():torch.cuda.manual_seed_all(seed*10101)
    rng=np.random.RandomState(seed);history=[];schedule=[];updates=0;began=time.monotonic()
    for epoch in range(1,epochs+1):
        model.train();order=rng.permutation(len(videos));totals=np.zeros(5);batches=0
        state=torch.cuda.get_rng_state(device) if torch.device(device).type=='cuda' else torch.get_rng_state()
        fingerprint=dict(order=hashlib.sha256(order.astype('<i8').tobytes()).hexdigest(),dropout=hashlib.sha256(state.cpu().numpy().tobytes()).hexdigest());schedule.append(fingerprint)
        for start in range(0,len(order),4):
            batch=collate([videos[int(i)] for i in order[start:start+4]],device)
            w=model(batch['x'].reshape(-1,29)).reshape(batch['valid'].shape)
            loss,parts=loss_terms(w,batch,cw,temporal,reg_coefficient)
            if not torch.isfinite(loss):raise FloatingPointError('Nonfinite bounded-head loss')
            optimizer.zero_grad(set_to_none=True);loss.backward()
            if not all(p.grad is None or torch.isfinite(p.grad).all() for p in model.parameters()):raise FloatingPointError('Nonfinite head gradients')
            norm=torch.nn.utils.clip_grad_norm_(model.parameters(),5.)
            if not torch.isfinite(norm):raise FloatingPointError('Nonfinite gradient norm')
            optimizer.step();updates+=1;batches+=1
            totals+=np.array([float(loss.detach())]+[float(parts[k].detach()) for k in ['CE','regularization','negative','early_positive']])
        history.append(dict(epoch=epoch,loss=totals[0]/batches,CE=totals[1]/batches,regularization=totals[2]/batches,negative=totals[3]/batches,early_positive=totals[4]/batches,**fingerprint))
        write_csv(out/'history.csv',history);update(stage='head_training',task=out.name,epoch=epoch,epochs=epochs)
        print('REGULARIZATION_HEAD',out.name,epoch,'/',epochs,'loss',round(totals[0]/batches,6),flush=True)
    ck=dict(state_dict=model.state_dict(),kind=kind,group=group,seed=seed,epochs=epochs,bound=.1,reg_coefficient=reg_coefficient,provenance=provenance)
    torch.save(ck,out/'model.pt')
    p,w=predict(model,videos,device)
    loaded=new_head(kind,seed,device);loaded.load_state_dict(torch.load(out/'model.pt',map_location=device,weights_only=False)['state_dict'])
    pp,ww=predict(loaded,videos,device);np.testing.assert_array_equal(p,pp);np.testing.assert_array_equal(w,ww)
    summary=dict(group=group,seed=seed,epochs=epochs,reg_coefficient=reg_coefficient,initialization_sha256=initialization_sha256,videos=len(videos),windows=len(y),updates=updates,parameters=sum(v.numel() for v in model.parameters()),train_weight_mean=float(w.mean()),train_weight_sd=float(w.std()),train_weight_min=float(w.min()),train_weight_max=float(w.max()),train_fraction_within_001_of_half=float(np.mean(np.abs(w-.5)<.01)),seconds=time.monotonic()-began,schedule=schedule)
    write_json(out/'summary.json',summary)
    return summary
