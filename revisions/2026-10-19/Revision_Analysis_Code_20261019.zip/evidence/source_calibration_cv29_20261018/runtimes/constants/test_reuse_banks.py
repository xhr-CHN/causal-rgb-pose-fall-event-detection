import io
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile
import numpy as np
from reuse_banks import decode_bank,reuse,BOUNDED_RESULT,BOUNDED_ARCHIVE
from cv_data import outer_plan,write_json


class BankChecks(unittest.TestCase):
    def fixture(self):
        a=dict(x=np.zeros((6,29),np.float32),pose=np.zeros((6,3),np.float32),rgb=np.zeros((6,3),np.float32),
            y=np.array([0,1,2,0,0,0]),frames=np.array([16,17,18,16,17,18]),offsets=np.array([0,3,6]))
        videos=[dict(sequence_id='a',subject_id=6,category='fall',onset=17),dict(sequence_id='b',subject_id=7,category='adl',onset=None)]
        return a,videos

    def decode(self,a,videos,fit=None):
        b=io.BytesIO();np.savez(b,**a)
        return decode_bank(b.getvalue(),json.dumps(videos).encode(),dict(fit=fit or [6,7]))

    def test_dense_roundtrip(self):
        a,v=self.fixture();result=self.decode(a,v);self.assertEqual(len(result),2)
        np.testing.assert_array_equal(result[0]['y'],[0,1,2])

    def test_outer_subject_and_duplicate_rejected(self):
        a,v=self.fixture()
        with self.assertRaises(ValueError):self.decode(a,v,[1,6])
        v[1]['sequence_id']='a'
        with self.assertRaises(ValueError):self.decode(a,v)

    def test_sparse_nonfinite_and_bad_offsets_rejected(self):
        for which in ['sparse','nan','offsets']:
            a,v=self.fixture()
            if which=='sparse':a['frames'][1]=19
            elif which=='nan':a['x'][1,1]=np.nan
            else:a['offsets'][-1]=7
            with self.assertRaises(ValueError):self.decode(a,v)

    def test_archive_bank_reuse_and_wrong_source_rejected(self):
        with tempfile.TemporaryDirectory(dir=Path.cwd()) as directory:
            root=Path(directory).resolve();folder=root/'experiments'/BOUNDED_RESULT;folder.mkdir(parents=True)
            write_json(folder/'status.json',dict(state='COMPLETE'));source={'fixture':'abc'}
            temps={p['fold']:dict(pose=dict(temperature=2.),rgb=dict(temperature=3.)) for p in outer_plan()}
            payload={}
            for i in range(36):payload['training/'+str(i)+'/model.pt']=b'model-fixture'
            for p in outer_plan():
                x=self.fixture()[0];fit=p['fit'];n=3*len(fit)
                x.update(x=np.zeros((n,29),np.float32),pose=np.zeros((n,3),np.float32),rgb=np.zeros((n,3),np.float32),
                    y=np.tile([0,1,2],len(fit)),frames=np.tile([16,17,18],len(fit)),offsets=np.arange(0,n+1,3))
                buffer=io.BytesIO();np.savez(buffer,**x);prefix='prepared/fold'+str(p['fold'])+'/'
                payload[prefix+'dense_OOF_bank.npz']=buffer.getvalue()
                payload[prefix+'videos.json']=json.dumps([dict(sequence_id='S'+str(s),subject_id=s,category='fall',onset=17) for s in fit]).encode()
                payload[prefix+'provenance.json']=json.dumps(dict(plan=p,temperatures=temps[p['fold']],dense20Hz=True,branch_training=False)).encode()
            payload['frozen_temperatures.json']=json.dumps(temps).encode()
            seal=dict(heads=36,all_training_complete_before_outer_evaluation=True,checkpoints_and_banks={n:hashlib.sha256(b).hexdigest() for n,b in payload.items()})
            payload['training_seal.json']=json.dumps(seal).encode();payload['source_preflight.json']=json.dumps(dict(input_sha256=source)).encode()
            archive=folder/BOUNDED_ARCHIVE
            with zipfile.ZipFile(archive,'x') as z:
                for name,data in payload.items():z.writestr(name,data)
            out=root/'out';out.mkdir();bad=root/'bad';bad.mkdir()
            with patch('reuse_banks.BOUNDED_SHA',hashlib.sha256(archive.read_bytes()).hexdigest()):
                banks,_=reuse(root,out,temps,source)
                self.assertEqual(sorted(banks),[1,2,3]);self.assertEqual(len(banks[1]),4)
                for name,data in payload.items():
                    if name.startswith('prepared/'):self.assertEqual((out/name).read_bytes(),data)
                with self.assertRaises(ValueError):reuse(root,bad,temps,{'wrong':'identity'})
            with self.assertRaises(ValueError):reuse(root,bad,temps,source)


if __name__=='__main__':unittest.main(verbosity=2)
