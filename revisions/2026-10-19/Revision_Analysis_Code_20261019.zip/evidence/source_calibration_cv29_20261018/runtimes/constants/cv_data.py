"""Read-only source data, explicit labels and subject-isolated fit plans."""
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path
import numpy as np
from dense_reconstruction import reconstruct
from dense_window_utils import windows_at,state_targets

ROOT=Path('/data1/yoloA27_full_snapshot_20261014')
PY=Path('/home/xiaohaoran/.conda/envs/yolo4090/bin/python')
RESULT='gate_cv29_4090_20261017_v2'
SUBJECTS=[1,3,6,7,8,9]
MODELS=['baseline','hard','aug_baseline','aug_hard']
SEEDS=[7,42,84]
EPOCHS=18
CODE_HASHES={
 'train_quality_gated_fusion_tcn.py':'533cb7252b032ccde4416e28b355283490deb9297e3326da8c6f9d3b34850d7c',
 'train_quality_gated_logit_fusion_v2.py':'baf5cfe9670bf5cbcb5c06913139b8a0cb4811631ab7d590658420dcf88ac796',
 'train_quality_gated_logit_fusion_v3_w16.py':'3db6a3cc3fcb13c8785aa2d2e270ffddba17dea8ac2c576039828b236150bc55'}
SOURCE_HASHES={
 'caucafall_pose_windows_3state_kinematic_v2/train_windows.npz':'3860053a09293f737cf0586747e5317c5d6595e11f73b69f03d018953be978a8',
 'caucafall_pose_windows_3state_kinematic_v2/train_window_metadata.csv':'9b2b9ea7f4fb8784bca62f050c2b88e1eeedcc4bc2889125eee4d608a1b8790c',
 'caucafall_rgb_roi_windows_3state_v1/train_windows.npz':'71dfc85d99775d0c612afb25d9ab35ae88844c36c3a4b6e11f99c91f294c1cf8',
 'caucafall_rgb_roi_windows_3state_v1/train_window_metadata.csv':'d53e50970d3e83a33a0f28b6791518954131d87ce2d0e50287b01614c75be18f'}


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def read_csv(path):
    with Path(path).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))


def write_json(path,obj):
    path=Path(path);tmp=path.with_suffix(path.suffix+'.partial')
    tmp.write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8');tmp.replace(path)


def write_csv(path,rows,fields=None):
    if fields is None:
        if not rows:raise ValueError('Empty CSV needs explicit columns')
        fields=list(rows[0])
    with Path(path).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)


def outer_plan():
    result=[]
    for fold,outer in [(1,[1,3]),(2,[6,7]),(3,[8,9])]:
        fit=sorted(set(SUBJECTS)-set(outer))
        result.append(dict(fold=fold,outer=outer,fit=fit,inner=[dict(held=s,fit=sorted(set(fit)-{s})) for s in fit]))
    return result


def check_fit(fit,allowed,excluded):
    if not fit or len(set(fit))!=len(fit) or not set(fit)<=set(allowed) or set(fit)&set(excluded):raise ValueError('Subject leakage or invalid fit population')


def validate_sequence(sid,rows,annotation):
    cats={r['category'].lower() for r in rows};subjects={int(r['subject_id']) for r in rows}
    if len(cats)!=1 or len(subjects)!=1:raise ValueError('Inconsistent sequence identity: '+sid)
    category=next(iter(cats));ends=np.array([int(r['target_frame_index']) for r in rows])
    labels=np.array([int(r['target_state_id']) for r in rows])
    if category=='adl':
        if not np.all(labels==0) or any('fall' in r['activity_name'].lower() for r in rows):raise ValueError('ADL category/label conflict: '+sid)
        if annotation is not None:raise ValueError('ADL unexpectedly has fall-boundary record: '+sid)
        return category,None,None
    if category!='fall' or annotation is None or annotation.get('status')!='checked':raise ValueError('Explicit checked fall boundaries required: '+sid)
    onset,stable=int(annotation['onset_frame']),int(annotation['stable_fallen_frame'])
    if int(annotation['subject_id'])!=next(iter(subjects)) or float(annotation['fps'])!=20.0 or not 0<onset<stable<=max(ends)<=int(annotation['total_frames']):raise ValueError('Invalid annotation or covered span: '+sid)
    for row in rows:
        if int(row['onset_frame'])!=onset or int(row['stable_fallen_frame'])!=stable:raise ValueError('Annotation/metadata mismatch: '+sid)
    np.testing.assert_array_equal(labels,state_targets(ends,'fall',onset,stable))
    return category,onset,stable


def load_source(root,out):
    root=root.resolve();hashes={}
    def checked(path,expected=None):
        path=path.resolve()
        if root not in path.parents:raise ValueError('Input outside project')
        h=sha(path)
        if expected is not None and h!=expected:raise ValueError('Input hash mismatch: '+str(path))
        hashes[str(path)]=h;return path
    code=root/'causal_rgb_pose_fall_event_detection_release_candidate_v1/code'
    for name,h in CODE_HASHES.items():checked(code/name,h)
    files={name:checked(root/'features'/name,h) for name,h in SOURCE_HASHES.items()}
    arrays=[];metadata=[];names=[];ys=[]
    for name,dim in [('caucafall_pose_windows_3state_kinematic_v2',95),('caucafall_rgb_roi_windows_3state_v1',256)]:
        with np.load(files[name+'/train_windows.npz'],allow_pickle=False) as z:
            if z['x'].shape!=(2513,32,dim) or int(z['window_length'])!=32 or z['state_names'].tolist()!=['ADL','Falling','Fallen']:raise ValueError('Unexpected source feature schema')
            arrays.append(z['x'].copy());ys.append(z['y'].copy());names.append(z['feature_names'].tolist())
        metadata.append(read_csv(files[name+'/train_window_metadata.csv']))
    np.testing.assert_array_equal(ys[0],ys[1])
    if any(len(m)!=2513 for m in metadata):raise ValueError('Metadata row count')
    for a,b in zip(*metadata):
        for k in ['sequence_id','subject_id','category','start_frame_index','target_frame_index','target_state_id']:
            if a[k]!=b[k]:raise ValueError('Pose/RGB alignment mismatch: '+k)
    meta=metadata[0];subjects=np.array([int(m['subject_id']) for m in meta])
    if set(subjects)!=set(SUBJECTS):raise ValueError('Source-validation/test subjects must not enter this experiment')
    np.testing.assert_array_equal(ys[0],np.array([int(r['target_state_id']) for r in meta]))
    annotations=read_csv(checked(root/'features/caucafall_pose_windows_3state_kinematic_v2/caucafall_state_annotations.csv'))
    lookup={r['sequence_id']:r for r in annotations}
    if len(lookup)!=len(annotations):raise ValueError('Duplicate annotation sequence')
    grouped=defaultdict(list)
    for row in meta:grouped[row['sequence_id']].append(row)
    specs={};ledger=[]
    for sid,group in sorted(grouped.items()):
        cat,onset,stable=validate_sequence(sid,group,lookup.get(sid));subject=int(group[0]['subject_id'])
        specs[sid]=dict(category=cat,onset=onset,stable=stable,subject_id=subject)
        ledger.append(dict(sequence_id=sid,subject_id=subject,category=cat,windows=len(group),onset=onset,stable=stable,last_covered_frame=max(int(r['target_frame_index']) for r in group)))
    if len(specs)!=59 or sum(v['category']=='fall' for v in specs.values())!=29 or sum(v['category']=='adl' for v in specs.values())!=30:raise ValueError('Unexpected59/29/30 source inventory')
    from gate_opt_features import QUALITY_NAMES
    qi=[names[0].index(n) for n in QUALITY_NAMES]
    data=dict(pose=arrays[0],rgb=arrays[1],y=ys[0],meta=meta,subjects=subjects,specs=specs,quality_indices=qi,names=names,input_sha256=hashes,code=code)
    if not all(np.isfinite(x).all() for x in arrays):raise ValueError('Nonfinite source features')
    report=dict(subjects=SUBJECTS,sequences=59,fall_events=29,adl_sequences=30,training_windows=2513,ADL_confirmed_by='explicit category plus all endpoint state labels, not missing annotations',input_sha256=hashes,source_validation_used=False,external_data_used=False)
    write_json(out/'source_preflight.json',report);write_csv(out/'source_sequence_inventory.csv',ledger)
    return data


def dense_subset(data,subjects):
    ix=np.flatnonzero(np.isin(data['subjects'],subjects));groups=defaultdict(list)
    for i in ix:groups[data['meta'][i]['sequence_id']].append(i)
    px=[];rx=[];labels=[];rows=[];specs={}
    for sid,indices in sorted(groups.items()):
        meta=[data['meta'][i] for i in indices]
        starts=np.array([int(r['start_frame_index']) for r in meta]);ends=np.array([int(r['target_frame_index']) for r in meta])
        fp,p,_,_=reconstruct(data['pose'][indices],starts,ends);fr,r,_,_=reconstruct(data['rgb'][indices],starts,ends)
        np.testing.assert_array_equal(fp,fr)
        if fp[0]!=1:raise ValueError('Unexpected coverage start')
        ep=fp[15:];px.append(windows_at(p,fp,ep));rx.append(windows_at(r,fr,ep));specs[sid]=data['specs'][sid]
        sp=specs[sid];labels.append(state_targets(ep,sp['category'],sp['onset'],sp['stable']))
        for frame in ep:rows.append(dict(sequence_id=sid,subject_id=int(meta[0]['subject_id']),source_frame_number=int(frame),sample_timestamp_ms=(int(frame)-1)*50.,source_timestamp_ms=(int(frame)-1)*50.))
    return dict(pose=np.concatenate(px),rgb=np.concatenate(rx),y=np.concatenate(labels),rows=rows,specs=specs)
