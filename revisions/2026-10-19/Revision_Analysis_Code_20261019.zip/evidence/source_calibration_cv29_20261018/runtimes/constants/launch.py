#!/usr/bin/env python3
"""Launch one detached bounded/timely experiment under the approved root."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime,timezone,timedelta

ROOT=Path('/data1/yoloA27_full_snapshot_20261014')
PY=Path('/home/xiaohaoran/.conda/envs/yolo4090/bin/python')
TOOLS=Path(__file__).resolve().parent
RESULT=ROOT/'experiments/gate_constant_controls_cv29_4090_20261018_v1'


def main():
    argparse.ArgumentParser(description=__doc__).parse_args()
    if os.name!='posix' or ROOT.resolve()!=ROOT or ROOT not in TOOLS.parents:raise RuntimeError('Run only inside approved Linux4090 root')
    if Path(sys.executable).resolve()!=PY.resolve() or sys.version_info[:3]!=(3,9,25):raise RuntimeError('Use original absolute yolo4090 interpreter')
    from control_pipeline import bundle_check
    bundle_check(TOOLS)
    for name,archive in [('gate_cv29_4090_20261017_v2','Gate_CV29_Results_20261017.zip'),('gate_suite_cv29_4090_20261018_v1','Gate_Suite_CV29_Results_20261018.zip'),('gate_regularization_cv29_4090_20261018_v1','Gate_Regularization_CV29_Results_20261018.zip')]:
        folder=ROOT/'experiments'/name
        if not (folder/archive).is_file() or json.loads((folder/'status.json').read_text())['state']!='COMPLETE':raise RuntimeError('Completed previous archive required: '+str(folder))
    if RESULT.exists():raise FileExistsError('Existing results preserved: '+str(RESULT))
    if ROOT not in RESULT.resolve().parents:raise ValueError('Output outside project')
    env=os.environ.copy()
    for key in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']:env[key]='2'
    env['CUBLAS_WORKSPACE_CONFIG']=':4096:8';env['PYTHONDONTWRITEBYTECODE']='1';env.setdefault('CUDA_VISIBLE_DEVICES','0')
    logs=TOOLS/'logs';logs.mkdir(exist_ok=True);stamp=datetime.now(timezone(timedelta(hours=8))).strftime('%Y%m%d_%H%M%S_%f');log=logs/('pipeline_'+stamp+'.log')
    with (TOOLS/'launch_record.json').open('x',encoding='utf-8') as claim:
        with log.open('xb') as stream:
            process=subprocess.Popen([str(PY),'-u',str(TOOLS/'control_pipeline.py'),'--root',str(ROOT)],cwd=str(TOOLS),env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        info=dict(pid=process.pid,log=str(log),result=str(RESULT),status_file=str(RESULT/'status.json'),gpu_mask=env['CUDA_VISIBLE_DEVICES'],newly_trained_heads=0,scalar_fits=9,mean_controls=27,branches_retrained=False,temperatures_refitted=False,launch_only_not_completion=True)
        json.dump(info,claim,indent=2)
    print('DETACHED_JOB_STARTED',json.dumps(info,indent=2),flush=True)
    print('You may disconnect SSH. Completion requires state COMPLETE and ALL_CONSTANT_CONTROLS_EXPERIMENTS_COMPLETE in log.',flush=True)


if __name__=='__main__':main()
