import tempfile
from pathlib import Path
import unittest
from bounded_pipeline import seal,verify_seal


class SealChecks(unittest.TestCase):
    def test_complete_models_and_frozen_temperature_tampering(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            out=Path(directory);train=out/'training';train.mkdir();prepared=out/'prepared';prepared.mkdir();temp=out/'frozen_temperatures.json';temp.write_bytes(b'{}')
            with self.assertRaises(ValueError):seal(out)
            for i in range(54):
                folder=train/str(i);folder.mkdir();(folder/'model.pt').write_bytes(b'fixture')
            seal(out);verify_seal(out);temp.write_bytes(b'changed')
            with self.assertRaises(ValueError):verify_seal(out)


if __name__=='__main__':unittest.main(verbosity=2)
