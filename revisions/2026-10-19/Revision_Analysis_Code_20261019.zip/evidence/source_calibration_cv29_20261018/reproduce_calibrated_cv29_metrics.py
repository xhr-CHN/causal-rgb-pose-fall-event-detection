"""Reconstruct retained candidate-alarm metrics without training or raw media.

After extracting Analysis_S2_Source_Data.zip, this script is in
evidence/source_calibration_cv29_20261018/. Default: primary0.85 only.
"""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import sys
import zipfile
import numpy as np

HERE=Path(__file__).resolve().parent


def csv_rows(z,name):return list(csv.DictReader(io.StringIO(z.read(name).decode('utf-8-sig'))))
def array(z,name):
    with np.load(io.BytesIO(z.read(name)),allow_pickle=False) as a:return {k:a[k].copy() for k in a.files}


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--archive',type=Path,required=True);ap.add_argument('--runtime-path',type=Path,default=HERE/'runtimes/stress');ap.add_argument('--all-policies',action='store_true');args=ap.parse_args()
    sys.path.insert(0,str(args.runtime_path.resolve()))
    from gate_dynamic_utils import candidates,event_metrics
    from gate_opt_features import frame_metrics
    checked=0
    with zipfile.ZipFile(args.archive) as z:
        if z.testzip() is not None:raise ValueError('Archive CRC failure')
        completion=json.loads(z.read('completion_summary.json'));stress=completion.get('cases')==28
        cases=json.loads(z.read('protocol.json'))['cases'] if stress else [dict(case='normal')]
        policies=['fixed_085','fixed_0875','fixed_090','dynamic'] if args.all_policies else ['fixed_085']
        for case in cases:
            prefix='evaluation/'+case['case']+'/' if stress else 'evaluation/'
            records=csv_rows(z,prefix+'fold_metrics.csv');events=csv_rows(z,prefix+'event_results.csv')
            table={(int(r['fold']),r['model'],int(r['seed']),r['policy']):r for r in records};roles=sorted({(r['model'],int(r['seed'])) for r in records})
            for fold in [1,2,3]:
                folder=prefix+f'fold{fold}/'
                specs={r['sequence_id']:dict(category=r['category'],onset=int(r['onset_frame']) if r['onset_frame'] else None) for r in events if int(r['fold'])==fold and r['model']=='calibrated_fixed' and r['policy']=='fixed_085'}
                common=csv_rows(z,folder+'frame_inventory.csv') if stress else None
                ycommon=array(z,folder+'targets.npz')['y'] if stress else None
                for model,seed in roles:
                    stem=model+f'_seed{seed}';a=array(z,folder+stem+'_predictions.npz');p,w=a['probabilities'],a['gate_weights'];y=ycommon if stress else a['y']
                    raw=common if stress else csv_rows(z,folder+stem+'_weights.csv')
                    rows=[dict(sequence_id=r['sequence_id'],source_frame_number=int(r['source_frame_number']),
                        sample_timestamp_ms=float(r.get('sample_timestamp_ms',(int(r['source_frame_number'])-1)*50)),source_timestamp_ms=float(r.get('source_timestamp_ms',(int(r['source_frame_number'])-1)*50))) for r in raw]
                    if len(rows)!=len(y) or p.shape!=(len(y),3) or w.shape!=(len(y),):raise ValueError('Prediction/frame alignment')
                    frames=frame_metrics(y,p);hours=float(np.sum(y==0)/(20*3600))
                    for policy in policies:
                        actual,_=event_metrics(candidates(rows,p,w,policy),specs,hours);record=table[(fold,model,seed,policy)]
                        for key,value in {**frames,**actual}.items():
                            if value is None:
                                if record[key]!='':raise ValueError('Missing-value mismatch')
                            elif abs(float(value)-float(record[key]))>1e-10:raise ValueError('Metric mismatch: '+str((case['case'],fold,model,seed,policy,key)))
                        checked+=1
            print('CASE_RECONSTRUCTED',case['case'],checked,flush=True)
    print(json.dumps(dict(status='metrics_reconstructed',fold_policy_rows=checked,archive_sha256=hashlib.sha256(args.archive.read_bytes()).hexdigest(),training=False,new_inference=False)))


if __name__=='__main__':main()
