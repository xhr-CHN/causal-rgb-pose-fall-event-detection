# October 2026 revision materials

This supplement documents the revision of **Cross-Dataset Fall-Event Detection via Causal RGB-Pose Temporal Modeling and Alarm Verification**. It supplements, rather than rewrites, the historical [v1.3.0](https://github.com/xhr-CHN/causal-rgb-pose-fall-event-detection/releases/tag/v1.3.0) workflow and frozen results. The manuscript URL does not need to change.

## Included additions

- Fixed OmniFall Le2i annotation provenance and source-timestamp endpoint mapping; the unsupported missing-file-as-ADL default is withdrawn.
- Corrected verifier development, the selected eight-feature pre-candidate model, and retrospective GMDCSA24 reassessment without rescue.
- Paired fusion tests and complete-video intervals, corrected URFD exposure accounting, verifier operating curves, descriptive costs, sampling/image sensitivity, learning curves and boundary perturbations.
- Descriptive false-alarm inspection records without redistribution of participant imagery.
- Exploratory source-only calibration, bounded-gate regularization, optimized-constant and training-mean controls, and frozen feature-stress analyses.

## Current interpretation

URFD retains 28/30 detections for fixed and gated fusion, with 24 and 26 false alarms, respectively. With the corrected complete Le2i labels, fixed fusion detects 122/130 with 103 false alarms; gated fusion detects 124/130 with 101. The paired external comparisons do not establish a consistent learned-gate advantage.

The historical GMDCSA24 final operating point remains 60/79 detections and 14 false alarms (53.32/h over approximately 0.262573 h negative exposure). The corrected eight-feature verifier reaches the same aggregate counts without rescue but changes individual errors. Its reassessment is retrospective, not a new blind test. Historical records remain distinct.

On the repeatedly inspected six-person/29-event source CV, the bounded calibrated zero-anchor head improves the primary 0.85 point from the original-structure reference of 25 detections/10 false alarms to 27/4; the 0.90 sensitivity point changes 25/9 to 29/1, with increased conditional delay. Calibrated equal fusion reaches the same detection and false-alarm counts, while dynamic weighting shows local timing differences and the weak-anchor optimized constant closely matches it. Three head seeds are not 87 independent falls. Feature stress is not a physical-camera or deployment validation.

## Files and downloads

Executed Python sources in `scripts/` and `evidence/source_calibration_cv29_20261018/` are retained byte-for-byte from the submitted analysis archive. `FILE_MANIFEST.csv` and `SHA256SUMS.txt` cover this source snapshot. Historical server paths remain in some scripts and protocols for provenance; adapt roots locally and retain the frozen roles/thresholds when reproducing records.

The separate release supplement is intended to carry these assets:

1. `Analysis_S2_Source_Data.zip`: exact submitted analysis archive, SHA-256 `47812402a9c725681b4b1da62d5edce39efc0a08d88f992ce516c7698cb2e614`.
2. `Revision_Analysis_Code_20261019.zip`: convenient source-only snapshot of this folder.
3. `Supplementary_Analysis_S2.pdf`: the submitted 12-page technical supplement.
4. Asset checksums and manifest.

See `REPRODUCTION.md` for prediction-metric reconstruction. Full dataset media, large source feature tensors and the 15 fold-specific temporal branch checkpoints are not supplied here. The saved records do not constitute an independent replay of the complete training history.

## Licensing and boundaries

Repository-authored source remains AGPL-3.0-only. Dataset-derived annotations, predictions, fitting records and checkpoints remain subject to the original providers' applicable terms; they are not relicensed as unrestricted data. No raw participant imagery or confidential reviewer/editor correspondence is added. An automated credential scan is not a substitute for an author's final privacy and redistribution-rights check.
