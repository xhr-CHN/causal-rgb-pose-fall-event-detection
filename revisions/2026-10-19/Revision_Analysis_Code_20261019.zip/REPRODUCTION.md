# Revision reanalysis

The original tag v1.3.0 retains the pre-revision training workflow. This directory contains additional revision analysis scripts and exploratory head-study tools. It does not replace the primary temporal model or establish a new blind test.

## Minimal prediction-level check

Download the separate `Analysis_S2_Source_Data.zip` asset and extract it into a new directory, for example `analysis_data/`. It contains the analysis procedures, cached records and intact result archives used by S2. Use Python with NumPy; the recorded server environment used Python 3.9.25, NumPy 1.26.4 and PyTorch 2.1.0+cu121/cuDNN 8902 for model work.

From the extracted analysis-data root:

```bash
python evidence/source_calibration_cv29_20261018/reproduce_calibrated_cv29_metrics.py --archive evidence/source_calibration_cv29_20261018/archives/Gate_Constant_Controls_CV29_Results_20261018.zip --all-policies
```

For frozen stress records, replace the archive argument with `Gate_Modality_Stress_Side_Results_20261018.zip` in the same directory. Without `--all-policies`, only the primary 0.85 point is checked. This reads saved predictions and does not train or run neural inference.

The same helper is present in this repository directory. It looks for `runtimes/stress/` next to itself, corresponding to `evidence/source_calibration_cv29_20261018/runtimes/stress/` from this revision-directory root; use `--runtime-path` if placing it elsewhere. Per-file SHA-256 values allow verification against the submitted source archive.

## Other analyses

`scripts/executed_provenance/` retains the label mapping, verifier correction, intervals and retrospective assessment procedures. `scripts/false_alarm_visual_audit/` retains descriptive audit procedures, but no raw participant videos or sampled contact sheets are distributed. Compact current CSV/JSON summaries are in `results/`; complete saved inputs/results remain in the separate source-data asset.

Some executed procedures retain fixed original paths and no-overwrite guards. Read each script's arguments and protocol before running it. Do not point a reconstruction job at a historical output directory or label new work as the original blind evaluation.

## What is not demonstrated

OOF/development uncertainty does not remove selection optimism; repeated source CV and stress are exploratory. Full training reproduction additionally requires the licensed original datasets, source features and separately archived branch checkpoints. No deployment, multi-person, natural-elderly-fall or camera-isolated generalization claim follows from these checks.
